# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "mmd Quick tool",
    "author" : "SFY", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 1, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "https://github.com/bb-yi/mmd-Quick-tool", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import mathutils
from bpy.app.handlers import persistent
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper
import blf
from bpy_extras.view3d_utils import location_3d_to_region_2d
from datetime import datetime


addon_keymaps = {}
_icons = None
ikfix = {'sna_bone_obj': None, 'sna_base_obj': None, 'sna_bone': [], 'sna_constraint_obj': None, 'sna_abc': None, 'sna_bone_list': [], }
node_tree_001 = {'sna_old_light_shading': 'MATCAP', 'sna_old_color_type_shading': 'OBJECT', 'sna_old_show_wireframes': False, 'sna_old_show_bones': True, 'sna_old_active_objects': '', }
node_tree_004 = {'sna_is_other_color_space': False, }
node_tree_001 = {'sna_sub_render_time': 0.0, 'sna_avg_render_time': 0.0, 'sna_sub_frame': 0, 'sna_current_frame': 0, 'sna_default_camera': '', 'sna_default_frame_start': 0, 'sna_default_frame_end': 0, 'sna_default_output_directory': '', }
node_tree_004 = {'sna_last_node': None, 'sna_bake_tex_size_x': 0, 'sna_bake_tex_size_y': 0, }
node_tree_002 = {'sna_sna_new_variable': '', }


def sna_update_sna_ik_fix_on_057DD(self, context):
    sna_updated_prop = self.sna_ik_fix_on
    if ((len(bpy.context.view_layer.objects.selected) == 1) and (bpy.context.view_layer.objects.active.type == 'ARMATURE')):
        for i_40A47 in range(len(bpy.context.view_layer.objects.active.data.bones)):
            for i_8327B in range(len(bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints)-1,-1,-1):
                if ('Copy Location_P' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].name or 'Damped Track_X' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].name or 'Damped Track_Z' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].name):
                    if bpy.context.scene.sna_ik_fix_on:
                        if bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].enabled:
                            pass
                        else:
                            bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].enabled = True
                    else:
                        if bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].enabled:
                            bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_40A47].name].constraints[i_8327B].enabled = False
    else:
        self.report({'WARNING'}, message='没有选中骨骼')


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_update_sna_new_property_001_7222D(self, context):
    sna_updated_prop = self.sna_new_property_001
    print(sna_updated_prop)
    if sna_updated_prop == "15":
        bpy.data.lights[bpy.context.active_object.name].spread = float(15 * 0.01745299994945526)
    elif sna_updated_prop == "60":
        bpy.data.lights[bpy.context.active_object.name].spread = float(60 * 0.01745299994945526)
    elif sna_updated_prop == "90":
        bpy.data.lights[bpy.context.active_object.name].spread = float(90 * 0.01745299994945526)
    elif sna_updated_prop == "120":
        bpy.data.lights[bpy.context.active_object.name].spread = float(120 * 0.01745299994945526)
    elif sna_updated_prop == "180":
        bpy.data.lights[bpy.context.active_object.name].spread = float(180 * 0.01745299994945526)
    elif sna_updated_prop == "0":
        bpy.data.lights[bpy.context.active_object.name].spread = float(0 * 0.01745299994945526)
    else:
        pass


def sna_update_sna_new_property_004_0F02E(self, context):
    sna_updated_prop = self.sna_new_property_004
    timemax_0_02639 = sna_setmaxi_454ED(sna_updated_prop)
    frame_0_85032, s_1_85032 = sna_time2frameinput_2F52D(timemax_0_02639)
    if bpy.context.scene.sna_open:
        bpy.context.scene.frame_current = frame_0_85032
        bpy.context.scene.sna_new_property_004 = timemax_0_02639


def sna_update_sna_bili_31149(self, context):
    sna_updated_prop = self.sna_bili
    print(sna_updated_prop)
    if sna_updated_prop == "1:1":
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
    elif sna_updated_prop == "3:2":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(3.0 / 2.0))
    elif sna_updated_prop == "4:3":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(4.0 / 3.0))
    elif sna_updated_prop == "16:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(16.0 / 9.0))
    elif sna_updated_prop == "14:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(14.0 / 9.0))
    elif sna_updated_prop == "1.85:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(1.850000023841858 / 1.0))
    elif sna_updated_prop == "2.39:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(2.390000104904175 / 1.0))
    else:
        pass


def sna_update_sna_view_tex_632AA(self, context):
    sna_updated_prop = self.sna_view_tex
    print(str(sna_updated_prop))
    for i_16090 in range(len(bpy.context.screen.areas)):
        if (bpy.context.screen.areas[i_16090].type == 'VIEW_3D'):
            for i_BB728 in range(len(bpy.context.screen.areas[i_16090].spaces)):
                if (bpy.context.screen.areas[i_16090].spaces[i_BB728].type == 'VIEW_3D'):
                    if (((bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.light == 'FLAT') and (bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.color_type == 'TEXTURE')) and bpy.context.scene.sna_view_tex):
                        node_tree_001['sna_old_light_shading'] = 'MATCAP'
                        node_tree_001['sna_old_color_type_shading'] = 'OBJECT'
                        node_tree_001['sna_old_show_wireframes'] = False
                        node_tree_001['sna_old_show_bones'] = True
                        bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.light = node_tree_001['sna_old_light_shading']
                        bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.color_type = node_tree_001['sna_old_color_type_shading']
                        bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_wireframes = node_tree_001['sna_old_show_wireframes']
                        bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_bones = node_tree_001['sna_old_show_bones']
                    else:
                        if bpy.context.scene.sna_view_tex:
                            node_tree_001['sna_old_light_shading'] = bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.light
                            node_tree_001['sna_old_color_type_shading'] = bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.color_type
                            node_tree_001['sna_old_show_wireframes'] = bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_wireframes
                            node_tree_001['sna_old_show_bones'] = bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_bones
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.light = 'FLAT'
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.color_type = 'TEXTURE'
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_wireframes = False
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_bones = False
                        else:
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.light = node_tree_001['sna_old_light_shading']
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].shading.color_type = node_tree_001['sna_old_color_type_shading']
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_wireframes = node_tree_001['sna_old_show_wireframes']
                            bpy.context.screen.areas[i_16090].spaces[i_BB728].overlay.show_bones = node_tree_001['sna_old_show_bones']
                            node_tree_001['sna_old_light_shading'] = 'MATCAP'
                            node_tree_001['sna_old_color_type_shading'] = 'OBJECT'
                            node_tree_001['sna_old_show_wireframes'] = False
                            node_tree_001['sna_old_show_bones'] = True


def sna_update_sna_new_property_003_B42B0(self, context):
    sna_updated_prop = self.sna_new_property_003
    if sna_updated_prop:
        bpy.context.preferences.view.language = 'zh_CN'
        bpy.context.preferences.view.use_translate_new_dataname = False
    else:
        bpy.context.preferences.view.language = 'en_US'
        bpy.context.preferences.view.use_translate_new_dataname = False


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def sna_update_sna_display_ver_id_C6BB7(self, context):
    sna_updated_prop = self.sna_display_ver_id
    bpy.ops.sna.operator_5f6b3('INVOKE_DEFAULT', )


def sna_update_sna_display_ver_color_BD949(self, context):
    sna_updated_prop = self.sna_display_ver_color
    bpy.ops.sna.operator_5f6b3('INVOKE_DEFAULT', )


def sna_update_sna_display_ver_size_04D29(self, context):
    sna_updated_prop = self.sna_display_ver_size
    bpy.ops.sna.operator_5f6b3('INVOKE_DEFAULT', )


def sna_update_render_camera_28727(self, context):
    sna_updated_prop = self.render_camera
    for i_18B62 in range(len(bpy.context.scene.sna_render_list)):
        if (bpy.context.scene.sna_render_list[i_18B62].render_camera == None):
            pass
        else:
            if ((bpy.context.scene.sna_render_list[i_18B62].render_camera != None) and bpy.context.scene.sna_render_list[i_18B62].render_camera.type == 'CAMERA'):
                pass
            else:
                bpy.context.scene.sna_render_list[i_18B62].render_camera = None


class SNA_UL_display_collection_list_E8A78(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_E8A78, icon, active_data, active_propname, index_E8A78):
        row = layout
        row_49AD8 = layout.row(heading='', align=True)
        row_49AD8.alert = False
        row_49AD8.enabled = True
        row_49AD8.active = True
        row_49AD8.use_property_split = False
        row_49AD8.use_property_decorate = False
        row_49AD8.scale_x = 1.0
        row_49AD8.scale_y = 1.0
        row_49AD8.alignment = 'Left'.upper()
        row_49AD8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_49AD8.template_icon(icon_value=124, scale=1.0)
        row_49AD8.prop(item_E8A78, 'name', text='', icon_value=0, emboss=False)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


class SNA_UL_display_collection_list001_8124D(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_8124D, icon, active_data, active_propname, index_8124D):
        row = layout
        split_338A7 = layout.split(factor=0.14944426715373993, align=False)
        split_338A7.alert = False
        split_338A7.enabled = True
        split_338A7.active = True
        split_338A7.use_property_split = False
        split_338A7.use_property_decorate = False
        split_338A7.scale_x = 1.0
        split_338A7.scale_y = 1.0
        split_338A7.alignment = 'Expand'.upper()
        if not True: split_338A7.operator_context = "EXEC_DEFAULT"
        split_338A7.label(text=str(int(index_8124D + 1.0)) + '.', icon_value=0)
        row_B9650 = split_338A7.row(heading='', align=True)
        row_B9650.alert = False
        row_B9650.enabled = True
        row_B9650.active = True
        row_B9650.use_property_split = False
        row_B9650.use_property_decorate = False
        row_B9650.scale_x = 1.7139999866485596
        row_B9650.scale_y = 1.0
        row_B9650.alignment = 'Left'.upper()
        row_B9650.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_B9650.prop(item_8124D, 'obj_list_pointer_property', text='', icon_value=0, emboss=True)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_B793B(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_B793B, icon, active_data, active_propname, index_B793B):
        row = layout
        layout.prop(item_B793B, 'on', text='', icon_value=(254 if item_B793B.on else 253), emboss=item_B793B.on)
        layout.prop(item_B793B, 'name', text='', icon_value=0, emboss=False)
        layout.prop(item_B793B, 'start_frame', text='开始', icon_value=0, emboss=item_B793B.on)
        layout.prop(item_B793B, 'end_frame', text='结束', icon_value=0, emboss=item_B793B.on)
        layout.prop(item_B793B, 'render_camera', text='', icon_value=168, emboss=item_B793B.on)
        layout.prop(item_B793B, 'output_directory', text='', icon_value=0, emboss=item_B793B.on)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def sna_select_vertex_9E7EA(i):
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active.data.vertices[i].select = True
    bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')


def sna_select_vertex_groups_8448B(name):
    bpy.ops.object.vertex_group_assign_new('INVOKE_DEFAULT', )
    bpy.context.view_layer.objects.active.vertex_groups.active.name = name


class SNA_OT_My_Generic_Operator_C8494(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_c8494"
    bl_label = "生成骨骼约束"
    bl_description = "选中骨架和abc(会自动识别顶点组包含的骨骼)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (len(bpy.context.view_layer.objects.selected) == 2):
            for i_9F071 in range(len(bpy.context.view_layer.objects.selected)):
                if (bpy.context.view_layer.objects.selected[i_9F071].type == 'ARMATURE'):
                    ikfix['sna_constraint_obj'] = bpy.context.view_layer.objects.selected[i_9F071]
                else:
                    ikfix['sna_abc'] = bpy.context.view_layer.objects.selected[i_9F071]
            for i_78390 in range(len(ikfix['sna_abc'].vertex_groups)):
                if '_x' in ikfix['sna_abc'].vertex_groups[i_78390].name:
                    ikfix['sna_bone_list'].append(ikfix['sna_abc'].vertex_groups[i_78390].name[:int(len(ikfix['sna_abc'].vertex_groups[i_78390].name) - 2.0)])
            bpy.context.view_layer.objects.active = ikfix['sna_constraint_obj']
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='POSE')
            for i_293E9 in range(len(ikfix['sna_constraint_obj'].data.bones)):
                if ikfix['sna_constraint_obj'].data.bones[i_293E9].name in ikfix['sna_bone_list']:
                    ikfix['sna_constraint_obj'].data.bones.active = ikfix['sna_constraint_obj'].data.bones[i_293E9]
                    constraint_52BAD = ikfix['sna_constraint_obj'].pose.bones[ikfix['sna_constraint_obj'].data.bones.active.name].constraints.new(type='COPY_LOCATION', )
                    constraint_52BAD.name = 'Copy Location_P'
                    constraint_52BAD.target = ikfix['sna_abc']
                    constraint_52BAD.subtarget = ikfix['sna_constraint_obj'].data.bones[i_293E9].name + '_p'
                    constraint_BBB91 = ikfix['sna_constraint_obj'].pose.bones[ikfix['sna_constraint_obj'].data.bones.active.name].constraints.new(type='DAMPED_TRACK', )
                    constraint_BBB91.name = 'Damped Track_X'
                    constraint_BBB91.target = ikfix['sna_abc']
                    constraint_BBB91.subtarget = ikfix['sna_constraint_obj'].data.bones[i_293E9].name + '_x'
                    constraint_BBB91.track_axis = 'TRACK_X'
                    constraint_FA476 = ikfix['sna_constraint_obj'].pose.bones[ikfix['sna_constraint_obj'].data.bones.active.name].constraints.new(type='DAMPED_TRACK', )
                    constraint_FA476.name = 'Damped Track_Z'
                    constraint_FA476.target = ikfix['sna_abc']
                    constraint_FA476.subtarget = ikfix['sna_constraint_obj'].data.bones[i_293E9].name + '_z'
                    constraint_FA476.track_axis = 'TRACK_Z'
                    self.report({'INFO'}, message='添加约束完成')
        else:
            self.report({'WARNING'}, message='没有选中两个物体')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Ik_B204A(bpy.types.Operator):
    bl_idname = "sna.ik_b204a"
    bl_label = "切换ik"
    bl_description = "关闭/打开IK"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if ((len(bpy.context.view_layer.objects.selected) == 1) and (bpy.context.view_layer.objects.active.type == 'ARMATURE')):
            for i_74BC2 in range(len(bpy.context.view_layer.objects.active.data.bones)):
                for i_DC99E in range(len(bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_74BC2].name].constraints)-1,-1,-1):
                    if 'IK' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_74BC2].name].constraints[i_DC99E].name:
                        bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_74BC2].name].constraints[i_DC99E].enabled =  not bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_74BC2].name].constraints[i_DC99E].enabled
                        self.report({'INFO'}, message=('已打开ik' if bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_74BC2].name].constraints[i_DC99E].enabled else '已关闭ik'))
        else:
            self.report({'WARNING'}, message='没有选中骨骼')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_C3269(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_c3269"
    bl_label = "添加骨骼物体"
    bl_description = "选中需要添加骨骼物体的骨架"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.BoolProperty(name='自定义骨骼物体', description='', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (len(bpy.context.view_layer.objects.selected) == 1):
            if (bpy.context.view_layer.objects.active.type == 'ARMATURE'):
                ikfix['sna_bone'] = []
                for i_6AD46 in range(len(bpy.context.view_layer.objects.active.data.bones)):
                    if bpy.context.view_layer.objects.active.data.bones[i_6AD46].select:
                        ikfix['sna_bone'].append(bpy.context.view_layer.objects.active.data.bones[i_6AD46].name)
                if self.sna_new_property:
                    for i_CAD53 in range(len(bpy.context.view_layer.objects.active.data.bones)):
                        if bpy.context.view_layer.objects.active.data.bones[i_CAD53].name in ikfix['sna_bone']:
                            bpy.context.view_layer.objects.active.data.bones[i_CAD53].select = True
                else:
                    bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='POSE')
                    bpy.ops.pose.select_all('INVOKE_DEFAULT', action='DESELECT')
                    for i_F4341 in range(len(['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'])):
                        bpy.ops.object.select_pattern(pattern=['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'][i_F4341])
                if (self.sna_new_property and (len(ikfix['sna_bone']) == 0)):
                    self.report({'WARNING'}, message='没有选中骨骼')
                else:
                    ikfix['sna_bone_obj'] = bpy.context.view_layer.objects.active
                    if (ikfix['sna_bone_obj'].type == 'ARMATURE'):
                        bpy.ops.mesh.primitive_cube_add('INVOKE_DEFAULT', )
                        bpy.context.view_layer.objects.active.name = '骨骼坐标系'
                        ikfix['sna_base_obj'] = bpy.context.view_layer.objects.active
                        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
                        bpy.ops.mesh.select_all(action='SELECT')
                        bpy.ops.transform.transform(value=(0.05000000074505806, 0.05000000074505806, 0.05000000074505806, 0.0))
                        bpy.ops.transform.resize(value=(0.05000000074505806, 0.05000000074505806, 0.05000000074505806), orient_type='GLOBAL')
                        bpy.ops.mesh.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.context.view_layer.objects.active.data.vertices[7].select = True
                        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
                        bpy.ops.mesh.delete(type='VERT')
                        sna_select_vertex_9E7EA(0)
                        sna_select_vertex_groups_8448B('p')
                        sna_select_vertex_9E7EA(4)
                        sna_select_vertex_groups_8448B('x')
                        sna_select_vertex_9E7EA(2)
                        sna_select_vertex_groups_8448B('y')
                        sna_select_vertex_9E7EA(1)
                        sna_select_vertex_groups_8448B('z')
                        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT')
                        bpy.context.view_layer.objects.active = ikfix['sna_bone_obj']
                        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='POSE')
                        for i_7D9BF in range(len(ikfix['sna_bone_obj'].data.bones)):
                            if ikfix['sna_bone_obj'].data.bones[i_7D9BF].select:
                                id_C2AF2 = ikfix['sna_base_obj'].copy()
                                id_1CE8E = id_C2AF2.data.copy()
                                id_C2AF2.data = id_1CE8E
                                bpy.context.collection.objects.link(object=id_C2AF2, )
                                id_C2AF2.name = ikfix['sna_bone_obj'].data.bones[i_7D9BF].name
                                id_C2AF2.matrix_world = ikfix['sna_bone_obj'].data.bones[i_7D9BF].matrix_local
                                for i_A9C43 in range(len(id_C2AF2.vertex_groups)):
                                    id_C2AF2.vertex_groups[i_A9C43].name = ikfix['sna_bone_obj'].data.bones[i_7D9BF].name + '_' + id_C2AF2.vertex_groups[i_A9C43].name
                                group_01804 = id_C2AF2.vertex_groups.new(name=ikfix['sna_bone_obj'].data.bones[i_7D9BF].name, )
                                for i_37E11 in range(len(id_C2AF2.data.vertices)):
                                    group_01804.add(index=(id_C2AF2.data.vertices[i_37E11].index, 0, 0), weight=1.0, type='REPLACE', )
                                modifier_130DA = id_C2AF2.modifiers.new(name='Armature Modifier', type='ARMATURE', )
                                modifier_130DA.object = ikfix['sna_bone_obj']
                                bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT')
                                bpy.ops.object.parent_set('INVOKE_DEFAULT', type='OBJECT')
                        bpy.data.objects.remove(object=ikfix['sna_base_obj'], )
                        bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[int(len(bpy.context.view_layer.objects.selected) - 1.0)]
                        bpy.ops.object.join('INVOKE_DEFAULT', )
                        bpy.context.view_layer.objects.selected[int(len(bpy.context.view_layer.objects.selected) - 1.0)].name = '骨骼物体'
                        self.report({'INFO'}, message='生成骨骼物体完成')
                    else:
                        self.report({'WARNING'}, message='所选物体不是骨骼')
            else:
                self.report({'WARNING'}, message='没有选中骨骼')
        else:
            self.report({'WARNING'}, message='没有选中骨骼')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_Cc136(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_cc136"
    bl_label = "传递顶点组"
    bl_description = "选中abc和骨骼物体"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (len(bpy.context.view_layer.objects.selected) == 2):
            if (len(bpy.context.view_layer.objects.active.vertex_groups) == 0):
                # 获取当前的活动物体
                abc_object = bpy.context.active_object
                # 获取当前激活的对象（骨架和物体）
                selected_objects = bpy.context.selected_objects
                # 遍历所有选中的物体
                for obj in selected_objects:
                    # 检查物体是否不是当前的活动物体
                    if obj != abc_object:
                        bone_axes_object = obj
                print(selected_objects)
                print("abc物体"+abc_object.name)
                print("骨骼物体"+bone_axes_object.name)
                # 检查是否有活动物体
                if abc_object is not None:
                    # 添加数据传递修改器
                    modifier = abc_object.modifiers.new(name="Data Transfer", type='DATA_TRANSFER')
                    # 设置传递的目标对象
                    if bone_axes_object is not None:
                        modifier.object = bone_axes_object
                    else:
                        print("找不到源对象")
                    # 设置传递数据类型为顶点数据和顶点组数据
                    modifier.use_vert_data = True
                    modifier.data_types_verts = {'VGROUP_WEIGHTS'}  # 设置为您需要的数据类型
                    #bpy.context.view_layer.objects.active = abc_object
                    bpy.ops.object.datalayout_transfer(modifier="Data Transfer")
                    # 应用修改器
                    bpy.ops.object.modifier_apply(modifier=modifier.name)
                    abc_object.select_set(True)  # 选中abc
                    # 更新视图以反映选择的更改
                    bpy.context.view_layer.objects.active = abc_object
                    bpy.context.view_layer.update()
                else:
                    print("没有找到活动物体")
            else:
                self.report({'WARNING'}, message='活动物体含有顶点组')
        else:
            self.report({'WARNING'}, message='没有选中两个物体')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_89058(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_89058"
    bl_label = "清除骨骼约束"
    bl_description = "选中骨骼，将清除生成的骨骼约束"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if ((len(bpy.context.view_layer.objects.selected) == 1) and (bpy.context.view_layer.objects.active.type == 'ARMATURE')):
            for i_751D8 in range(len(bpy.context.view_layer.objects.active.data.bones)):
                for i_70648 in range(len(bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints)-1,-1,-1):
                    if ('Copy Location_P' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints[i_70648].name or 'Damped Track_X' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints[i_70648].name or 'Damped Track_Z' in bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints[i_70648].name):
                        bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints.remove(constraint=bpy.context.view_layer.objects.active.pose.bones[bpy.context.view_layer.objects.active.data.bones[i_751D8].name].constraints[i_70648], )
                        self.report({'INFO'}, message='已移除约束')
        else:
            self.report({'WARNING'}, message='没有选中骨骼')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_C034B(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_c034b"
    bl_label = "烘焙约束"
    bl_description = "将ik约束烘焙为关键帧"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.IntProperty(name='起始帧', description='', default=0, subtype='NONE', min=0)
    sna_new_property_001: bpy.props.IntProperty(name='结束帧', description='', default=250, subtype='NONE', min=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active.type == 'ARMATURE'):
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='POSE')
            bpy.ops.sna.my_generic_operator_400a9('INVOKE_DEFAULT', sna_new_property='腿ik骨')
            bpy.ops.nla.bake(frame_start=self.sna_new_property, frame_end=self.sna_new_property_001, only_selected=True, visual_keying=True, clear_constraints=True, use_current_action=True, bake_types={'POSE'})
            self.report({'INFO'}, message='烘焙完成')
        else:
            self.report({'WARNING'}, message='活动物体不是骨骼')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator015_0Ebb1(bpy.types.Operator):
    bl_idname = "sna.operator015_0ebb1"
    bl_label = "Operator.015"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_new_property_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property: bpy.props.EnumProperty(name='位姿', description='', items=[('位置', '位置', '', 0, 0), ('旋转', '旋转', '', 0, 1), ('缩放', '缩放', '', 0, 2)])
    sna_x: bpy.props.BoolProperty(name='x', description='', default=True)
    sna_y: bpy.props.BoolProperty(name='y', description='', default=True)
    sna_z: bpy.props.BoolProperty(name='z', description='', default=True)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_37CB5 in range(len(bpy.context.selected_objects)):
            if (self.sna_new_property == '位置'):
                if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location", globals(), locals()):
                    bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location = tuple(mathutils.Vector((bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location if (self.sna_new_property == '位置') else (bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler if (self.sna_new_property == '旋转') else None))) * mathutils.Vector(((0 if self.sna_x else 1), (0 if self.sna_y else 1), (0 if self.sna_z else 1))))
            else:
                if (self.sna_new_property == '旋转'):
                    if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler", globals(), locals()):
                        bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler = tuple(mathutils.Vector((bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location if (self.sna_new_property == '位置') else (bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler if (self.sna_new_property == '旋转') else None))) * mathutils.Vector(((0 if self.sna_x else 1), (0 if self.sna_y else 1), (0 if self.sna_z else 1))))
                else:
                    if (self.sna_new_property == '缩放'):
                        if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale", globals(), locals()):
                            bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale = ((1.0 if self.sna_x else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[0]), (1.0 if self.sna_y else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[1]), (1.0 if self.sna_z else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[2]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_setmaxi_454ED(time):
    return round((float(time + 0.0) if (float(float(time + 0.0) - int(time + 0.0)) < 0.6000000238418579) else float(0.6000000238418579 + int(time + 0.0))), abs(3))


def sna_time2frameinput_2F52D(time):
    return [int(round(float(float(float(float(time + 0.0) - int(time + 0.0)) * 100.0) + float(int(time + 0.0) * 60.0)), abs(1)) * bpy.context.scene.render.fps), round(float(float(float(float(time + 0.0) - int(time + 0.0)) * 100.0) + float(int(time + 0.0) * 60.0)), abs(1))]


def sna_frame2timei_02BDE(frame):
    return float(int(int(frame / bpy.context.scene.render.fps) / 60.0) + float(eval("int(frame / bpy.context.scene.render.fps) % 60.0") / 100.0))


class SNA_OT_Operator013_2E178(bpy.types.Operator):
    bl_idname = "sna.operator013_2e178"
    bl_label = "Operator.013"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import random

        def set_random_light_colors():
            # 获取当前选择的灯光对象
            selected_lights = [obj for obj in bpy.context.selected_objects if obj.type == 'LIGHT']
            for light in selected_lights:
                # 检查灯光是否有 color 属性
                if hasattr(light.data, 'color'):
                    # 生成随机颜色
                    random_color = [random.uniform(0, 1) for _ in range(3)]
                    # 设置灯光的颜色
                    light.data.color = random_color
        if __name__ == "__main__":
            set_random_light_colors()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_cycles_light_pt_light_B5682(self, context):
    if not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property_001):
        layout = self.layout
        row_9A489 = layout.row(heading='', align=True)
        row_9A489.alert = False
        row_9A489.enabled = True
        row_9A489.active = True
        row_9A489.use_property_split = False
        row_9A489.use_property_decorate = False
        row_9A489.scale_x = 1.0
        row_9A489.scale_y = 1.0
        row_9A489.alignment = 'Expand'.upper()
        row_9A489.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9A489.operator('sna.operator016_2e985', text='亮度*0.5', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator018_bf94b', text='亮度*0.75', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator019_8aa9a', text='亮度*1.5', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator017_e38ed', text='亮度*2', icon_value=31, emboss=True, depress=False)
        row_81A38 = layout.row(heading='', align=True)
        row_81A38.alert = False
        row_81A38.enabled = True
        row_81A38.active = True
        row_81A38.use_property_split = False
        row_81A38.use_property_decorate = False
        row_81A38.scale_x = 1.0
        row_81A38.scale_y = 1.0
        row_81A38.alignment = 'Expand'.upper()
        row_81A38.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_81A38.operator('sna.operator013_2e178', text='随机灯光颜色', icon_value=239, emboss=True, depress=False)


class SNA_OT_Operator019_8Aa9A(bpy.types.Operator):
    bl_idname = "sna.operator019_8aa9a"
    bl_label = "Operator.019"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 1.5)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator017_E38Ed(bpy.types.Operator):
    bl_idname = "sna.operator017_e38ed"
    bl_label = "Operator.017"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator018_Bf94B(bpy.types.Operator):
    bl_idname = "sna.operator018_bf94b"
    bl_label = "Operator.018"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 0.75)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator016_2E985(bpy.types.Operator):
    bl_idname = "sna.operator016_2e985"
    bl_label = "Operator.016"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 0.5)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def frame_change_post_handler_1BDE6(dummy):
    time_0_5ddbc = sna_frame2timei_02BDE(bpy.context.scene.frame_current)
    bpy.context.scene.sna_open = False
    bpy.context.scene.sna_new_property_004 = time_0_5ddbc
    bpy.context.scene.sna_open = True


def sna_add_to_time_mt_editor_menus_BB1C8(self, context):
    if not (False):
        layout = self.layout
        row_58E00 = layout.row(heading='', align=False)
        row_58E00.alert = False
        row_58E00.enabled = True
        row_58E00.active = True
        row_58E00.use_property_split = False
        row_58E00.use_property_decorate = False
        row_58E00.scale_x = 0.8320000171661377
        row_58E00.scale_y = 1.0
        row_58E00.alignment = 'Expand'.upper()
        row_58E00.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_58E00.prop(bpy.context.scene, 'sna_new_property_004', text='时间(分.秒)', icon_value=0, emboss=True)


def sna_add_to_dopesheet_ht_header_9E879(self, context):
    if not (False):
        layout = self.layout
        row_85DC3 = layout.row(heading='', align=True)
        row_85DC3.alert = False
        row_85DC3.enabled = True
        row_85DC3.active = True
        row_85DC3.use_property_split = False
        row_85DC3.use_property_decorate = False
        row_85DC3.scale_x = 1.0
        row_85DC3.scale_y = 1.0
        row_85DC3.alignment = 'Expand'.upper()
        row_85DC3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_85DC3.operator('sna.operator023_dc120', text='', icon_value=6, emboss=True, depress=False)
        op = row_85DC3.operator('sna.operator024_d37ce', text='', icon_value=4, emboss=True, depress=False)


class SNA_OT_Operator024_D37Ce(bpy.types.Operator):
    bl_idname = "sna.operator024_d37ce"
    bl_label = "Operator.024"
    bl_description = "将当前帧设置为结束帧"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.frame_end = bpy.context.scene.frame_current
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator023_Dc120(bpy.types.Operator):
    bl_idname = "sna.operator023_dc120"
    bl_label = "Operator.023"
    bl_description = "将当前帧设置为起始帧"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.frame_start = bpy.context.scene.frame_current
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator021_0D655(bpy.types.Operator):
    bl_idname = "sna.operator021_0d655"
    bl_label = "Operator.021"
    bl_description = "删除装配产生的材质变形节点组"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前选中的对象
        selected_objects = bpy.context.selected_objects
        for obj in selected_objects:
            # 检查对象是否有材质
            if obj.material_slots:
                for slot in obj.material_slots:
                    # 检查材质是否有节点
                    if slot.material.use_nodes:
                        # 初始化要删除的节点列表
                        nodes_to_remove = []
                        # 初始化贴图节点变量
                        base1_rgb_texture_node = None
                        # 遍历节点，收集所有MMDMorphAdd和MMDMorphMul节点，并找到初始的贴图节点
                        for node in slot.material.node_tree.nodes:
                            if node.type == 'GROUP' and ('MMDMorphAdd' in node.node_tree.name or 'MMDMorphMul' in node.node_tree.name):
                                # 如果是第一个MMDMorph节点组，获取它的贴图
                                if base1_rgb_texture_node is None:
                                    for link in node.inputs['Base1 RGB'].links:
                                        if link.from_node.type == 'TEX_IMAGE':
                                            base1_rgb_texture_node = link.from_node
                                            break
                                # 添加节点到待删除列表
                                nodes_to_remove.append(node)
                        # 删除所有MMDMorphAdd和MMDMorphMul节点
                        for node in nodes_to_remove:
                            slot.material.node_tree.nodes.remove(node)
                        # 如果找到贴图节点，连接到MMDShaderDev的Base Tex输入
                        if base1_rgb_texture_node:
                            # 找到MMDShaderDev节点组
                            target_node_group = next((node for node in slot.material.node_tree.nodes if node.type == 'GROUP' and 'MMDShaderDev' in node.node_tree.name), None)
                            # 连接贴图节点到MMDShaderDev的Base Tex
                            if target_node_group:
                                slot.material.node_tree.links.new(target_node_group.inputs['Base Tex'], base1_rgb_texture_node.outputs['Color'])
        # 更新场景，以反映节点更改
        bpy.context.view_layer.update()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator005_9368B(bpy.types.Operator):
    bl_idname = "sna.operator005_9368b"
    bl_label = "Operator.005"
    bl_description = "将替换mmd自带节点组为原理化节点组"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前选中的物体
        selected_objects = bpy.context.selected_objects
        # 遍历选中的物体
        for obj in selected_objects:
            # 遍历物体的所有材质槽
            for material_slot in obj.material_slots:
                material = material_slot.material
                # 遍历材质的所有节点
                for node in material.node_tree.nodes:
                    # 检查节点的类型和名称
                    if node.type == 'GROUP' and node.node_tree.name == 'MMDShaderDev':  # 替换为你的节点组名称
                        # 获取节点组的输入
                        base_tex_input = node.inputs.get('Base Tex')
                        base_alpha_input = node.inputs.get('Base Alpha')
                        # 如果找到对应的输入，继续处理
                        if base_tex_input and base_alpha_input:
                            # 获取连接到 Base Tex 和 Base Alpha 的连接
                            base_tex_link = base_tex_input.links[0] if base_tex_input.links else None
                            base_alpha_link = base_alpha_input.links[0] if base_alpha_input.links else None
                            # 创建新的原理化节点
                            principled_node = material.node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
                            principled_node.location = node.location
                            # 连接 Base Tex
                            if base_tex_link:
                                material.node_tree.links.new(principled_node.inputs['Base Color'], base_tex_link.from_socket)
                            # 连接 Base Alpha
                            if base_alpha_link:
                                material.node_tree.links.new(principled_node.inputs['Alpha'], base_alpha_link.from_socket)
                            # 连接新原理化节点到材质输出
                            material_output_node = material.node_tree.nodes.get("Material Output")
                            if material_output_node:
                                material.node_tree.links.new(material_output_node.inputs['Surface'], principled_node.outputs['BSDF'])
                            # 删除旧的节点
                            material.node_tree.nodes.remove(node)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator006_42368(bpy.types.Operator):
    bl_idname = "sna.operator006_42368"
    bl_label = "Operator.006"
    bl_description = "选中mmd相机和mmd相机的父级空物体"
    bl_options = {"REGISTER", "UNDO"}
    sna_camera_name: bpy.props.StringProperty(name='camera_name', description='', default='Camera', subtype='NONE', maxlen=0)
    sna_mmd_camera: bpy.props.StringProperty(name='MMD_Camera', description='', default='MMD_Camera', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not  not ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA')))

    def execute(self, context):
        if ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA'))):
            if bpy.context.view_layer.objects.selected[0].type == 'EMPTY':
                self.sna_mmd_camera = bpy.context.view_layer.objects.selected[0].name
                self.sna_camera_name = bpy.context.view_layer.objects.selected[1].name
                print(self.sna_mmd_camera + self.sna_camera_name)
                camera_name = self.sna_camera_name
                Advance_frame = bpy.context.scene.sna_new_property_002
                MMD_Camera = self.sna_mmd_camera
                '''
                camera_name="Camera"
                Advance_frame=30
                MMD_Camera='MMD_Camera'
                '''
                #选中物体

                def selected_object(Selected_object_name):
                # 检查物体是否存在
                    if Selected_object_name in bpy.data.objects:
                        obj = bpy.data.objects[Selected_object_name]
                        # 将指定物体设置为活动物体
                        bpy.context.view_layer.objects.active = obj
                        # 清除选择
                        bpy.ops.object.select_all(action='DESELECT')
                        # 选择指定物体
                        obj.select_set(True)
                    else:
                        print(f"找不到名为 '{Selected_object_name}' 的物体。")
                #选中通道

                def select_channel(channel_name):
                    # 获取当前激活的动作
                    current_action = bpy.context.object.animation_data.action
                    if current_action:
                        # 遍历当前动作的 F-Curves（通道）
                        for fcurve in current_action.fcurves:
                            if fcurve.data_path.endswith(channel_name):
                                fcurve.select = True
                            else:
                                fcurve.select = False

                def set_workspace_to_3d_view():
                    # 获取当前激活的工作区域
                    current_area = bpy.context.area
                    if current_area:
                        # 设置当前工作区域为3D视图
                        current_area.type = 'VIEW_3D'
                        print("Switched to 3D View.")
                    else:
                        print("No active workspace.")
                bpy.context.preferences.view.language = 'en_US'#设置语言为英文
                bpy.ops.object.select_all(action='DESELECT')#取消所有选择
                selected_object(MMD_Camera)
                bpy.context.area.type = 'DOPESHEET_EDITOR'#切换工作区域为动画摄影表
                bpy.context.area.spaces.active.dopesheet.show_only_selected = False#取消显示所有关键帧
                #选择名为angle的关键帧
                bpy.context.area.spaces.active.dopesheet.filter_text = "angle"#搜索通道名
                bpy.ops.action.select_all(action='SELECT')#全选关键帧
                bpy.ops.action.copy()
                select_channel("angle")#选中通道
                bpy.context.scene.frame_set(Advance_frame)#回到第0帧
                bpy.ops.anim.channels_setting_toggle(type='MUTE')#禁用通道
                bpy.context.area.spaces.active.dopesheet.filter_text = "perspective"
                select_channel("perspective")
                bpy.ops.anim.channels_setting_toggle(type='MUTE')
                #新建空物体
                empty = bpy.data.objects.new("焦距", None)
                bpy.context.scene.collection.objects.link(empty)
                selected_object("焦距")
                # 设置要操作的物体名称
                object_name = empty.name
                # 检查物体是否存在
                if object_name in bpy.data.objects:
                    obj = bpy.data.objects[object_name]
                    # 在时间轴中的特定帧设置物体的位置
                    frame = 0  # 替换为您要创建关键帧的帧数
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    # 在时间轴中的特定帧设置物体的位置
                    # 替换为您要创建关键帧的帧数
                    obj.location.x = 0.2  # 替换为您要设置的位置值
                    #obj.location.y = 0.0
                    #obj.location.z = 0.0
                    # 在指定帧上为位置属性创建关键帧
                    obj.keyframe_insert(data_path="location", frame=frame,index=0)
                    bpy.context.area.spaces.active.dopesheet.filter_text = "X Location"
                    bpy.ops.action.select_all(action='SELECT')
                    #粘贴关键帧
                    bpy.ops.action.paste(flipped=True)
                    bpy.context.area.spaces.active.dopesheet.filter_text = ""
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    bpy.context.preferences.view.language = 'zh_CN'#回到中文
                    bpy.context.area.type = 'TEXT_EDITOR'
                    #bpy.context.area.type = 'TEXT_EDITOR'
                    set_workspace_to_3d_view()
                    empty_obj = bpy.data.objects[object_name]
                    # 创建一个新的驱动器
                    driver = empty_obj.driver_add('location', 2)  # 在这里，将驱动器添加到目标物体的 Y 缩放属性（索引为 1）
                    # 设置驱动器的类型为 "Scripted Expression"，以自定义表达式
                    driver.driver.type = 'SCRIPTED'
                    # 创建一个自定义变量，用于控制驱动器
                    var = driver.driver.variables.new()
                    var.name = "var"  # 变量名称
                    var.type = 'SINGLE_PROP'
                    var.targets[0].id = empty_obj
                    var.targets[0].data_path = "location.x"  # 引用源物体的 X 位置属性
                    # 设置驱动器的表达式，以引用自定义变量 var
                    driver.driver.expression = "12/tan(var/2)"  # 使目标物体的 Y 缩放属性等于源物体的 X 位置属性的两倍
                    target_object = empty_obj
                    selected_object(camera_name)
                    # 通过名称获取相机对象
                    camera = bpy.data.objects.get(camera_name) 
                    if camera and target_object:
                        # 创建一个新的驱动器对象
                        driver = camera.data.driver_add("lens")  # "lens" 是焦距属性的名称
                        # 设置驱动器的类型为 "Scripted Expression"
                        driver.driver.type = "SCRIPTED"
                        # 创建一个自定义变量，并将其设置为控制驱动器的输入
                        var = driver.driver.variables.new()
                        var.name = "var"  # 自定义变量的名称
                        var.type = "SINGLE_PROP"
                        var.targets[0].id = target_object
                        var.targets[0].data_path = "location.z"  # 引用目标物体的 X 位置属性作为输入
                        # 设置驱动器的表达式，以引用自定义变量并计算焦距
                        driver.driver.expression = "var"  # 例如，这里是一个示例表达式
                    else:
                        print("找不到相机或目标物体。")
                else:
                    print(f"找不到名为 '{object_name}' 的物体。")
                set_workspace_to_3d_view()
            else:
                self.sna_mmd_camera = bpy.context.view_layer.objects.selected[1].name
                self.sna_camera_name = bpy.context.view_layer.objects.selected[0].name
                print(self.sna_mmd_camera + self.sna_camera_name)
                camera_name = self.sna_camera_name
                Advance_frame = bpy.context.scene.sna_new_property_002
                MMD_Camera = self.sna_mmd_camera
                '''
                camera_name="Camera"
                Advance_frame=30
                MMD_Camera='MMD_Camera'
                '''
                #选中物体

                def selected_object(Selected_object_name):
                # 检查物体是否存在
                    if Selected_object_name in bpy.data.objects:
                        obj = bpy.data.objects[Selected_object_name]
                        # 将指定物体设置为活动物体
                        bpy.context.view_layer.objects.active = obj
                        # 清除选择
                        bpy.ops.object.select_all(action='DESELECT')
                        # 选择指定物体
                        obj.select_set(True)
                    else:
                        print(f"找不到名为 '{Selected_object_name}' 的物体。")
                #选中通道

                def select_channel(channel_name):
                    # 获取当前激活的动作
                    current_action = bpy.context.object.animation_data.action
                    if current_action:
                        # 遍历当前动作的 F-Curves（通道）
                        for fcurve in current_action.fcurves:
                            if fcurve.data_path.endswith(channel_name):
                                fcurve.select = True
                            else:
                                fcurve.select = False

                def set_workspace_to_3d_view():
                    # 获取当前激活的工作区域
                    current_area = bpy.context.area
                    if current_area:
                        # 设置当前工作区域为3D视图
                        current_area.type = 'VIEW_3D'
                        print("Switched to 3D View.")
                    else:
                        print("No active workspace.")
                bpy.context.preferences.view.language = 'en_US'#设置语言为英文
                bpy.ops.object.select_all(action='DESELECT')#取消所有选择
                selected_object(MMD_Camera)
                bpy.context.area.type = 'DOPESHEET_EDITOR'#切换工作区域为动画摄影表
                bpy.context.area.spaces.active.dopesheet.show_only_selected = False#取消显示所有关键帧
                #选择名为angle的关键帧
                bpy.context.area.spaces.active.dopesheet.filter_text = "angle"#搜索通道名
                bpy.ops.action.select_all(action='SELECT')#全选关键帧
                bpy.ops.action.copy()
                select_channel("angle")#选中通道
                bpy.context.scene.frame_set(Advance_frame)#回到第0帧
                bpy.ops.anim.channels_setting_toggle(type='MUTE')#禁用通道
                bpy.context.area.spaces.active.dopesheet.filter_text = "perspective"
                select_channel("perspective")
                bpy.ops.anim.channels_setting_toggle(type='MUTE')
                #新建空物体
                empty = bpy.data.objects.new("焦距", None)
                bpy.context.scene.collection.objects.link(empty)
                selected_object("焦距")
                # 设置要操作的物体名称
                object_name = empty.name
                # 检查物体是否存在
                if object_name in bpy.data.objects:
                    obj = bpy.data.objects[object_name]
                    # 在时间轴中的特定帧设置物体的位置
                    frame = 0  # 替换为您要创建关键帧的帧数
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    # 在时间轴中的特定帧设置物体的位置
                    # 替换为您要创建关键帧的帧数
                    obj.location.x = 0.2  # 替换为您要设置的位置值
                    #obj.location.y = 0.0
                    #obj.location.z = 0.0
                    # 在指定帧上为位置属性创建关键帧
                    obj.keyframe_insert(data_path="location", frame=frame,index=0)
                    bpy.context.area.spaces.active.dopesheet.filter_text = "X Location"
                    bpy.ops.action.select_all(action='SELECT')
                    #粘贴关键帧
                    bpy.ops.action.paste(flipped=True)
                    bpy.context.area.spaces.active.dopesheet.filter_text = ""
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    bpy.context.preferences.view.language = 'zh_CN'#回到中文
                    bpy.context.area.type = 'TEXT_EDITOR'
                    #bpy.context.area.type = 'TEXT_EDITOR'
                    set_workspace_to_3d_view()
                    empty_obj = bpy.data.objects[object_name]
                    # 创建一个新的驱动器
                    driver = empty_obj.driver_add('location', 2)  # 在这里，将驱动器添加到目标物体的 Y 缩放属性（索引为 1）
                    # 设置驱动器的类型为 "Scripted Expression"，以自定义表达式
                    driver.driver.type = 'SCRIPTED'
                    # 创建一个自定义变量，用于控制驱动器
                    var = driver.driver.variables.new()
                    var.name = "var"  # 变量名称
                    var.type = 'SINGLE_PROP'
                    var.targets[0].id = empty_obj
                    var.targets[0].data_path = "location.x"  # 引用源物体的 X 位置属性
                    # 设置驱动器的表达式，以引用自定义变量 var
                    driver.driver.expression = "12/tan(var/2)"  # 使目标物体的 Y 缩放属性等于源物体的 X 位置属性的两倍
                    target_object = empty_obj
                    selected_object(camera_name)
                    # 通过名称获取相机对象
                    camera = bpy.data.objects.get(camera_name) 
                    if camera and target_object:
                        # 创建一个新的驱动器对象
                        driver = camera.data.driver_add("lens")  # "lens" 是焦距属性的名称
                        # 设置驱动器的类型为 "Scripted Expression"
                        driver.driver.type = "SCRIPTED"
                        # 创建一个自定义变量，并将其设置为控制驱动器的输入
                        var = driver.driver.variables.new()
                        var.name = "var"  # 自定义变量的名称
                        var.type = "SINGLE_PROP"
                        var.targets[0].id = target_object
                        var.targets[0].data_path = "location.z"  # 引用目标物体的 X 位置属性作为输入
                        # 设置驱动器的表达式，以引用自定义变量并计算焦距
                        driver.driver.expression = "var"  # 例如，这里是一个示例表达式
                    else:
                        print("找不到相机或目标物体。")
                else:
                    print(f"找不到名为 '{object_name}' 的物体。")
                set_workspace_to_3d_view()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator004_Fa32A(bpy.types.Operator):
    bl_idname = "sna.operator004_fa32a"
    bl_label = "Operator.004"
    bl_description = "合并使用同一基础色贴图的材质"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 存储贴图的字典
        texture_dict = {}
        color_input_name=["Color", "Base Color", "Diffuse Color", "Albedo","Base Tex"]
        # 获取所选物体列表
        selected_objects = bpy.context.selected_objects
        # 循环遍历所选物体
        for obj in selected_objects:
            # 检查物体是否为网格对象
            if isinstance(obj.data, bpy.types.Mesh):
                # 遍历物体的材质列表
                for material in obj.data.materials:
                    # 获取材质的节点树
                    tree = material.node_tree
                    # 遍历节点树中的所有节点
                    for node in tree.nodes:
                        # 检查节点类型是否为ShaderNodeTexImage（贴图节点）
                        if node.type == 'TEX_IMAGE':
                            # 检查节点的输出连接是否存在
                            if node.outputs['Color'].is_linked:
                                # 遍历节点的输出连接
                                for link in node.outputs['Color'].links:
                                    # 检查连接的输入端口名称是否为"基础颜色"
                                    for input_name in color_input_name:
                                        if link.to_socket.name == input_name:
                                            # 检查贴图是否已经在字典中
                                            if node.image.name not in texture_dict:
                                                # 将贴图节点添加到字典
                                                texture_dict[node.image.name] = material
                                                print('贴图已经在字典中', node.image.name)
                                            else:
                                                # 替换材质为字典中的材质
                                                new_material = texture_dict[node.image.name]
                                                # 将物体的材质更改为新的材质
                                                obj.data.materials[0] = new_material
                                                print('贴图不在字典中', node.image.name, '替换材质:', new_material.name)
                                    else:
                                        print('连接端口的贴图没找到')
                        else:
                            print("没有找到贴图")
            else:
                print('没有找到网格对象')
        #清理未使用数据块
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        # 设置材质的名称为贴图名称
        for tex_name, material in texture_dict.items():
            material.name = tex_name
        # 打印贴图字典
        print(texture_dict)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator025_4038C(bpy.types.Operator):
    bl_idname = "sna.operator025_4038c"
    bl_label = "Operator.025"
    bl_description = "为选中物体添加表情(需要安装mmd插件)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_0D15C in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_0D15C]
            bpy.ops.mmd_tools.import_vmd('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator001_64C4A(bpy.types.Operator):
    bl_idname = "sna.operator001_64c4a"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 2560
        bpy.context.scene.render.resolution_y = 1440
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_B46A6(bpy.types.Operator):
    bl_idname = "sna.operator_b46a6"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator007_85779(bpy.types.Operator):
    bl_idname = "sna.operator007_85779"
    bl_label = "Operator.007"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_ax: bpy.props.IntProperty(name='ax', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        self.sna_ax = bpy.context.scene.render.resolution_x
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_y = self.sna_ax
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator008_F7B4C(bpy.types.Operator):
    bl_idname = "sna.operator008_f7b4c"
    bl_label = "Operator.008"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x / 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y / 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator002_7Dbd9(bpy.types.Operator):
    bl_idname = "sna.operator002_7dbd9"
    bl_label = "Operator.002"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 3840
        bpy.context.scene.render.resolution_y = 2160
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator014_47F89(bpy.types.Operator):
    bl_idname = "sna.operator014_47f89"
    bl_label = "Operator.014"
    bl_description = "方形"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1920
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_render_pt_format_DCB79(self, context):
    if not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property):
        layout = self.layout
        row_96091 = layout.row(heading='', align=False)
        row_96091.alert = False
        row_96091.enabled = True
        row_96091.active = True
        row_96091.use_property_split = False
        row_96091.use_property_decorate = False
        row_96091.scale_x = 1.0
        row_96091.scale_y = 1.0
        row_96091.alignment = 'Center'.upper()
        row_96091.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_96091.prop(bpy.data.scenes['Scene'].render, 'film_transparent', text='透明', icon_value=0, emboss=True)
        row_96091.prop(bpy.data.scenes['Scene'].render, 'use_persistent_data', text='持久数据', icon_value=0, emboss=True)


class SNA_OT_Operator009_F9Bf5(bpy.types.Operator):
    bl_idname = "sna.operator009_f9bf5"
    bl_label = "Operator.009"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x * 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y * 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_MMD_9FB97(bpy.types.Panel):
    bl_label = 'mmd快速工具'
    bl_idname = 'SNA_PT_MMD_9FB97'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'MMD'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_OT_Mtl_78668(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.mtl_78668"
    bl_label = "选择mtl文件"
    bl_description = "选择mtl文件，贴图需要和mtl文件在同一个文件夹内"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.mtl', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        file_path = self.filepath
        import re
        # 脚本 by 三分仪
        # 将alembic_file.mtl所在路径复制进去，贴图和alembic_file.mtl在同一文件夹下
        #file_path = r'E:\mmd_project\绯色回响mmd\wj\alembic_file.mtl'
        materials = {}
        with open(file_path, 'r', encoding='gbk') as f:
            current_material = None
            for line in f:
                if line.startswith("newmtl"):
                    current_material = line.split()[1]
                    materials[current_material] = {}
                elif line.startswith("map_Kd"):
                    texture = line.split()[1:]
                    texture_name = " ".join(texture)
                    if current_material is not None:
                        materials[current_material]["map_Kd"] = texture_name
        new_materials_dict = {}
        for i, (key, value) in enumerate(materials.items()):
            new_key = f'xform_0_material_{i}'
            new_materials_dict[new_key] = value
        # Check if 'map_Kd' exists before trying to access it
        materials = {k: v.get('map_Kd', '') for k, v in new_materials_dict.items()}
        # Output the new dictionary
        print(materials)
        for key, value in materials.items():
            obj = bpy.data.objects[key]
            mat = bpy.data.materials.new(name=value)
            # 设置该材质使用节点
            mat.use_nodes = True
            # 创建一个新的Image纹理节点
            tex = mat.node_tree.nodes.new('ShaderNodeTexImage')
            tex.location = (-300, 300)
            new_name = value
            new_path = file_path.replace(file_path.split('\\')[-1], new_name)
            print(new_path)
            # 设置纹理图片路径
            tex.image = bpy.data.images.load(new_path)
            # 获取Diffuse BSDF节点
            bsdf = mat.node_tree.nodes.get('Principled BSDF')
            # 将Image纹理节点连接到Diffuse BSDF节点的Base Color输入
            mat.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            mat.node_tree.links.new(tex.outputs['Alpha'], bsdf.inputs['Alpha'])
            # 赋予材质
            obj.data.materials.append(mat)
            # 遍历所有物体
            for obj in bpy.data.objects:
                # 判断物体名称中是否含有 xform_0_material
                if "xform_0_material" in obj.name:
                    # 遍历该物体的材质
                    for mat_slot in obj.material_slots:
                        # 获取材质
                        mat = mat_slot.material
                        # 判断材质名称中是否含有序号
                        if re.search(r"\.\d+", mat.name):
                            # 替换材质名称为没有序号的名称
                            new_name = re.sub(r"\.\d+", "", mat.name)
                            mat_slot.material = bpy.data.materials[new_name]
            # 清理未使用的数据块
            bpy.ops.outliner.orphans_purge()
        return {"FINISHED"}


class SNA_OT_Operator020_173C4(bpy.types.Operator):
    bl_idname = "sna.operator020_173c4"
    bl_label = "Operator.020"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_DBE3D in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_DBE3D]
            bpy.ops.mesh.customdata_custom_splitnormals_clear('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator022_D211D(bpy.types.Operator):
    bl_idname = "sna.operator022_d211d"
    bl_label = "Operator.022"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_687B4 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_687B4]
            for i_3F2FD in range(len(bpy.context.active_object.data.shape_keys.animation_data.action.fcurves)-1,-1,-1):
                if (len(bpy.context.object.data.shape_keys.animation_data.action.fcurves[i_3F2FD].keyframe_points) == 1):
                    bpy.context.object.data.shape_keys.animation_data.action.fcurves.remove(fcurve=bpy.context.active_object.data.shape_keys.animation_data.action.fcurves[i_3F2FD], )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator023_9E188(bpy.types.Operator):
    bl_idname = "sna.operator023_9e188"
    bl_label = "Operator.023"
    bl_description = "清理形态键上的驱动器"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前选中的所有物体
        selected_objects = bpy.context.selected_objects
        # 遍历选中的物体
        for obj in selected_objects:
            # 检查对象是否有形态键
            if obj.data.shape_keys:
                # 遍历所有形态键
                for key_block in obj.data.shape_keys.key_blocks:
                    # 获取形态键的驱动器数据路径
                    data_path = 'key_blocks["{}"].value'.format(key_block.name)
                    # 尝试获取驱动器
                    driver = obj.data.shape_keys.animation_data.drivers.find(data_path)
                    # 如果驱动器存在，移除它
                    if driver:
                        obj.data.shape_keys.animation_data.drivers.remove(driver)
        print("完成对选中物体形态键驱动器的移除")
        # 更新视图，以便立即看到更改的效果
        bpy.context.view_layer.update()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator024_1Bdb7(bpy.types.Operator):
    bl_idname = "sna.operator024_1bdb7"
    bl_label = "Operator.024"
    bl_description = "清除选中物体材质中未使用的节点"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.IntProperty(name='深度', description='', default=1, subtype='NONE', min=1)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        x = self.sna_new_property

        def delete_unconnected_nodes(material):
            # 遍历材质中的所有节点
            for node in material.node_tree.nodes:
                # 跳过材质输出节点
                if node.type == 'OUTPUT_MATERIAL':
                    continue
                # 检查节点的每个输出是否连接到其他节点
                if all(output.is_linked == False for output in node.outputs):
                    # 删除未连接的节点
                    material.node_tree.nodes.remove(node)

        def main():
            # 确保有物体被选中
            if bpy.context.selected_objects:
                for obj in bpy.context.selected_objects:
                    # 确保物体有材质
                    if obj.data.materials:
                        for mat in obj.data.materials:
                            # 如果材质存在节点，则调用函数
                            if mat and mat.node_tree:
                                delete_unconnected_nodes(mat)
        # 调用主函数
        #x = 3 #删除深度
        for i in range(x):
            main()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator025_C68F6(bpy.types.Operator):
    bl_idname = "sna.operator025_c68f6"
    bl_label = "Operator.025"
    bl_description = "清除选中物体的骨骼修改器"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_A9AE5 in range(len(bpy.context.view_layer.objects.selected)):
            if (bpy.context.view_layer.objects.selected[i_A9AE5].type == 'MESH'):
                for i_02857 in range(len(bpy.context.view_layer.objects.selected[i_A9AE5].modifiers)):
                    print(bpy.context.view_layer.objects.selected[i_A9AE5].modifiers[i_02857].type)
                    if (bpy.context.view_layer.objects.selected[i_A9AE5].modifiers[i_02857].type == 'ARMATURE'):
                        bpy.context.view_layer.objects.selected[i_A9AE5].modifiers.remove(modifier=bpy.context.view_layer.objects.selected[i_A9AE5].modifiers[i_02857], )
                        break
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator002_Ac0A6(bpy.types.Operator):
    bl_idname = "sna.operator002_ac0a6"
    bl_label = "Operator.002"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_view_tex:
            bpy.context.scene.sna_view_tex = False
        else:
            bpy.context.scene.sna_view_tex = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_tool_header_FC05E(self, context):
    if not (False):
        layout = self.layout
        row_1F802 = layout.row(heading='', align=False)
        row_1F802.alert = False
        row_1F802.enabled = True
        row_1F802.active = True
        row_1F802.use_property_split = False
        row_1F802.use_property_decorate = False
        row_1F802.scale_x = 1.0
        row_1F802.scale_y = 1.0
        row_1F802.alignment = 'Center'.upper()
        row_1F802.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_1F802.prop(bpy.context.scene, 'sna_new_property_003', text=('中' if bpy.context.scene.sna_new_property_003 else '英'), icon_value=0, emboss=True)
        row_1F802.prop(bpy.context.scene, 'sna_view_tex', text='', icon_value=80, emboss=True)
        op = row_1F802.operator('outliner.orphans_purge', text='清理数据', icon_value=0, emboss=True, depress=False)


class SNA_OT_Operator001_1136E(bpy.types.Operator):
    bl_idname = "sna.operator001_1136e"
    bl_label = "Operator.001"
    bl_description = "选中相同材质的物体"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前场景
        scene = bpy.context.scene
        # 获取当前选中的物体
        active_obj = bpy.context.active_object
        # 检查是否有选中物体和它是否有材质
        if active_obj and active_obj.material_slots:
            # 获取选中物体的所有材质
            active_materials = set(slot.material for slot in active_obj.material_slots if slot.material)
            # 遍历场景中的所有物体
            for obj in scene.objects:
                # 只对网格物体进行操作
                if obj.type == 'MESH':
                    # 遍历物体的所有材质插槽
                    for slot in obj.material_slots:
                        # 如果物体使用了与选中物体相同的材质之一
                        if slot.material in active_materials:
                            # 选择物体
                            obj.select_set(True)
                            # 一旦找到匹配的材质，无需检查其余材质
                            break
        else:
            print("No active mesh object with materials selected.")
        # 更新视图层以反映物体的选择变化
        bpy.context.view_layer.update()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_5Ed64(bpy.types.Operator):
    bl_idname = "sna.operator_5ed64"
    bl_label = "Operator"
    bl_description = "在材质编辑器中选择一个贴图节点，就选中相同使用了这张贴图的物体"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import bpy
        # 此函数用于在Blender中显示提示信息

        def show_message_box(message = "", title = "Message Box", icon = 'INFO'):

            def draw(self, context):
                self.layout.label(text=message)
            bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)
        # 使用示例
        show_message_box("未选中纹理节点", "提示", 'ERROR')
        # 初始化变量
        selected_image = None
        node_editor = None
        # 尝试获取当前节点编辑器的上下文
        for area in bpy.context.screen.areas:
            if area.type == 'NODE_EDITOR':
                node_editor = area.spaces.active
                break
        # 如果找到节点编辑器
        if node_editor and node_editor.tree_type == 'ShaderNodeTree' and node_editor.edit_tree:
            # 获取选中的节点
            selected_nodes = [node for node in node_editor.edit_tree.nodes if node.select and node.type == 'TEX_IMAGE']
            # 如果选中了纹理节点，获取它的图像数据
            if selected_nodes:
                selected_image = selected_nodes[0].image
            else:
                show_message_box("未选中纹理节点", "提示", 'ERROR')
        # 如果有选中的纹理
        if selected_image:
            # 遍历所有物体
            for obj in bpy.data.objects:
                # 只检查具有材质的网格物体
                if obj.type == 'MESH' and obj.material_slots:
                    # 遍历所有材质插槽
                    for slot in obj.material_slots:
                        if slot.material and slot.material.use_nodes:
                            # 遍历所有材质节点
                            for node in slot.material.node_tree.nodes:
                                if node.type == 'TEX_IMAGE' and node.image == selected_image:
                                    # 如果该材质使用了选中的纹理，选中物体
                                    obj.select_set(True)
                                    break  # 跳出节点循环
        else:
            print("No texture node selected in the active Node Editor.")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_400A9(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_400a9"
    bl_label = "选中骨架"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_new_property_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property: bpy.props.EnumProperty(name='选择', description='', items=[('腿ik骨', '腿ik骨', '', 0, 0), ('全部身体骨', '全部身体骨', '', 0, 1), ('身体骨', '身体骨', '', 0, 2), ('手骨', '手骨', '', 0, 3), ('调整骨', '调整骨', '', 0, 4), ('d骨', 'd骨', '', 0, 5), ('捩骨', '捩骨', '', 0, 6)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_new_property == "全部身体骨":
            for i_30AF0 in range(len(['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'])):
                bpy.ops.object.select_pattern(pattern=['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'][i_30AF0])
            for i_FCA08 in range(len(['下半身', '上半身2', '上半身', '上半身3', '首', '頭', '肩.R', '肩.L', '腕.R', '腕.L', 'ひじ.R', 'ひじ.L', '手首.R', '手首.L'])):
                bpy.ops.object.select_pattern(pattern=['下半身', '上半身2', '上半身', '上半身3', '首', '頭', '肩.R', '肩.L', '腕.R', '腕.L', 'ひじ.R', 'ひじ.L', '手首.R', '手首.L'][i_FCA08])
            for i_AA1B7 in range(len(['親指０.R', '親指１.R', '親指２.R', '人指０.R', '人指１.R', '人指２.R', '人指３.R', '中指０.R', '中指１.R', '中指２.R', '中指３.R', '薬指０.R', '薬指１.R', '薬指２.R', '薬指３.R', '小指０.R', '小指１.R', '小指２.R', '小指３.R'])):
                bpy.ops.object.select_pattern(pattern=['親指０.R', '親指１.R', '親指２.R', '人指０.R', '人指１.R', '人指２.R', '人指３.R', '中指０.R', '中指１.R', '中指２.R', '中指３.R', '薬指０.R', '薬指１.R', '薬指２.R', '薬指３.R', '小指０.R', '小指１.R', '小指２.R', '小指３.R'][i_AA1B7])
            for i_844DC in range(len(['親指０.L', '親指１.L', '親指２.L', '人指０.L', '人指１.L', '人指２.L', '人指３.L', '中指０.L', '中指１.L', '中指２.L', '中指３.L', '薬指０.L', '薬指１.L', '薬指２.L', '薬指３.L', '小指０.L', '小指１.L', '小指２.L', '小指３.L'])):
                bpy.ops.object.select_pattern(pattern=['親指０.L', '親指１.L', '親指２.L', '人指０.L', '人指１.L', '人指２.L', '人指３.L', '中指０.L', '中指１.L', '中指２.L', '中指３.L', '薬指０.L', '薬指１.L', '薬指２.L', '薬指３.L', '小指０.L', '小指１.L', '小指２.L', '小指３.L'][i_844DC])
        elif self.sna_new_property == "身体骨":
            for i_1B62D in range(len(['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'])):
                bpy.ops.object.select_pattern(pattern=['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'][i_1B62D])
            for i_EFC29 in range(len(['下半身', '上半身2', '上半身', '上半身3', '首', '頭', '肩.R', '肩.L', '腕.R', '腕.L', 'ひじ.R', 'ひじ.L', '手首.R', '手首.L'])):
                bpy.ops.object.select_pattern(pattern=['下半身', '上半身2', '上半身', '上半身3', '首', '頭', '肩.R', '肩.L', '腕.R', '腕.L', 'ひじ.R', 'ひじ.L', '手首.R', '手首.L'][i_EFC29])
        elif self.sna_new_property == "腿ik骨":
            for i_FA29C in range(len(['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'])):
                bpy.ops.object.select_pattern(pattern=['足.L', 'ひざ.L', '足首.L', '足先EX.L', '足.R', 'ひざ.R', '足首.R', '足先EX.R'][i_FA29C])
        elif self.sna_new_property == "手骨":
            for i_256E3 in range(len(['親指０.R', '親指１.R', '親指２.R', '人指０.R', '人指１.R', '人指２.R', '人指３.R', '中指０.R', '中指１.R', '中指２.R', '中指３.R', '薬指０.R', '薬指１.R', '薬指２.R', '薬指３.R', '小指０.R', '小指１.R', '小指２.R', '小指３.R'])):
                bpy.ops.object.select_pattern(pattern=['親指０.R', '親指１.R', '親指２.R', '人指０.R', '人指１.R', '人指２.R', '人指３.R', '中指０.R', '中指１.R', '中指２.R', '中指３.R', '薬指０.R', '薬指１.R', '薬指２.R', '薬指３.R', '小指０.R', '小指１.R', '小指２.R', '小指３.R'][i_256E3])
            for i_6EC5E in range(len(['親指０.L', '親指１.L', '親指２.L', '人指０.L', '人指１.L', '人指２.L', '人指３.L', '中指０.L', '中指１.L', '中指２.L', '中指３.L', '薬指０.L', '薬指１.L', '薬指２.L', '薬指３.L', '小指０.L', '小指１.L', '小指２.L', '小指３.L'])):
                bpy.ops.object.select_pattern(pattern=['親指０.L', '親指１.L', '親指２.L', '人指０.L', '人指１.L', '人指２.L', '人指３.L', '中指０.L', '中指１.L', '中指２.L', '中指３.L', '薬指０.L', '薬指１.L', '薬指２.L', '薬指３.L', '小指０.L', '小指１.L', '小指２.L', '小指３.L'][i_6EC5E])
        elif self.sna_new_property == "调整骨":
            bpy.ops.object.select_pattern(pattern='*調整*', extend=True)
        elif self.sna_new_property == "d骨":
            for i_A62E2 in range(len(['足D.L', 'ひざD.L', '足首D.L', '足D.R', 'ひざD.R', '足首D.R'])):
                bpy.ops.object.select_pattern(pattern=['足D.L', 'ひざD.L', '足首D.L', '足D.R', 'ひざD.R', '足首D.R'][i_A62E2])
        elif self.sna_new_property == "捩骨":
            bpy.ops.object.select_pattern(pattern='*捩*', extend=True)
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_E6Bd2(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_e6bd2"
    bl_label = "添加顶点色属性"
    bl_description = "为选中的物体添加顶点色"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.StringProperty(name='顶点色名称', description='', default='顶点色', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_tree_001['sna_old_active_objects'] = bpy.context.view_layer.objects.active.name
        for i_58412 in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_58412]
            bpy.ops.geometry.color_attribute_add(name=self.sna_new_property, domain='POINT', data_type='FLOAT_COLOR', color=(0.0, 0.0, 0.0, 1.0))
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[node_tree_001['sna_old_active_objects']]
            self.report({'INFO'}, message='已添加顶点色')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_E9B48(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_e9b48"
    bl_label = "移除顶点色属性"
    bl_description = "移除选中物体指定名称的顶点色，如果为空则移除最后一个"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.StringProperty(name='删除名称', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_tree_001['sna_old_active_objects'] = bpy.context.view_layer.objects.active.name
        for i_76711 in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_76711]
            if (len(bpy.context.view_layer.objects.active.data.color_attributes) != 0):
                for i_9755E in range(len(bpy.context.view_layer.objects.active.data.color_attributes)-1,-1,-1):
                    if (self.sna_new_property == bpy.context.view_layer.objects.active.data.color_attributes[i_9755E].name):
                        bpy.context.view_layer.objects.active.data.color_attributes.active_color = bpy.context.view_layer.objects.active.data.color_attributes[i_9755E]
                        bpy.ops.geometry.color_attribute_remove('INVOKE_DEFAULT', )
                        bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[node_tree_001['sna_old_active_objects']]
                        self.report({'INFO'}, message='已移除指定名称顶点色')
                if (self.sna_new_property == ''):
                    bpy.context.view_layer.objects.active.data.color_attributes.active_color = bpy.context.view_layer.objects.active.data.color_attributes[int(len(bpy.context.view_layer.objects.active.data.color_attributes) - 1.0)]
                    bpy.ops.geometry.color_attribute_remove('INVOKE_DEFAULT', )
                    bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[node_tree_001['sna_old_active_objects']]
                    self.report({'INFO'}, message='已移除最后一个顶点色')
            else:
                bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[node_tree_001['sna_old_active_objects']]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_outliner_ht_header_1E9B6(self, context):
    if not (False):
        layout = self.layout


class SNA_OT_My_Generic_Operator_Cf418(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_cf418"
    bl_label = "切换物体渲染显示模式"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_02C32 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
            if bpy.context.scene.sna_disable_keyframe_switch:
                success_F1E52 = bpy.context.view_layer.objects.selected[i_02C32].keyframe_insert(data_path='hide_render', )
                bpy.context.scene.frame_current = int(bpy.context.scene.frame_current + 1.0)
                bpy.context.view_layer.objects.selected[i_02C32].hide_render = (not bpy.context.view_layer.objects.selected[i_02C32].hide_render)
                success_4CBE0 = bpy.context.view_layer.objects.selected[i_02C32].keyframe_insert(data_path='hide_render', )
                bpy.context.scene.frame_current = int(bpy.context.scene.frame_current - 1.0)
            else:
                bpy.context.view_layer.objects.selected[i_02C32].hide_render = (not bpy.context.view_layer.objects.selected[i_02C32].hide_render)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_98B5F(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_98b5f"
    bl_label = "根据渲染是否显示设置视图"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_FAB97 in range(len(bpy.context.view_layer.objects.selected)-1,-1,-1):
            if bpy.context.scene.sna_disable_keyframe_switch:
                success_45A3C = bpy.context.view_layer.objects.selected[i_FAB97].keyframe_insert(data_path='hide_viewport', )
                bpy.context.scene.frame_current = int(bpy.context.scene.frame_current + 1.0)
                bpy.context.view_layer.objects.selected[i_FAB97].hide_viewport = (not bpy.context.view_layer.objects.selected[i_FAB97].hide_viewport)
                success_6370B = bpy.context.view_layer.objects.selected[i_FAB97].keyframe_insert(data_path='hide_viewport', )
                bpy.context.scene.frame_current = int(bpy.context.scene.frame_current - 1.0)
                self.report({'INFO'}, message='只对关闭有效')
            else:
                bpy.context.view_layer.objects.selected[i_FAB97].hide_viewport = (not bpy.context.view_layer.objects.selected[i_FAB97].hide_viewport)
                self.report({'INFO'}, message='只对关闭有效')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_object_pt_constraints_25BA8(self, context):
    if not (False):
        layout = self.layout
        col_24E34 = layout.column(heading='', align=False)
        col_24E34.alert = False
        col_24E34.enabled = True
        col_24E34.active = True
        col_24E34.use_property_split = False
        col_24E34.use_property_decorate = False
        col_24E34.scale_x = 1.0
        col_24E34.scale_y = 1.0
        col_24E34.alignment = 'Expand'.upper()
        col_24E34.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_D8E68 = col_24E34.row(heading='', align=True)
        row_D8E68.alert = bpy.context.scene.sna_remove_transform_constraint
        row_D8E68.enabled = True
        row_D8E68.active = True
        row_D8E68.use_property_split = False
        row_D8E68.use_property_decorate = False
        row_D8E68.scale_x = 1.0
        row_D8E68.scale_y = 1.0
        row_D8E68.alignment = 'Expand'.upper()
        row_D8E68.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_D8E68.prop(bpy.context.scene, 'sna_remove_transform_constraint', text='', icon_value=21, emboss=True)
        op = row_D8E68.operator('sna.my_generic_operator_cde4f', text='位置变换约束', icon_value=424, emboss=True, depress=False)
        op = row_D8E68.operator('sna.my_generic_operator_2b24e', text='旋转变换约束', icon_value=425, emboss=True, depress=False)


class SNA_OT_My_Generic_Operator_Cde4F(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_cde4f"
    bl_label = "添加位置变换约束"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_remove_transform_constraint:
            if (len(bpy.context.view_layer.objects.selected) == 0):
                self.report({'INFO'}, message='没有选中物体')
            else:
                for i_11CEA in range(len(bpy.context.view_layer.objects.selected)):
                    if (len(bpy.context.view_layer.objects.selected[i_11CEA].constraints) == 0):
                        self.report({'INFO'}, message='没有找到约束')
                    else:
                        for i_9C95C in range(len(bpy.context.view_layer.objects.selected[i_11CEA].constraints)):
                            if '变换位置' in bpy.context.view_layer.objects.selected[i_11CEA].constraints[i_9C95C].name:
                                bpy.context.view_layer.objects.selected[i_11CEA].constraints.remove(constraint=bpy.context.view_layer.objects.selected[i_11CEA].constraints[i_9C95C], )
                                self.report({'INFO'}, message='移除了一个位置变换约束')
                                break
                            else:
                                self.report({'INFO'}, message='没有找到位置变换约束')
        else:
            if (len(bpy.context.view_layer.objects.selected) == 0):
                self.report({'INFO'}, message='没有选中物体')
            else:
                for i_73428 in range(len(bpy.context.view_layer.objects.selected)):
                    constraint_5341E = bpy.context.view_layer.objects.selected[i_73428].constraints.new(type='TRANSFORM', )
                    constraint_5341E.name = '变换位置'
                    constraint_5341E.from_max_x = 100.0
                    constraint_5341E.from_min_x = float(100.0 * -1.0)
                    constraint_5341E.from_max_y = 100.0
                    constraint_5341E.from_min_y = float(100.0 * -1.0)
                    constraint_5341E.from_max_z = 100.0
                    constraint_5341E.from_min_z = float(100.0 * -1.0)
                    constraint_5341E.to_max_x = 100.0
                    constraint_5341E.to_min_x = float(100.0 * -1.0)
                    constraint_5341E.to_max_y = 100.0
                    constraint_5341E.to_min_y = float(100.0 * -1.0)
                    constraint_5341E.to_max_z = 100.0
                    constraint_5341E.to_min_z = float(100.0 * -1.0)
                    self.report({'INFO'}, message='已添加位置变换约束')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_2B24E(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_2b24e"
    bl_label = "添加旋转变换约束"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_remove_transform_constraint:
            if (len(bpy.context.view_layer.objects.selected) == 0):
                self.report({'INFO'}, message='没有选中物体')
            else:
                for i_37FC5 in range(len(bpy.context.view_layer.objects.selected)):
                    if (len(bpy.context.view_layer.objects.selected[i_37FC5].constraints) == 0):
                        self.report({'INFO'}, message='没有找到约束')
                    else:
                        for i_6D01C in range(len(bpy.context.view_layer.objects.selected[i_37FC5].constraints)):
                            if '变换旋转' in bpy.context.view_layer.objects.selected[i_37FC5].constraints[i_6D01C].name:
                                bpy.context.view_layer.objects.selected[i_37FC5].constraints.remove(constraint=bpy.context.view_layer.objects.selected[i_37FC5].constraints[i_6D01C], )
                                self.report({'INFO'}, message='移除了一个旋转变换约束')
                                break
                            else:
                                self.report({'INFO'}, message='没有找到旋转变换约束')
        else:
            if (len(bpy.context.view_layer.objects.selected) == 0):
                self.report({'INFO'}, message='没有选中物体')
            else:
                for i_00AAE in range(len(bpy.context.view_layer.objects.selected)):
                    constraint_C50CC = bpy.context.view_layer.objects.selected[i_00AAE].constraints.new(type='TRANSFORM', )
                    constraint_C50CC.name = '变换旋转'
                    constraint_C50CC.map_from = 'ROTATION'
                    constraint_C50CC.map_to = 'ROTATION'
                    constraint_C50CC.from_max_x_rot = 3.1415927410125732
                    constraint_C50CC.from_min_x_rot = float(3.1415927410125732 * -1.0)
                    constraint_C50CC.from_max_y_rot = 3.1415927410125732
                    constraint_C50CC.from_min_y_rot = float(3.1415927410125732 * -1.0)
                    constraint_C50CC.from_max_z_rot = 3.1415927410125732
                    constraint_C50CC.from_min_z_rot = float(3.1415927410125732 * -1.0)
                    constraint_C50CC.to_max_x_rot = 3.1415927410125732
                    constraint_C50CC.to_min_x_rot = float(3.1415927410125732 * -1.0)
                    constraint_C50CC.to_max_y_rot = 3.1415927410125732
                    constraint_C50CC.to_min_y_rot = float(3.1415927410125732 * -1.0)
                    constraint_C50CC.to_max_z_rot = 3.1415927410125732
                    constraint_C50CC.to_min_z_rot = float(3.1415927410125732 * -1.0)
                    self.report({'INFO'}, message='已添加旋转变换约束')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_editor_menus_F6DBF(self, context):
    if not (False):
        layout = self.layout


class SNA_PT_panel_A0042(bpy.types.Panel):
    bl_label = '显示点编号设置'
    bl_idname = 'SNA_PT_panel_A0042'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = '显示点编号设置'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene, 'sna_display_ver_color', text='颜色', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_display_ver_size', text='字体大小', icon_value=0, emboss=True)


class SNA_OT_Operator_5F6B3(bpy.types.Operator):
    bl_idname = "sna.operator_5f6b3"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_display_ver_id:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Uv_94B57(bpy.types.Operator):
    bl_idname = "sna.uv_94b57"
    bl_label = "移除位置uv"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_EE5B8 in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_EE5B8]
            bpy.context.view_layer.objects.active.data.uv_layers.active = bpy.context.view_layer.objects.active.data.uv_layers[int(len(bpy.context.view_layer.objects.active.data.uv_layers) - 1.0)]
            if 'pos' in bpy.context.view_layer.objects.active.data.uv_layers.active.name:
                bpy.ops.mesh.uv_texture_remove('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Uv_9201E(bpy.types.Operator):
    bl_idname = "sna.uv_9201e"
    bl_label = "生成视图uv"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_new_property_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property: bpy.props.EnumProperty(name='视图方向', description='', items=[('FRONT', 'FRONT', '', 0, 0), ('LEFT', 'LEFT', '', 0, 1), ('TOP', 'TOP', '', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_7227A in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_7227A]
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.view3d.view_axis('INVOKE_DEFAULT', type=self.sna_new_property)
            bpy.ops.mesh.select_all('INVOKE_DEFAULT', action='SELECT')
            bpy.ops.mesh.uv_texture_add('INVOKE_DEFAULT', )
            bpy.context.view_layer.objects.active.data.uv_layers[int(len(bpy.context.view_layer.objects.active.data.uv_layers) - 1.0)].name = 'pos_' + self.sna_new_property
            bpy.context.view_layer.objects.active.data.uv_layers.active = bpy.context.view_layer.objects.active.data.uv_layers[int(len(bpy.context.view_layer.objects.active.data.uv_layers) - 1.0)]
        bpy.ops.uv.project_from_view('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_Bedaf(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_bedaf"
    bl_label = "材质到物体"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_73298 in range(len(bpy.context.view_layer.objects.selected)):
            if (property_exists("bpy.context.view_layer.objects.selected[i_73298].data.materials", globals(), locals()) and len(bpy.context.view_layer.objects.selected[i_73298].data.materials) > 0):
                bpy.context.view_layer.objects.selected[i_73298].name = bpy.context.view_layer.objects.selected[i_73298].data.materials[0].name
            else:
                self.report({'INFO'}, message=bpy.context.view_layer.objects.selected[i_73298].name + '没有材质')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_04Cf5(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_04cf5"
    bl_label = "物体到材质"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_E1144 in range(len(bpy.context.view_layer.objects.selected)):
            if (property_exists("bpy.context.view_layer.objects.selected[i_E1144].data.materials", globals(), locals()) and len(bpy.context.view_layer.objects.selected[i_E1144].data.materials) > 0):
                bpy.context.view_layer.objects.selected[i_E1144].data.materials[0].name = bpy.context.view_layer.objects.selected[i_E1144].name
            else:
                self.report({'INFO'}, message=bpy.context.view_layer.objects.selected[i_E1144].name + '没有材质')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_60634(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_60634"
    bl_label = "贴图到材质"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_F171C in range(len(bpy.context.view_layer.objects.selected)):
            if (property_exists("bpy.context.view_layer.objects.selected[i_F171C].data.materials", globals(), locals()) and len(bpy.context.view_layer.objects.selected[i_F171C].data.materials) > 0):
                for i_000DB in range(len(bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes)):
                    if (bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB].type == 'TEX_IMAGE'):
                        for i_E8F57 in range(len(bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB].id_data.links)):
                            for i_85594 in range(len(['Color', 'Base Color', 'Diffuse Color', 'Albedo', 'Base Tex'])):
                                if ((bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB].id_data.links[i_E8F57].to_socket.name == ['Color', 'Base Color', 'Diffuse Color', 'Albedo', 'Base Tex'][i_85594]) and (bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB].id_data.links[i_E8F57].from_node == bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB])):
                                    bpy.context.view_layer.objects.selected[i_F171C].name = bpy.context.view_layer.objects.selected[i_F171C].data.materials[0].node_tree.nodes[i_000DB].image.name
            else:
                self.report({'INFO'}, message=bpy.context.view_layer.objects.selected[i_F171C].name + '没有材质')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_B74Af(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_b74af"
    bl_label = "匹配色彩空间"
    bl_description = "匹配选中物体材质基础色贴图的色彩空间"
    bl_options = {"REGISTER", "UNDO"}

    def sna_new_property_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property: bpy.props.EnumProperty(name='匹配物体', description='', items=[('仅选中', '仅选中', '', 0, 0), ('所有物体', '所有物体', '', 0, 1)])

    def sna_new_property_001_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property_001: bpy.props.EnumProperty(name='匹配贴图', description='', items=[('仅基础色贴图', '仅基础色贴图', '', 0, 0), ('所有贴图', '所有贴图', '', 0, 1)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_FA792 in range(len((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected))):
            if ((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].type == 'MESH'):
                if (property_exists("(bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials", globals(), locals()) and len((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials) > 0):
                    for i_D75EA in range(len((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials)):
                        for i_AA6AB in range(len((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes)):
                            if ((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB].type == 'TEX_IMAGE'):
                                if (self.sna_new_property_001 == '所有贴图'):
                                    if ((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB].image != None):
                                        is_other_color_space_0_a4077 = sna_execute_FC79C((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB])
                                        if is_other_color_space_0_a4077:
                                            self.report({'WARNING'}, message='未找到对应贴图的色彩空间')
                                        else:
                                            self.report({'INFO'}, message='成功匹配色彩空间')
                                else:
                                    for i_CE2BF in range(len((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB].id_data.links)):
                                        for i_42755 in range(len(['Color', 'Base Color', 'Diffuse Color', 'Albedo', 'Base Tex'])):
                                            if (((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB].id_data.links[i_CE2BF].to_socket.name == ['Color', 'Base Color', 'Diffuse Color', 'Albedo', 'Base Tex'][i_42755]) and ((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB].id_data.links[i_CE2BF].from_node == (bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB])):
                                                is_other_color_space_0_f9006 = sna_execute_FC79C((bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].data.materials[i_D75EA].node_tree.nodes[i_AA6AB])
                                                if is_other_color_space_0_f9006:
                                                    self.report({'WARNING'}, message='未找到对应贴图的色彩空间')
                                                else:
                                                    self.report({'INFO'}, message='成功匹配色彩空间')
                else:
                    self.report({'INFO'}, message=(bpy.context.view_layer.objects if (self.sna_new_property == '所有物体') else bpy.context.view_layer.objects.selected)[i_FA792].name + '没有材质')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_execute_FC79C(node):
    node_tree_004['sna_is_other_color_space'] = False
    if bpy.context.scene.view_settings.view_transform == "Filmic":
        node.image.colorspace_settings.name = 'Filmic sRGB'
    elif bpy.context.scene.view_settings.view_transform == "Standard":
        node.image.colorspace_settings.name = 'sRGB'
    elif bpy.context.scene.view_settings.view_transform == "AgX":
        node.image.colorspace_settings.name = 'AgX Base sRGB'
    else:
        node_tree_004['sna_is_other_color_space'] = True
    return node_tree_004['sna_is_other_color_space']


class SNA_OT_Down_25Ee0(bpy.types.Operator):
    bl_idname = "sna.down_25ee0"
    bl_label = "down"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (float(len(bpy.context.scene.sna_render_list) - 1.0) == bpy.context.scene.sna_id):
            pass
        else:
            bpy.context.scene.sna_render_list.move(bpy.context.scene.sna_id, int(bpy.context.scene.sna_id + 1.0))
            item_CA05D = bpy.context.scene.sna_render_list[int(bpy.context.scene.sna_id + 1.0)]
            bpy.context.scene.sna_id = int(bpy.context.scene.sna_id + 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Up_B66Ca(bpy.types.Operator):
    bl_idname = "sna.up_b66ca"
    bl_label = "up"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_id == 0):
            pass
        else:
            bpy.context.scene.sna_render_list.move(bpy.context.scene.sna_id, int(bpy.context.scene.sna_id - 1.0))
            item_BA94F = bpy.context.scene.sna_render_list[int(bpy.context.scene.sna_id - 1.0)]
            bpy.context.scene.sna_id = int(bpy.context.scene.sna_id - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Render_List_84292(bpy.types.Operator):
    bl_idname = "sna.add_render_list_84292"
    bl_label = "add_render_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_D5070 = bpy.context.scene.sna_render_list.add()
        item_D5070.name = '渲染任务' + str(len(bpy.context.scene.sna_render_list))
        item_D5070.start_frame = bpy.context.scene.frame_start
        item_D5070.end_frame = bpy.context.scene.frame_end
        bpy.context.scene.sna_id = int(len(bpy.context.scene.sna_render_list) - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Render_List_E8059(bpy.types.Operator):
    bl_idname = "sna.remove_render_list_e8059"
    bl_label = "remove_render_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (int(len(bpy.context.scene.sna_render_list) - 1.0) == bpy.context.scene.sna_id):
            if len(bpy.context.scene.sna_render_list) > bpy.context.scene.sna_id:
                bpy.context.scene.sna_render_list.remove(bpy.context.scene.sna_id)
            bpy.context.scene.sna_id = int(len(bpy.context.scene.sna_render_list) - 1.0)
        else:
            if len(bpy.context.scene.sna_render_list) > bpy.context.scene.sna_id:
                bpy.context.scene.sna_render_list.remove(bpy.context.scene.sna_id)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_5874F(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_5874f"
    bl_label = "渲染"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sna.operator_cc77e('INVOKE_DEFAULT', )
        bpy.ops.sna.my_generic_operator_33f13('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_complete_handler_825EB(dummy):
    bpy.context.scene.sna_id = int(bpy.context.scene.sna_id + 1.0)
    for i_D5DFF in range(len(bpy.context.scene.sna_render_list)):
        if (bpy.context.scene.sna_render_list[i_D5DFF].on and (i_D5DFF >= bpy.context.scene.sna_id)):
            bpy.context.scene.sna_id = i_D5DFF
            break

    def delayed_3D3B7():
        bpy.context.scene.sna_is_render = False
        if bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].on:
            bpy.context.scene.frame_start = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].start_frame
            bpy.context.scene.frame_end = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].end_frame
            bpy.context.scene.camera = (bpy.data.objects[node_tree_001['sna_default_camera']] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera == None) else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera)
            bpy.context.scene.render.filepath = (node_tree_001['sna_default_output_directory'] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory == '') else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory)
            bpy.context.scene.sna_is_render = True
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True, use_viewport=True)
        else:

            def delayed_C1A0C():
                bpy.context.scene.frame_start = node_tree_001['sna_default_frame_start']
                bpy.context.scene.frame_end = node_tree_001['sna_default_frame_end']
                bpy.context.scene.camera = bpy.context.view_layer.objects[node_tree_001['sna_default_camera']]

                def delayed_F65CF():
                    bpy.context.scene.render.filepath = node_tree_001['sna_default_output_directory']
                    bpy.context.scene.sna_time.clear()
                    bpy.context.scene.sna_is_render = False
                bpy.app.timers.register(delayed_F65CF, first_interval=0.5)
            bpy.app.timers.register(delayed_C1A0C, first_interval=1.0)
    bpy.app.timers.register(delayed_3D3B7, first_interval=0.30000001192092896)


@persistent
def render_complete_handler_C420C(dummy):
    pass


class SNA_OT_My_Generic_Operator_33F13(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_33f13"
    bl_label = "开始渲染"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_tree_001['sna_default_frame_start'] = bpy.context.scene.frame_start
        node_tree_001['sna_default_frame_end'] = bpy.context.scene.frame_end
        node_tree_001['sna_default_camera'] = bpy.context.scene.camera.name
        node_tree_001['sna_default_output_directory'] = bpy.context.scene.render.filepath
        for i_ACDF3 in range(len(bpy.context.scene.sna_render_list)):
            if bpy.context.scene.sna_render_list[i_ACDF3].on:
                print(str(i_ACDF3))
                bpy.context.scene.sna_id = i_ACDF3
                break
        bpy.context.scene.frame_start = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].start_frame
        bpy.context.scene.frame_end = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].end_frame
        bpy.context.scene.camera = (bpy.context.scene.camera if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera == None) else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera)
        bpy.context.scene.render.filepath = (node_tree_001['sna_default_output_directory'] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory == '') else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory)
        bpy.context.scene.sna_is_render = True
        bpy.ops.render.render('INVOKE_DEFAULT', animation=True, use_viewport=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_cancel_handler_58683(dummy):
    bpy.context.scene.sna_is_render = False


@persistent
def render_post_handler_4E079(dummy):
    if (bpy.context.scene.sna_render_list[len(bpy.context.scene.sna_render_list)].end_frame == bpy.context.scene.frame_current):
        bpy.context.scene.sna_is_render = False


@persistent
def render_pre_handler_1092E(dummy):
    if (len(bpy.context.scene.sna_time) >= 6):
        if len(bpy.context.scene.sna_time) > 0:
            bpy.context.scene.sna_time.remove(0)
        item_D9314 = bpy.context.scene.sna_time.add()
        item_D9314.frame_start_time = round(float(int(datetime.now().time().hour * 3600.0) + float(int(datetime.now().time().minute * 60.0) + float(datetime.now().time().second + float(datetime.now().time().microsecond//1000 / 1000.0)))), abs(2))
        item_D9314.frame_time = (0 if (len(bpy.context.scene.sna_time) <= 1) else round(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_start_time - (0 if (len(bpy.context.scene.sna_time) <= 1) else bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 2.0)].frame_start_time)), abs(2)))
    else:
        item_F5BA6 = bpy.context.scene.sna_time.add()
        item_F5BA6.frame_start_time = round(float(int(datetime.now().time().hour * 3600.0) + float(int(datetime.now().time().minute * 60.0) + float(datetime.now().time().second + float(datetime.now().time().microsecond//1000 / 1000.0)))), abs(2))
        item_F5BA6.frame_time = (0 if (len(bpy.context.scene.sna_time) <= 1) else round(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_start_time - (0 if (len(bpy.context.scene.sna_time) <= 1) else bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 2.0)].frame_start_time)), abs(2)))


@persistent
def render_post_handler_15713(dummy):
    node_tree_001['sna_sub_render_time'] = round((float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_time + node_tree_001['sna_sub_render_time']) if (len(bpy.context.scene.sna_time) == 1) else float(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_time + node_tree_001['sna_sub_render_time']) - bpy.context.scene.sna_time[0].frame_time)), abs(2))
    node_tree_001['sna_avg_render_time'] = round(float(node_tree_001['sna_sub_render_time'] / (int(len(bpy.context.scene.sna_time) - 1.0) if (len(bpy.context.scene.sna_time) <= 5) else int(len(bpy.context.scene.sna_time) - 1.0))), abs(2))


class SNA_OT_Operator_Cc77E(bpy.types.Operator):
    bl_idname = "sna.operator_cc77e"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_E2ECF in range(len(bpy.context.scene.sna_render_list)):
            node_tree_001['sna_sub_frame'] = (int(int(int(bpy.context.scene.sna_render_list[i_E2ECF].end_frame - bpy.context.scene.sna_render_list[i_E2ECF].start_frame) + 1.0) + node_tree_001['sna_sub_frame']) if bpy.context.scene.sna_render_list[i_E2ECF].on else node_tree_001['sna_sub_frame'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_post_handler_B2801(dummy):
    node_tree_001['sna_current_frame'] = int(node_tree_001['sna_current_frame'] + 1.0)


class SNA_OT_Add_Obj_List_6C8D9(bpy.types.Operator):
    bl_idname = "sna.add_obj_list_6c8d9"
    bl_label = "add_obj_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_D2599 = bpy.context.scene.sna_obj_list.add()
        item_D2599.name = '物体组' + str(len(bpy.context.scene.sna_obj_list))
        bpy.context.scene.sna_obj_list_id = int(len(bpy.context.scene.sna_obj_list) - 1.0)
        bpy.ops.sna.my_generic_operator_72cae('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_72Cae(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_72cae"
    bl_label = "指定"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_761DE in range(len(bpy.context.view_layer.objects.selected)):
            if (len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected) == 0):
                item_E3792 = bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.add()
                item_E3792.obj_list_pointer_property = bpy.context.view_layer.objects.selected[i_761DE]
            else:
                for i_157FD in range(len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected)):
                    if (bpy.context.view_layer.objects.selected[i_761DE] == bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_157FD].obj_list_pointer_property):
                        self.report({'WARNING'}, message=bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_157FD].name + '已在物体组中')
                        break
                if (bpy.context.view_layer.objects.selected[i_761DE] == bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_157FD].obj_list_pointer_property):
                    pass
                else:
                    item_7098B = bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.add()
                    item_7098B.obj_list_pointer_property = bpy.context.view_layer.objects.selected[i_761DE]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_C6C4F(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_c6c4f"
    bl_label = "清空"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.clear()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Obj_List_Pointer_3Ad57(bpy.types.Operator):
    bl_idname = "sna.add_obj_list_pointer_3ad57"
    bl_label = "add_obj_list_pointer"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_4DC8B = bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.add()
        bpy.context.scene.sna_obj_list_pointer_id = int(len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected) - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_1632D(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_1632d"
    bl_label = "选择"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_E3467 in range(len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected)):
            if (bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_E3467].obj_list_pointer_property == None):
                pass
            else:
                bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_E3467].obj_list_pointer_property.select = True
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_F1Fff(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_f1fff"
    bl_label = "移除所选"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_9DC6E in range(len(bpy.context.view_layer.objects.selected)):
            for i_E9422 in range(len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected)-1,-1,-1):
                if (bpy.context.view_layer.objects.selected[i_9DC6E] == bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_E9422].obj_list_pointer_property):
                    for i_2CFF3 in range(len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected)):
                        if bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_2CFF3] == bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected[i_E9422]:
                            bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.remove(i_2CFF3)
                            break
                    self.report({'INFO'}, message='已从物体组中移除所选物体')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Obj_List_Pointer_75A67(bpy.types.Operator):
    bl_idname = "sna.remove_obj_list_pointer_75a67"
    bl_label = "remove_obj_list_pointer"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_obj_list_pointer_id == 0):
            if len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected) > bpy.context.scene.sna_obj_list_pointer_id:
                bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.remove(bpy.context.scene.sna_obj_list_pointer_id)
            bpy.context.scene.sna_obj_list_pointer_id = 0
        else:
            if len(bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected) > bpy.context.scene.sna_obj_list_pointer_id:
                bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id].selected.remove(bpy.context.scene.sna_obj_list_pointer_id)
            bpy.context.scene.sna_obj_list_pointer_id = int(bpy.context.scene.sna_obj_list_pointer_id - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Obj_List_063B1(bpy.types.Operator):
    bl_idname = "sna.remove_obj_list_063b1"
    bl_label = "remove_obj_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (len(bpy.context.scene.sna_obj_list) == 1):
            bpy.context.scene.sna_obj_list.clear()
        else:
            if (bpy.context.scene.sna_obj_list_id == 0):
                if len(bpy.context.scene.sna_obj_list) > bpy.context.scene.sna_obj_list_id:
                    bpy.context.scene.sna_obj_list.remove(bpy.context.scene.sna_obj_list_id)
                bpy.context.scene.sna_obj_list_id = 0
            else:
                if len(bpy.context.scene.sna_obj_list) > bpy.context.scene.sna_obj_list_id:
                    bpy.context.scene.sna_obj_list.remove(bpy.context.scene.sna_obj_list_id)
                bpy.context.scene.sna_obj_list_id = int(len(bpy.context.scene.sna_obj_list) - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT__E64C1(bpy.types.Panel):
    bl_label = '物体组'
    bl_idname = 'SNA_PT__E64C1'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'
    bl_category = '物体组'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_735AF = layout.column(heading='', align=False)
        col_735AF.alert = False
        col_735AF.enabled = True
        col_735AF.active = True
        col_735AF.use_property_split = False
        col_735AF.use_property_decorate = False
        col_735AF.scale_x = 1.0
        col_735AF.scale_y = 1.0
        col_735AF.alignment = 'Expand'.upper()
        col_735AF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_DB106 = col_735AF.row(heading='', align=False)
        row_DB106.alert = False
        row_DB106.enabled = True
        row_DB106.active = True
        row_DB106.use_property_split = False
        row_DB106.use_property_decorate = False
        row_DB106.scale_x = 1.0
        row_DB106.scale_y = 1.0
        row_DB106.alignment = 'Expand'.upper()
        row_DB106.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('E8A78', locals())
        row_DB106.template_list('SNA_UL_display_collection_list_E8A78', coll_id, bpy.context.scene, 'sna_obj_list', bpy.context.scene, 'sna_obj_list_id', rows=0)
        col_E3169 = row_DB106.column(heading='', align=False)
        col_E3169.alert = False
        col_E3169.enabled = True
        col_E3169.active = True
        col_E3169.use_property_split = False
        col_E3169.use_property_decorate = False
        col_E3169.scale_x = 1.0
        col_E3169.scale_y = 1.0
        col_E3169.alignment = 'Left'.upper()
        col_E3169.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E3169.operator('sna.add_obj_list_6c8d9', text='', icon_value=31, emboss=True, depress=False)
        op = col_E3169.operator('sna.remove_obj_list_063b1', text='', icon_value=32, emboss=True, depress=False)
        row_D00E0 = col_735AF.row(heading='', align=True)
        row_D00E0.alert = False
        row_D00E0.enabled = True
        row_D00E0.active = True
        row_D00E0.use_property_split = False
        row_D00E0.use_property_decorate = False
        row_D00E0.scale_x = 1.0
        row_D00E0.scale_y = 1.0
        row_D00E0.alignment = 'Expand'.upper()
        row_D00E0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_D00E0.operator('sna.my_generic_operator_72cae', text='指定', icon_value=0, emboss=True, depress=False)
        op = row_D00E0.operator('sna.my_generic_operator_1632d', text='选择', icon_value=0, emboss=True, depress=False)
        op = row_D00E0.operator('sna.my_generic_operator_f1fff', text='移除所选', icon_value=0, emboss=True, depress=False)
        op = row_D00E0.operator('sna.my_generic_operator_c6c4f', text='清空', icon_value=0, emboss=True, depress=False)
        row_18431 = col_735AF.row(heading='', align=False)
        row_18431.alert = False
        row_18431.enabled = True
        row_18431.active = True
        row_18431.use_property_split = False
        row_18431.use_property_decorate = False
        row_18431.scale_x = 1.0
        row_18431.scale_y = 1.0
        row_18431.alignment = 'Expand'.upper()
        row_18431.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('8124D', locals())
        row_18431.template_list('SNA_UL_display_collection_list001_8124D', coll_id, bpy.context.scene.sna_obj_list[bpy.context.scene.sna_obj_list_id], 'selected', bpy.context.scene, 'sna_obj_list_pointer_id', rows=0)
        col_688F4 = row_18431.column(heading='', align=False)
        col_688F4.alert = False
        col_688F4.enabled = True
        col_688F4.active = True
        col_688F4.use_property_split = False
        col_688F4.use_property_decorate = False
        col_688F4.scale_x = 1.0
        col_688F4.scale_y = 1.0
        col_688F4.alignment = 'Left'.upper()
        col_688F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_688F4.operator('sna.add_obj_list_pointer_3ad57', text='', icon_value=31, emboss=True, depress=False)
        op = col_688F4.operator('sna.remove_obj_list_pointer_75a67', text='', icon_value=32, emboss=True, depress=False)


class SNA_PT_MMD_QUICK_TOOL_MATERIAL_C3756(bpy.types.Panel):
    bl_label = 'mmd Quick tool Material'
    bl_idname = 'SNA_PT_MMD_QUICK_TOOL_MATERIAL_C3756'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'QT MMD'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not ((eval('bpy.context.space_data.type') == 'NODE_EDITOR') and (eval('bpy.context.space_data.tree_type') == 'ShaderNodeTree'))))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_OT_Bake_Tex_F278F(bpy.types.Operator):
    bl_idname = "sna.bake_tex_f278f"
    bl_label = "bake_tex"
    bl_description = "bake"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.area.type == 'NODE_EDITOR'):
            if bpy.context.scene.sna_use_choose_tex:
                if (('TEX_IMAGE' == bpy.context.active_object.active_material.node_tree.nodes.active.type) and (bpy.context.active_object.active_material.node_tree.nodes.active.select == True)):
                    bpy.ops.object.bake('INVOKE_DEFAULT', type='EMIT', margin=16, margin_type='ADJACENT_FACES', target='IMAGE_TEXTURES', use_clear=True)
                    self.report({'INFO'}, message='烘焙完成')
                else:
                    self.report({'INFO'}, message='没有选中图像节点')
            else:
                for i_E93E1 in range(len(bpy.context.active_object.active_material.node_tree.links)):
                    if (('材质输出' == bpy.context.active_object.active_material.node_tree.links[i_E93E1].to_node.name) or (bpy.context.active_object.active_material.node_tree.links[i_E93E1].to_node.name == 'Material Output')):
                        node_tree_004['sna_last_node'] = bpy.context.active_object.active_material.node_tree.links[i_E93E1].from_node
                        print(bpy.context.active_object.active_material.node_tree.links[i_E93E1].to_node.name)
                node_73893 = bpy.context.active_object.active_material.node_tree.nodes.new(type='ShaderNodeTexImage', )
                node_73893.location = tuple(mathutils.Vector(node_tree_004['sna_last_node'].location) + mathutils.Vector((0.0, 250.0)))
                image_E6981 = bpy.data.images.new(name='bake_tex', width=bpy.context.scene.sna_bake_tex_size_x, height=bpy.context.scene.sna_bake_tex_size_y, alpha=True, )
                node_73893.image = image_E6981
                for i_3E53F in range(len(bpy.context.active_object.active_material.node_tree.nodes)):
                    bpy.context.active_object.active_material.node_tree.nodes[i_3E53F].select = False
                node_73893.select = True
                bpy.context.active_object.active_material.node_tree.nodes.active = node_73893
                bpy.ops.object.bake('INVOKE_DEFAULT', type='EMIT', margin=16, margin_type='ADJACENT_FACES', target='IMAGE_TEXTURES', use_clear=True)
                self.report({'INFO'}, message='烘焙完成')
        else:
            self.report({'INFO'}, message='活动区域不在节点编辑器')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_tool_header_D53B4(self, context):
    if not ( not 'PAINT_VERTEX'==bpy.context.mode):
        layout = self.layout
        row_9B98E = layout.row(heading='', align=True)
        row_9B98E.alert = False
        row_9B98E.enabled = True
        row_9B98E.active = True
        row_9B98E.use_property_split = False
        row_9B98E.use_property_decorate = False
        row_9B98E.scale_x = 1.0
        row_9B98E.scale_y = 1.0
        row_9B98E.alignment = 'Left'.upper()
        row_9B98E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9B98E.operator('sna.operator_6aa4f', text='', icon_value=77, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator001_05281', text='', icon_value=_icons['white.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator002_2a623', text='', icon_value=_icons['black.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator003_d462c', text='', icon_value=_icons['red.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator004_d6bee', text='', icon_value=_icons['green.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator005_2a676', text='', icon_value=_icons['blue.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator006_dda67', text='', icon_value=_icons['yellow.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator007_17ad2', text='', icon_value=_icons['purple.png'].icon_id, emboss=True, depress=False)
        op = row_9B98E.operator('sna.operator008_a3fb7', text='', icon_value=_icons['cyan.png'].icon_id, emboss=True, depress=False)


class SNA_OT_Operator001_05281(bpy.types.Operator):
    bl_idname = "sna.operator001_05281"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (1.0, 1.0, 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator003_D462C(bpy.types.Operator):
    bl_idname = "sna.operator003_d462c"
    bl_label = "Operator.003"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (1.0, 0.0, 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator004_D6Bee(bpy.types.Operator):
    bl_idname = "sna.operator004_d6bee"
    bl_label = "Operator.004"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (0.0, 1.0, 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator005_2A676(bpy.types.Operator):
    bl_idname = "sna.operator005_2a676"
    bl_label = "Operator.005"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (0.0, 0.0, 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator006_Dda67(bpy.types.Operator):
    bl_idname = "sna.operator006_dda67"
    bl_label = "Operator.006"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (1.0, 1.0, 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator007_17Ad2(bpy.types.Operator):
    bl_idname = "sna.operator007_17ad2"
    bl_label = "Operator.007"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (1.0, 0.0, 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator008_A3Fb7(bpy.types.Operator):
    bl_idname = "sna.operator008_a3fb7"
    bl_label = "Operator.008"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (0.0, 1.0, 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator002_2A623(bpy.types.Operator):
    bl_idname = "sna.operator002_2a623"
    bl_label = "Operator.002"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.brushes['Draw'].color = (0.0, 0.0, 0.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_6Aa4F(bpy.types.Operator):
    bl_idname = "sna.operator_6aa4f"
    bl_label = "Operator"
    bl_description = "设置选中物体的顶点色为画笔颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_tree_002['sna_sna_new_variable'] = bpy.context.view_layer.objects.active.name
        bpy.ops.paint.vertex_color_set('INVOKE_DEFAULT', )
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT')
        for i_44E9C in range(len(bpy.context.view_layer.objects.selected)):
            bpy.context.view_layer.objects.active = bpy.context.view_layer.objects.selected[i_44E9C]
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
            bpy.ops.paint.vertex_color_set('INVOKE_DEFAULT', )
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='OBJECT')
            if (i_44E9C == int(len(bpy.context.view_layer.objects.selected) - 1.0)):
                bpy.context.view_layer.objects.active = bpy.context.view_layer.objects[node_tree_002['sna_sna_new_variable']]
                bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_C113E(bpy.types.AddonPreferences):
    bl_idname = 'mmd_quick_tool'
    sna_mmd: bpy.props.BoolProperty(name='MMD工具', description='', default=True)
    sna_new_property: bpy.props.BoolProperty(name='快速设置分辨率界面', description='', default=True)
    sna_new_property_001: bpy.props.BoolProperty(name='快速灯光设置界面', description='', default=True)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            row_1F4FE = layout.row(heading='', align=False)
            row_1F4FE.alert = False
            row_1F4FE.enabled = True
            row_1F4FE.active = True
            row_1F4FE.use_property_split = False
            row_1F4FE.use_property_decorate = False
            row_1F4FE.scale_x = 1.0
            row_1F4FE.scale_y = 1.0
            row_1F4FE.alignment = 'Expand'.upper()
            row_1F4FE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_mmd', text='MMD工具', icon_value=0, emboss=True)
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_new_property', text='快速设置分辨率界面', icon_value=0, emboss=True)
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_new_property_001', text='快速设置灯光界面', icon_value=0, emboss=True)
            row_472B7 = layout.row(heading='', align=False)
            row_472B7.alert = False
            row_472B7.enabled = True
            row_472B7.active = True
            row_472B7.use_property_split = False
            row_472B7.use_property_decorate = False
            row_472B7.scale_x = 1.0
            row_472B7.scale_y = 1.0
            row_472B7.alignment = 'Expand'.upper()
            row_472B7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_472B7.operator('wm.url_open', text='打开github首页获取帮助', icon_value=625, emboss=True, depress=False)
            op.url = 'https://github.com/bb-yi/mmd-Quick-tool'
            row_99DC0 = layout.row(heading='', align=False)
            row_99DC0.alert = False
            row_99DC0.enabled = True
            row_99DC0.active = True
            row_99DC0.use_property_split = False
            row_99DC0.use_property_decorate = False
            row_99DC0.scale_x = 1.0
            row_99DC0.scale_y = 1.0
            row_99DC0.alignment = 'Center'.upper()
            row_99DC0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_99DC0.label(text='mmd Quick tool', icon_value=0)
            row_99DC0.label(text='插件版本' + str(tuple((1, 1, 2))), icon_value=0)
            row_99DC0.label(text='by  ' + 'SFY', icon_value=227)
            row_99DC0.label(text='感谢使用', icon_value=0)


class SNA_PT_IK_BB533(bpy.types.Panel):
    bl_label = 'ik修复'
    bl_idname = 'SNA_PT_IK_BB533'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_MMD_9FB97'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_79ECE = layout.column(heading='', align=False)
        col_79ECE.alert = False
        col_79ECE.enabled = True
        col_79ECE.active = True
        col_79ECE.use_property_split = False
        col_79ECE.use_property_decorate = False
        col_79ECE.scale_x = 1.0
        col_79ECE.scale_y = 1.0
        col_79ECE.alignment = 'Expand'.upper()
        col_79ECE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_79ECE.operator('sna.my_generic_operator_c3269', text='添加骨骼物体', icon_value=174, emboss=True, depress=False)
        op.sna_new_property = False
        op = col_79ECE.operator('sna.my_generic_operator_cc136', text='传递顶点组', icon_value=546, emboss=True, depress=False)
        op = col_79ECE.operator('sna.my_generic_operator_c8494', text='生成骨骼约束', icon_value=177, emboss=True, depress=False)
        row_4175F = col_79ECE.row(heading='', align=False)
        row_4175F.alert = False
        row_4175F.enabled = True
        row_4175F.active = True
        row_4175F.use_property_split = False
        row_4175F.use_property_decorate = False
        row_4175F.scale_x = 1.0
        row_4175F.scale_y = 1.0
        row_4175F.alignment = 'Expand'.upper()
        row_4175F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_4175F.prop(bpy.context.scene, 'sna_ik_fix_on', text=('开启' if bpy.context.scene.sna_ik_fix_on else '关闭'), icon_value=254, emboss=True)
        op = row_4175F.operator('sna.my_generic_operator_89058', text='清除骨骼约束', icon_value=715, emboss=True, depress=False)
        op = col_79ECE.operator('sna.ik_b204a', text='关闭/打开IK', icon_value=692, emboss=True, depress=False)
        op = col_79ECE.operator('sna.my_generic_operator_c034b', text='烘焙约束', icon_value=510, emboss=True, depress=False)
        op.sna_new_property = bpy.context.scene.frame_start
        op.sna_new_property_001 = bpy.context.scene.frame_end


class SNA_PT_panel_CAA15(bpy.types.Panel):
    bl_label = '物体操作'
    bl_idname = 'SNA_PT_panel_CAA15'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_MMD_9FB97'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.operator015_0ebb1', text='位姿归零', icon_value=0, emboss=True, depress=False)
        op.sna_x = True
        op.sna_y = True
        op.sna_z = True


class SNA_PT__EB9A7(bpy.types.Panel):
    bl_label = '分辨率调整'
    bl_idname = 'SNA_PT__EB9A7'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_format'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_9A4A1 = layout.row(heading='', align=False)
        row_9A4A1.alert = False
        row_9A4A1.enabled = True
        row_9A4A1.active = True
        row_9A4A1.use_property_split = False
        row_9A4A1.use_property_decorate = False
        row_9A4A1.scale_x = 1.0
        row_9A4A1.scale_y = 1.0
        row_9A4A1.alignment = 'Left'.upper()
        row_9A4A1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9A4A1.operator('sna.operator_b46a6', text='1080p', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator001_64c4a', text='2k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator002_7dbd9', text='4k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator007_85779', text='交换', icon_value=692, emboss=True, depress=False)
        op.sna_ax = 7
        op = row_9A4A1.operator('sna.operator008_f7b4c', text='*0.5', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator009_f9bf5', text='*2', icon_value=0, emboss=True, depress=False)
        row_3E7EE = layout.row(heading='', align=False)
        row_3E7EE.alert = False
        row_3E7EE.enabled = True
        row_3E7EE.active = True
        row_3E7EE.use_property_split = False
        row_3E7EE.use_property_decorate = False
        row_3E7EE.scale_x = 1.0
        row_3E7EE.scale_y = 1.0
        row_3E7EE.alignment = 'Left'.upper()
        row_3E7EE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_3E7EE.prop(bpy.context.scene, 'sna_bili', text='比例', icon_value=0, emboss=True, expand=True)


class SNA_PT__76238(bpy.types.Panel):
    bl_label = '相机设置'
    bl_idname = 'SNA_PT__76238'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_format'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_854C3 = layout.row(heading='', align=False)
        row_854C3.alert = False
        row_854C3.enabled = True
        row_854C3.active = True
        row_854C3.use_property_split = False
        row_854C3.use_property_decorate = False
        row_854C3.scale_x = 1.0
        row_854C3.scale_y = 1.0
        row_854C3.alignment = 'Left'.upper()
        row_854C3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_854C3.prop(bpy.data.cameras[bpy.context.scene.camera.data.name], 'lens', text='焦距', icon_value=0, emboss=True)
        row_854C3.prop(bpy.data.cameras[bpy.context.scene.camera.data.name].dof, 'aperture_fstop', text='光圈', icon_value=0, emboss=True)


class SNA_PT_MMD_13483(bpy.types.Panel):
    bl_label = 'MMD工具'
    bl_idname = 'SNA_PT_MMD_13483'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_9FB97'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_mmd)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_MMD_D0266(bpy.types.Panel):
    bl_label = 'MMD流程'
    bl_idname = 'SNA_PT_MMD_D0266'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_85326 = layout.column(heading='', align=False)
        col_85326.alert = False
        col_85326.enabled = True
        col_85326.active = True
        col_85326.use_property_split = False
        col_85326.use_property_decorate = False
        col_85326.scale_x = 1.0
        col_85326.scale_y = 1.0
        col_85326.alignment = 'Expand'.upper()
        col_85326.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_85326.operator('sna.operator021_0d655', text='删除材质变形节点组', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator004_fa32a', text='合并相同贴图的材质', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator005_9368b', text='替换mmd材质节点组', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.mtl_78668', text='为abc添加材质', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator025_4038c', text='为选中物体导入表情', icon_value=0, emboss=True, depress=False)
        col_52A12 = col_85326.column(heading='', align=True)
        col_52A12.alert = False
        col_52A12.enabled = True
        col_52A12.active = True
        col_52A12.use_property_split = False
        col_52A12.use_property_decorate = False
        col_52A12.scale_x = 1.0
        col_52A12.scale_y = 1.0
        col_52A12.alignment = 'Center'.upper()
        col_52A12.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_52A12.separator(factor=1.003000020980835)
        col_52A12.label(text='如果导入mmd相机后经常闪退可以试试这个', icon_value=0)
        op = col_52A12.operator('sna.operator006_42368', text='相机闪退修复', icon_value=0, emboss=True, depress=False)
        op.sna_camera_name = ''
        op.sna_mmd_camera = ''
        if ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA'))):
            col_52A12.prop(bpy.context.scene, 'sna_new_property_002', text='帧偏移', icon_value=0, emboss=True)


class SNA_PT__DD0E8(bpy.types.Panel):
    bl_label = '清理'
    bl_idname = 'SNA_PT__DD0E8'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_E927A = layout.column(heading='', align=False)
        col_E927A.alert = False
        col_E927A.enabled = True
        col_E927A.active = True
        col_E927A.use_property_split = False
        col_E927A.use_property_decorate = False
        col_E927A.scale_x = 1.0
        col_E927A.scale_y = 1.0
        col_E927A.alignment = 'Expand'.upper()
        col_E927A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E927A.operator('sna.operator020_173c4', text='清理自定义几何数据', icon_value=0, emboss=True, depress=False)
        op = col_E927A.operator('sna.operator022_d211d', text='清理空形态键关键帧', icon_value=0, emboss=True, depress=False)
        op = col_E927A.operator('sna.operator023_9e188', text='清除形态键上的驱动器', icon_value=0, emboss=True, depress=False)
        op = col_E927A.operator('sna.operator024_1bdb7', text='清除无用材质节点', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = 0
        op = col_E927A.operator('sna.operator025_c68f6', text='清除骨骼修改器', icon_value=0, emboss=True, depress=False)


class SNA_PT__6A6A3(bpy.types.Panel):
    bl_label = '选择'
    bl_idname = 'SNA_PT__6A6A3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_BA6C8 = layout.column(heading='', align=False)
        col_BA6C8.alert = False
        col_BA6C8.enabled = True
        col_BA6C8.active = True
        col_BA6C8.use_property_split = False
        col_BA6C8.use_property_decorate = False
        col_BA6C8.scale_x = 1.0
        col_BA6C8.scale_y = 1.0
        col_BA6C8.alignment = 'Expand'.upper()
        col_BA6C8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_7FD55 = col_BA6C8.box()
        box_7FD55.alert = False
        box_7FD55.enabled = True
        box_7FD55.active = True
        box_7FD55.use_property_split = False
        box_7FD55.use_property_decorate = False
        box_7FD55.alignment = 'Expand'.upper()
        box_7FD55.scale_x = 1.0
        box_7FD55.scale_y = 1.0
        if not True: box_7FD55.operator_context = "EXEC_DEFAULT"
        row_4AFCF = box_7FD55.row(heading='', align=False)
        row_4AFCF.alert = False
        row_4AFCF.enabled = True
        row_4AFCF.active = True
        row_4AFCF.use_property_split = False
        row_4AFCF.use_property_decorate = False
        row_4AFCF.scale_x = 1.0
        row_4AFCF.scale_y = 1.0
        row_4AFCF.alignment = 'Expand'.upper()
        row_4AFCF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_4AFCF.operator('sna.operator_5ed64', text='根据贴图选择物体', icon_value=0, emboss=True, depress=False)
        op = row_4AFCF.operator('sna.operator001_1136e', text='选中相同材质的物体', icon_value=0, emboss=True, depress=False)
        box_2F6C2 = col_BA6C8.box()
        box_2F6C2.alert = False
        box_2F6C2.enabled = True
        box_2F6C2.active = True
        box_2F6C2.use_property_split = False
        box_2F6C2.use_property_decorate = False
        box_2F6C2.alignment = 'Expand'.upper()
        box_2F6C2.scale_x = 1.0
        box_2F6C2.scale_y = 1.0
        if not True: box_2F6C2.operator_context = "EXEC_DEFAULT"
        row_0DF0B = box_2F6C2.row(heading='', align=False)
        row_0DF0B.alert = False
        row_0DF0B.enabled = True
        row_0DF0B.active = True
        row_0DF0B.use_property_split = False
        row_0DF0B.use_property_decorate = False
        row_0DF0B.scale_x = 1.0
        row_0DF0B.scale_y = 1.0
        row_0DF0B.alignment = 'Expand'.upper()
        row_0DF0B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0DF0B.operator('sna.my_generic_operator_400a9', text='选中骨架', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = '腿ik骨'


class SNA_PT__CA667(bpy.types.Panel):
    bl_label = '顶点色'
    bl_idname = 'SNA_PT__CA667'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 3
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_222AF = layout.column(heading='', align=False)
        col_222AF.alert = False
        col_222AF.enabled = True
        col_222AF.active = True
        col_222AF.use_property_split = False
        col_222AF.use_property_decorate = False
        col_222AF.scale_x = 1.0
        col_222AF.scale_y = 1.0
        col_222AF.alignment = 'Expand'.upper()
        col_222AF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_BFA66 = col_222AF.row(heading='', align=False)
        row_BFA66.alert = False
        row_BFA66.enabled = True
        row_BFA66.active = True
        row_BFA66.use_property_split = False
        row_BFA66.use_property_decorate = False
        row_BFA66.scale_x = 1.0
        row_BFA66.scale_y = 1.0
        row_BFA66.alignment = 'Expand'.upper()
        row_BFA66.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_BFA66.operator('sna.my_generic_operator_e6bd2', text='添加顶点色属性', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = '顶点色'
        op = row_BFA66.operator('sna.my_generic_operator_e9b48', text='移除顶点色属性', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = ''


class SNA_PT_UV_C5809(bpy.types.Panel):
    bl_label = 'UV'
    bl_idname = 'SNA_PT_UV_C5809'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_8BB61 = layout.column(heading='', align=False)
        col_8BB61.alert = False
        col_8BB61.enabled = True
        col_8BB61.active = True
        col_8BB61.use_property_split = False
        col_8BB61.use_property_decorate = False
        col_8BB61.scale_x = 1.0
        col_8BB61.scale_y = 1.0
        col_8BB61.alignment = 'Expand'.upper()
        col_8BB61.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_4EF87 = col_8BB61.row(heading='', align=False)
        row_4EF87.alert = False
        row_4EF87.enabled = True
        row_4EF87.active = True
        row_4EF87.use_property_split = False
        row_4EF87.use_property_decorate = False
        row_4EF87.scale_x = 1.0
        row_4EF87.scale_y = 1.0
        row_4EF87.alignment = 'Expand'.upper()
        row_4EF87.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_4EF87.operator('sna.uv_9201e', text='生成位置uv', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = 'FRONT'
        op = row_4EF87.operator('sna.uv_94b57', text='移除位置uv', icon_value=0, emboss=True, depress=False)


class SNA_PT__3C27A(bpy.types.Panel):
    bl_label = '名称编辑'
    bl_idname = 'SNA_PT__3C27A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_02724 = layout.row(heading='', align=False)
        row_02724.alert = False
        row_02724.enabled = True
        row_02724.active = True
        row_02724.use_property_split = False
        row_02724.use_property_decorate = False
        row_02724.scale_x = 1.0
        row_02724.scale_y = 1.0
        row_02724.alignment = 'Expand'.upper()
        row_02724.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_02724.operator('sna.my_generic_operator_bedaf', text='材质到物体', icon_value=0, emboss=True, depress=False)
        op = row_02724.operator('sna.my_generic_operator_04cf5', text='物体到材质', icon_value=0, emboss=True, depress=False)
        op = row_02724.operator('sna.my_generic_operator_60634', text='贴图到材质', icon_value=0, emboss=True, depress=False)


class SNA_PT__3C09E(bpy.types.Panel):
    bl_label = '贴图'
    bl_idname = 'SNA_PT__3C09E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_13483'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_D8D26 = layout.row(heading='', align=False)
        row_D8D26.alert = False
        row_D8D26.enabled = True
        row_D8D26.active = True
        row_D8D26.use_property_split = False
        row_D8D26.use_property_decorate = False
        row_D8D26.scale_x = 1.0
        row_D8D26.scale_y = 1.0
        row_D8D26.alignment = 'Expand'.upper()
        row_D8D26.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_D8D26.operator('sna.my_generic_operator_b74af', text='匹配色彩空间', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = '仅选中'
        op.sna_new_property_001 = '仅基础色贴图'


class SNA_PT_panel_0AC32(bpy.types.Panel):
    bl_label = '分段渲染'
    bl_idname = 'SNA_PT_panel_0AC32'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_9FB97'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_9BC54 = layout.row(heading='', align=False)
        row_9BC54.alert = False
        row_9BC54.enabled = True
        row_9BC54.active = True
        row_9BC54.use_property_split = False
        row_9BC54.use_property_decorate = False
        row_9BC54.scale_x = 1.0
        row_9BC54.scale_y = 1.0
        row_9BC54.alignment = 'Expand'.upper()
        row_9BC54.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        coll_id = display_collection_id('B793B', locals())
        row_9BC54.template_list('SNA_UL_display_collection_list_B793B', coll_id, bpy.context.scene, 'sna_render_list', bpy.context.scene, 'sna_id', rows=0)
        col_B28B3 = row_9BC54.column(heading='', align=True)
        col_B28B3.alert = False
        col_B28B3.enabled = True
        col_B28B3.active = True
        col_B28B3.use_property_split = False
        col_B28B3.use_property_decorate = False
        col_B28B3.scale_x = 1.0
        col_B28B3.scale_y = 1.0
        col_B28B3.alignment = 'Expand'.upper()
        col_B28B3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_B28B3.operator('sna.add_render_list_84292', text='', icon_value=31, emboss=True, depress=False)
        op = col_B28B3.operator('sna.remove_render_list_e8059', text='', icon_value=32, emboss=True, depress=False)
        col_B28B3.separator(factor=1.6389999389648438)
        op = col_B28B3.operator('sna.up_b66ca', text='', icon_value=7, emboss=True, depress=False)
        op = col_B28B3.operator('sna.down_25ee0', text='', icon_value=5, emboss=True, depress=False)
        col_34299 = layout.column(heading='', align=False)
        col_34299.alert = False
        col_34299.enabled = True
        col_34299.active = True
        col_34299.use_property_split = False
        col_34299.use_property_decorate = False
        col_34299.scale_x = 1.0
        col_34299.scale_y = 1.0
        col_34299.alignment = 'Expand'.upper()
        col_34299.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_9779E = col_34299.row(heading='', align=False)
        row_9779E.alert = bpy.context.scene.sna_is_render
        row_9779E.enabled = True
        row_9779E.active = True
        row_9779E.use_property_split = False
        row_9779E.use_property_decorate = False
        row_9779E.scale_x = 1.0
        row_9779E.scale_y = 1.0
        row_9779E.alignment = 'Expand'.upper()
        row_9779E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_9779E.operator('sna.my_generic_operator_5874f', text=('正在渲染' if bpy.context.scene.sna_is_render else '开始渲染'), icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_is_render:
            row_42916 = col_34299.row(heading='', align=False)
            row_42916.alert = True
            row_42916.enabled = True
            row_42916.active = True
            row_42916.use_property_split = False
            row_42916.use_property_decorate = False
            row_42916.scale_x = 1.0
            row_42916.scale_y = 1.0
            row_42916.alignment = 'Center'.upper()
            row_42916.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_42916.label(text='正在进行    ' + bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].name, icon_value=0)
            row_42916.label(text='第' + str(bpy.data.scenes['Scene'].frame_current) + '帧', icon_value=0)
        row_71992 = col_34299.row(heading='', align=False)
        row_71992.alert = False
        row_71992.enabled = True
        row_71992.active = True
        row_71992.use_property_split = False
        row_71992.use_property_decorate = False
        row_71992.scale_x = 1.0
        row_71992.scale_y = 1.0
        row_71992.alignment = 'Center'.upper()
        row_71992.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_71992.label(text='平均渲染时间(五次)  ' + str(node_tree_001['sna_avg_render_time']), icon_value=0)
        row_71992.label(text='还剩' + str(int(node_tree_001['sna_sub_frame'] - node_tree_001['sna_current_frame'])) + '帧', icon_value=0)
        row_71992.label(text='预计剩余' + str(round(float(int(node_tree_001['sna_sub_frame'] - node_tree_001['sna_current_frame']) * node_tree_001['sna_avg_render_time']), abs(2))) + '时间', icon_value=0)


class SNA_PT_bake_tex_955B8(bpy.types.Panel):
    bl_label = '烘焙贴图'
    bl_idname = 'SNA_PT_bake_tex_955B8'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_MMD_QUICK_TOOL_MATERIAL_C3756'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.bake_tex_f278f', text='烘焙当前预览', icon_value=0, emboss=True, depress=False)
        col_2ED0C = layout.column(heading='', align=True)
        col_2ED0C.alert = False
        col_2ED0C.enabled = True
        col_2ED0C.active = True
        col_2ED0C.use_property_split = False
        col_2ED0C.use_property_decorate = False
        col_2ED0C.scale_x = 1.0
        col_2ED0C.scale_y = 1.0
        col_2ED0C.alignment = 'Expand'.upper()
        col_2ED0C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_2ED0C.prop(bpy.context.scene, 'sna_bake_tex_size_x', text='X', icon_value=0, emboss=True)
        col_2ED0C.prop(bpy.context.scene, 'sna_bake_tex_size_y', text='Y', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_use_choose_tex', text='使用当前选中图像节点', icon_value=0, emboss=True)


class SNA_GROUP_sna_render_list_property(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='name', description='', default='', subtype='NONE', maxlen=0)
    start_frame: bpy.props.IntProperty(name='start_frame', description='', default=0, subtype='NONE')
    end_frame: bpy.props.IntProperty(name='end_frame', description='', default=0, subtype='NONE')
    render_camera: bpy.props.PointerProperty(name='render_camera', description='', type=bpy.types.Object, update=sna_update_render_camera_28727)
    output_directory: bpy.props.StringProperty(name='output_directory', description='', default='', subtype='DIR_PATH', maxlen=0)
    on: bpy.props.BoolProperty(name='on', description='', default=True)


class SNA_GROUP_sna_render_time(bpy.types.PropertyGroup):
    frame_start_time: bpy.props.FloatProperty(name='frame_start_time', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    frame_time: bpy.props.FloatProperty(name='frame_time', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)


class SNA_GROUP_sna_obj_list_pointer(bpy.types.PropertyGroup):
    obj_list_pointer_property: bpy.props.PointerProperty(name='obj_list_pointer_Property', description='', type=bpy.types.Object)
    active: bpy.props.BoolProperty(name='active', description='活动物体', default=False)


class SNA_GROUP_sna_obj_list_property(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='name', description='', default='物体组', subtype='NONE', maxlen=0)
    selected: bpy.props.CollectionProperty(name='selected', description='', type=SNA_GROUP_sna_obj_list_pointer)


def sna_new_property_001_enum_items(self, context):
    return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_render_list_property)
    bpy.utils.register_class(SNA_GROUP_sna_render_time)
    bpy.utils.register_class(SNA_GROUP_sna_obj_list_pointer)
    bpy.utils.register_class(SNA_GROUP_sna_obj_list_property)
    bpy.types.Scene.sna_bili = bpy.props.EnumProperty(name='bili', description='', items=[('自定义', '自定义', '', 0, 0), ('1:1', '1:1', '', 0, 1), ('3:2', '3:2', '', 0, 2), ('4:3', '4:3', '', 0, 3), ('16:9', '16:9', '', 0, 4), ('14:9', '14:9', '', 0, 5), ('1.85:1', '1.85:1', '', 0, 6), ('2.39:1', '2.39:1', '', 0, 7)], update=sna_update_sna_bili_31149)
    bpy.types.Scene.sna_new_property = bpy.props.BoolProperty(name='锁定比例', description='', default=False)
    bpy.types.Scene.sna_new_property_001 = bpy.props.EnumProperty(name='灯光角度', description='', items=[('自定义', '自定义', '', 0, 0), ('0', '0', '', 0, 1), ('15', '15', '', 0, 2), ('60', '60', '', 0, 3), ('90', '90', '', 0, 4), ('120', '120', '', 0, 5), ('180', '180', '', 0, 6)], update=sna_update_sna_new_property_001_7222D)
    bpy.types.Scene.sna_new_property_002 = bpy.props.IntProperty(name='帧偏移', description='', default=30, subtype='NONE')
    bpy.types.Scene.sna_new_property_003 = bpy.props.BoolProperty(name='切换中英文', description='', default=True, update=sna_update_sna_new_property_003_B42B0)
    bpy.types.Scene.sna_new_property_004 = bpy.props.FloatProperty(name='分.秒', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=3, precision=2, update=sna_update_sna_new_property_004_0F02E)
    bpy.types.Scene.sna_id = bpy.props.IntProperty(name='id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_render_list = bpy.props.CollectionProperty(name='render_list', description='', type=SNA_GROUP_sna_render_list_property)
    bpy.types.Scene.sna_is_render = bpy.props.BoolProperty(name='is_render', description='', default=False)
    bpy.types.Scene.sna_render_time_id = bpy.props.IntProperty(name='render_time_id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_time = bpy.props.CollectionProperty(name='time', description='', type=SNA_GROUP_sna_render_time)
    bpy.types.Scene.sna_open = bpy.props.BoolProperty(name='open', description='', default=True)
    bpy.types.Scene.sna_view_tex = bpy.props.BoolProperty(name='view_tex', description='切换到预览贴图模式', default=False, update=sna_update_sna_view_tex_632AA)
    bpy.types.Scene.sna_disable_keyframe_switch = bpy.props.BoolProperty(name='Disable_keyframe_switch', description='', default=False)
    bpy.types.Scene.sna_remove_transform_constraint = bpy.props.BoolProperty(name='Remove_transform_constraint', description='', default=False)
    bpy.types.Scene.sna_obj_list_id = bpy.props.IntProperty(name='obj_list_id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_obj_list = bpy.props.CollectionProperty(name='obj_list', description='', type=SNA_GROUP_sna_obj_list_property)
    bpy.types.Scene.sna_obj_list_pointer_id = bpy.props.IntProperty(name='obj_list_pointer_id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_bake_tex_size_x = bpy.props.IntProperty(name='bake_tex_size_x', description='', default=1024, subtype='NONE')
    bpy.types.Scene.sna_bake_tex_size_y = bpy.props.IntProperty(name='bake_tex_size_y', description='', default=1024, subtype='NONE')
    bpy.types.Scene.sna_use_choose_tex = bpy.props.BoolProperty(name='use_choose_tex', description='', default=False)
    bpy.types.Scene.sna_display_ver_id = bpy.props.BoolProperty(name='display_ver_id', description='', default=False, update=sna_update_sna_display_ver_id_C6BB7)
    bpy.types.Scene.sna_display_ver_color = bpy.props.FloatVectorProperty(name='display_ver_color', description='', size=4, default=(1.0, 1.0, 1.0, 1.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=1, precision=2, update=sna_update_sna_display_ver_color_BD949)
    bpy.types.Scene.sna_display_ver_size = bpy.props.FloatProperty(name='display_ver_size', description='', default=20.0, subtype='NONE', unit='NONE', min=0.10000000149011612, max=100.0, step=3, precision=1, update=sna_update_sna_display_ver_size_04D29)
    bpy.types.Scene.sna_ik_fix_on = bpy.props.BoolProperty(name='ik_fix_on', description='', default=True, update=sna_update_sna_ik_fix_on_057DD)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_C8494)
    bpy.utils.register_class(SNA_OT_Ik_B204A)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_C3269)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_Cc136)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_89058)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_C034B)
    bpy.utils.register_class(SNA_OT_Operator015_0Ebb1)
    bpy.utils.register_class(SNA_OT_Operator013_2E178)
    bpy.types.CYCLES_LIGHT_PT_light.append(sna_add_to_cycles_light_pt_light_B5682)
    bpy.utils.register_class(SNA_OT_Operator019_8Aa9A)
    bpy.utils.register_class(SNA_OT_Operator017_E38Ed)
    bpy.utils.register_class(SNA_OT_Operator018_Bf94B)
    bpy.utils.register_class(SNA_OT_Operator016_2E985)
    bpy.app.handlers.frame_change_post.append(frame_change_post_handler_1BDE6)
    bpy.types.TIME_MT_editor_menus.append(sna_add_to_time_mt_editor_menus_BB1C8)
    bpy.types.DOPESHEET_HT_header.append(sna_add_to_dopesheet_ht_header_9E879)
    bpy.utils.register_class(SNA_OT_Operator024_D37Ce)
    bpy.utils.register_class(SNA_OT_Operator023_Dc120)
    bpy.utils.register_class(SNA_OT_Operator021_0D655)
    bpy.utils.register_class(SNA_OT_Operator005_9368B)
    bpy.utils.register_class(SNA_OT_Operator006_42368)
    bpy.utils.register_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.register_class(SNA_OT_Operator025_4038C)
    bpy.utils.register_class(SNA_OT_Operator001_64C4A)
    bpy.utils.register_class(SNA_OT_Operator_B46A6)
    bpy.utils.register_class(SNA_OT_Operator007_85779)
    bpy.utils.register_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.register_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.register_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.append(sna_add_to_render_pt_format_DCB79)
    bpy.utils.register_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.register_class(SNA_PT_MMD_9FB97)
    bpy.utils.register_class(SNA_OT_Mtl_78668)
    bpy.utils.register_class(SNA_OT_Operator020_173C4)
    bpy.utils.register_class(SNA_OT_Operator022_D211D)
    bpy.utils.register_class(SNA_OT_Operator023_9E188)
    bpy.utils.register_class(SNA_OT_Operator024_1Bdb7)
    bpy.utils.register_class(SNA_OT_Operator025_C68F6)
    bpy.utils.register_class(SNA_OT_Operator002_Ac0A6)
    bpy.types.VIEW3D_HT_tool_header.append(sna_add_to_view3d_ht_tool_header_FC05E)
    bpy.utils.register_class(SNA_OT_Operator001_1136E)
    bpy.utils.register_class(SNA_OT_Operator_5Ed64)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_400A9)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_E6Bd2)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_E9B48)
    bpy.types.OUTLINER_HT_header.append(sna_add_to_outliner_ht_header_1E9B6)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_Cf418)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_98B5F)
    bpy.types.OBJECT_PT_constraints.prepend(sna_add_to_object_pt_constraints_25BA8)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_Cde4F)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_2B24E)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_F6DBF)
    bpy.utils.register_class(SNA_PT_panel_A0042)
    bpy.utils.register_class(SNA_OT_Operator_5F6B3)
    bpy.utils.register_class(SNA_OT_Uv_94B57)
    bpy.utils.register_class(SNA_OT_Uv_9201E)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_Bedaf)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_04Cf5)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_60634)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_B74Af)
    bpy.utils.register_class(SNA_OT_Down_25Ee0)
    bpy.utils.register_class(SNA_OT_Up_B66Ca)
    bpy.utils.register_class(SNA_OT_Add_Render_List_84292)
    bpy.utils.register_class(SNA_OT_Remove_Render_List_E8059)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_5874F)
    bpy.app.handlers.render_complete.append(render_complete_handler_825EB)
    bpy.app.handlers.render_complete.append(render_complete_handler_C420C)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_33F13)
    bpy.app.handlers.render_cancel.append(render_cancel_handler_58683)
    bpy.app.handlers.render_post.append(render_post_handler_4E079)
    bpy.app.handlers.render_pre.append(render_pre_handler_1092E)
    bpy.app.handlers.render_post.append(render_post_handler_15713)
    bpy.utils.register_class(SNA_OT_Operator_Cc77E)
    bpy.app.handlers.render_post.append(render_post_handler_B2801)
    bpy.utils.register_class(SNA_OT_Add_Obj_List_6C8D9)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_72Cae)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_C6C4F)
    bpy.utils.register_class(SNA_OT_Add_Obj_List_Pointer_3Ad57)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_1632D)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_F1Fff)
    bpy.utils.register_class(SNA_OT_Remove_Obj_List_Pointer_75A67)
    bpy.utils.register_class(SNA_OT_Remove_Obj_List_063B1)
    bpy.utils.register_class(SNA_PT__E64C1)
    bpy.utils.register_class(SNA_UL_display_collection_list_E8A78)
    bpy.utils.register_class(SNA_UL_display_collection_list001_8124D)
    bpy.utils.register_class(SNA_PT_MMD_QUICK_TOOL_MATERIAL_C3756)
    bpy.utils.register_class(SNA_OT_Bake_Tex_F278F)
    bpy.types.VIEW3D_HT_tool_header.prepend(sna_add_to_view3d_ht_tool_header_D53B4)
    if not 'white.png' in _icons: _icons.load('white.png', os.path.join(os.path.dirname(__file__), 'icons', 'white.png'), "IMAGE")
    if not 'black.png' in _icons: _icons.load('black.png', os.path.join(os.path.dirname(__file__), 'icons', 'black.png'), "IMAGE")
    if not 'red.png' in _icons: _icons.load('red.png', os.path.join(os.path.dirname(__file__), 'icons', 'red.png'), "IMAGE")
    if not 'green.png' in _icons: _icons.load('green.png', os.path.join(os.path.dirname(__file__), 'icons', 'green.png'), "IMAGE")
    if not 'blue.png' in _icons: _icons.load('blue.png', os.path.join(os.path.dirname(__file__), 'icons', 'blue.png'), "IMAGE")
    if not 'yellow.png' in _icons: _icons.load('yellow.png', os.path.join(os.path.dirname(__file__), 'icons', 'yellow.png'), "IMAGE")
    if not 'purple.png' in _icons: _icons.load('purple.png', os.path.join(os.path.dirname(__file__), 'icons', 'purple.png'), "IMAGE")
    if not 'cyan.png' in _icons: _icons.load('cyan.png', os.path.join(os.path.dirname(__file__), 'icons', 'cyan.png'), "IMAGE")
    bpy.utils.register_class(SNA_OT_Operator001_05281)
    bpy.utils.register_class(SNA_OT_Operator003_D462C)
    bpy.utils.register_class(SNA_OT_Operator004_D6Bee)
    bpy.utils.register_class(SNA_OT_Operator005_2A676)
    bpy.utils.register_class(SNA_OT_Operator006_Dda67)
    bpy.utils.register_class(SNA_OT_Operator007_17Ad2)
    bpy.utils.register_class(SNA_OT_Operator008_A3Fb7)
    bpy.utils.register_class(SNA_OT_Operator002_2A623)
    bpy.utils.register_class(SNA_OT_Operator_6Aa4F)
    bpy.utils.register_class(SNA_AddonPreferences_C113E)
    bpy.utils.register_class(SNA_PT_IK_BB533)
    bpy.utils.register_class(SNA_PT_panel_CAA15)
    bpy.utils.register_class(SNA_PT__EB9A7)
    bpy.utils.register_class(SNA_PT__76238)
    bpy.utils.register_class(SNA_PT_MMD_13483)
    bpy.utils.register_class(SNA_PT_MMD_D0266)
    bpy.utils.register_class(SNA_PT__DD0E8)
    bpy.utils.register_class(SNA_PT__6A6A3)
    bpy.utils.register_class(SNA_PT__CA667)
    bpy.utils.register_class(SNA_PT_UV_C5809)
    bpy.utils.register_class(SNA_PT__3C27A)
    bpy.utils.register_class(SNA_PT__3C09E)
    bpy.utils.register_class(SNA_PT_panel_0AC32)
    bpy.utils.register_class(SNA_UL_display_collection_list_B793B)
    bpy.utils.register_class(SNA_PT_bake_tex_955B8)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator002_ac0a6', 'E', 'PRESS',
        ctrl=True, alt=False, shift=True, repeat=False)
    addon_keymaps['21D05'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator001_05281', 'NUMPAD_2', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['0B307'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator003_d462c', 'NUMPAD_4', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['B5C32'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator004_d6bee', 'NUMPAD_5', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['0CA9A'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator005_2a676', 'NUMPAD_6', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['56E3A'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator006_dda67', 'NUMPAD_7', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['BE0FA'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator007_17ad2', 'NUMPAD_8', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['D590C'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator008_a3fb7', 'NUMPAD_9', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['EA13A'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator002_2a623', 'NUMPAD_3', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['D3C04'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.operator_6aa4f', 'NUMPAD_1', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['FCCB2'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_ik_fix_on
    del bpy.types.Scene.sna_display_ver_size
    del bpy.types.Scene.sna_display_ver_color
    del bpy.types.Scene.sna_display_ver_id
    del bpy.types.Scene.sna_use_choose_tex
    del bpy.types.Scene.sna_bake_tex_size_y
    del bpy.types.Scene.sna_bake_tex_size_x
    del bpy.types.Scene.sna_obj_list_pointer_id
    del bpy.types.Scene.sna_obj_list
    del bpy.types.Scene.sna_obj_list_id
    del bpy.types.Scene.sna_remove_transform_constraint
    del bpy.types.Scene.sna_disable_keyframe_switch
    del bpy.types.Scene.sna_view_tex
    del bpy.types.Scene.sna_open
    del bpy.types.Scene.sna_time
    del bpy.types.Scene.sna_render_time_id
    del bpy.types.Scene.sna_is_render
    del bpy.types.Scene.sna_render_list
    del bpy.types.Scene.sna_id
    del bpy.types.Scene.sna_new_property_004
    del bpy.types.Scene.sna_new_property_003
    del bpy.types.Scene.sna_new_property_002
    del bpy.types.Scene.sna_new_property_001
    del bpy.types.Scene.sna_new_property
    del bpy.types.Scene.sna_bili
    bpy.utils.unregister_class(SNA_GROUP_sna_obj_list_property)
    bpy.utils.unregister_class(SNA_GROUP_sna_obj_list_pointer)
    bpy.utils.unregister_class(SNA_GROUP_sna_render_time)
    bpy.utils.unregister_class(SNA_GROUP_sna_render_list_property)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_C8494)
    bpy.utils.unregister_class(SNA_OT_Ik_B204A)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_C3269)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_Cc136)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_89058)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_C034B)
    bpy.utils.unregister_class(SNA_OT_Operator015_0Ebb1)
    bpy.utils.unregister_class(SNA_OT_Operator013_2E178)
    bpy.types.CYCLES_LIGHT_PT_light.remove(sna_add_to_cycles_light_pt_light_B5682)
    bpy.utils.unregister_class(SNA_OT_Operator019_8Aa9A)
    bpy.utils.unregister_class(SNA_OT_Operator017_E38Ed)
    bpy.utils.unregister_class(SNA_OT_Operator018_Bf94B)
    bpy.utils.unregister_class(SNA_OT_Operator016_2E985)
    bpy.app.handlers.frame_change_post.remove(frame_change_post_handler_1BDE6)
    bpy.types.TIME_MT_editor_menus.remove(sna_add_to_time_mt_editor_menus_BB1C8)
    bpy.types.DOPESHEET_HT_header.remove(sna_add_to_dopesheet_ht_header_9E879)
    bpy.utils.unregister_class(SNA_OT_Operator024_D37Ce)
    bpy.utils.unregister_class(SNA_OT_Operator023_Dc120)
    bpy.utils.unregister_class(SNA_OT_Operator021_0D655)
    bpy.utils.unregister_class(SNA_OT_Operator005_9368B)
    bpy.utils.unregister_class(SNA_OT_Operator006_42368)
    bpy.utils.unregister_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.unregister_class(SNA_OT_Operator025_4038C)
    bpy.utils.unregister_class(SNA_OT_Operator001_64C4A)
    bpy.utils.unregister_class(SNA_OT_Operator_B46A6)
    bpy.utils.unregister_class(SNA_OT_Operator007_85779)
    bpy.utils.unregister_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.unregister_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.unregister_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.remove(sna_add_to_render_pt_format_DCB79)
    bpy.utils.unregister_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.unregister_class(SNA_PT_MMD_9FB97)
    bpy.utils.unregister_class(SNA_OT_Mtl_78668)
    bpy.utils.unregister_class(SNA_OT_Operator020_173C4)
    bpy.utils.unregister_class(SNA_OT_Operator022_D211D)
    bpy.utils.unregister_class(SNA_OT_Operator023_9E188)
    bpy.utils.unregister_class(SNA_OT_Operator024_1Bdb7)
    bpy.utils.unregister_class(SNA_OT_Operator025_C68F6)
    bpy.utils.unregister_class(SNA_OT_Operator002_Ac0A6)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_FC05E)
    bpy.utils.unregister_class(SNA_OT_Operator001_1136E)
    bpy.utils.unregister_class(SNA_OT_Operator_5Ed64)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_400A9)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_E6Bd2)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_E9B48)
    bpy.types.OUTLINER_HT_header.remove(sna_add_to_outliner_ht_header_1E9B6)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_Cf418)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_98B5F)
    bpy.types.OBJECT_PT_constraints.remove(sna_add_to_object_pt_constraints_25BA8)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_Cde4F)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_2B24E)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_F6DBF)
    bpy.utils.unregister_class(SNA_PT_panel_A0042)
    bpy.utils.unregister_class(SNA_OT_Operator_5F6B3)
    bpy.utils.unregister_class(SNA_OT_Uv_94B57)
    bpy.utils.unregister_class(SNA_OT_Uv_9201E)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_Bedaf)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_04Cf5)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_60634)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_B74Af)
    bpy.utils.unregister_class(SNA_OT_Down_25Ee0)
    bpy.utils.unregister_class(SNA_OT_Up_B66Ca)
    bpy.utils.unregister_class(SNA_OT_Add_Render_List_84292)
    bpy.utils.unregister_class(SNA_OT_Remove_Render_List_E8059)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_5874F)
    bpy.app.handlers.render_complete.remove(render_complete_handler_825EB)
    bpy.app.handlers.render_complete.remove(render_complete_handler_C420C)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_33F13)
    bpy.app.handlers.render_cancel.remove(render_cancel_handler_58683)
    bpy.app.handlers.render_post.remove(render_post_handler_4E079)
    bpy.app.handlers.render_pre.remove(render_pre_handler_1092E)
    bpy.app.handlers.render_post.remove(render_post_handler_15713)
    bpy.utils.unregister_class(SNA_OT_Operator_Cc77E)
    bpy.app.handlers.render_post.remove(render_post_handler_B2801)
    bpy.utils.unregister_class(SNA_OT_Add_Obj_List_6C8D9)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_72Cae)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_C6C4F)
    bpy.utils.unregister_class(SNA_OT_Add_Obj_List_Pointer_3Ad57)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_1632D)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_F1Fff)
    bpy.utils.unregister_class(SNA_OT_Remove_Obj_List_Pointer_75A67)
    bpy.utils.unregister_class(SNA_OT_Remove_Obj_List_063B1)
    bpy.utils.unregister_class(SNA_PT__E64C1)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_E8A78)
    bpy.utils.unregister_class(SNA_UL_display_collection_list001_8124D)
    bpy.utils.unregister_class(SNA_PT_MMD_QUICK_TOOL_MATERIAL_C3756)
    bpy.utils.unregister_class(SNA_OT_Bake_Tex_F278F)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_D53B4)
    bpy.utils.unregister_class(SNA_OT_Operator001_05281)
    bpy.utils.unregister_class(SNA_OT_Operator003_D462C)
    bpy.utils.unregister_class(SNA_OT_Operator004_D6Bee)
    bpy.utils.unregister_class(SNA_OT_Operator005_2A676)
    bpy.utils.unregister_class(SNA_OT_Operator006_Dda67)
    bpy.utils.unregister_class(SNA_OT_Operator007_17Ad2)
    bpy.utils.unregister_class(SNA_OT_Operator008_A3Fb7)
    bpy.utils.unregister_class(SNA_OT_Operator002_2A623)
    bpy.utils.unregister_class(SNA_OT_Operator_6Aa4F)
    bpy.utils.unregister_class(SNA_AddonPreferences_C113E)
    bpy.utils.unregister_class(SNA_PT_IK_BB533)
    bpy.utils.unregister_class(SNA_PT_panel_CAA15)
    bpy.utils.unregister_class(SNA_PT__EB9A7)
    bpy.utils.unregister_class(SNA_PT__76238)
    bpy.utils.unregister_class(SNA_PT_MMD_13483)
    bpy.utils.unregister_class(SNA_PT_MMD_D0266)
    bpy.utils.unregister_class(SNA_PT__DD0E8)
    bpy.utils.unregister_class(SNA_PT__6A6A3)
    bpy.utils.unregister_class(SNA_PT__CA667)
    bpy.utils.unregister_class(SNA_PT_UV_C5809)
    bpy.utils.unregister_class(SNA_PT__3C27A)
    bpy.utils.unregister_class(SNA_PT__3C09E)
    bpy.utils.unregister_class(SNA_PT_panel_0AC32)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_B793B)
    bpy.utils.unregister_class(SNA_PT_bake_tex_955B8)
