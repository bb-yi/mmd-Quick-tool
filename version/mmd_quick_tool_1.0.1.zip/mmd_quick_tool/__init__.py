# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "mmd Quick tool",
    "author" : "SFY", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper


addon_keymaps = {}
_icons = None


def sna_update_sna_bili_31149(self, context):
    sna_updated_prop = self.sna_bili
    print(sna_updated_prop)
    if sna_updated_prop == "1:1":
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
    elif sna_updated_prop == "3:2":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(3.0 / 2.0))
    elif sna_updated_prop == "4:3":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(4.0 / 3.0))
    elif sna_updated_prop == "16:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(16.0 / 9.0))
    elif sna_updated_prop == "14:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(14.0 / 9.0))
    elif sna_updated_prop == "1.85:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(1.850000023841858 / 1.0))
    elif sna_updated_prop == "2.39:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(2.390000104904175 / 1.0))
    else:
        pass


def sna_update_sna_new_property_001_7222D(self, context):
    sna_updated_prop = self.sna_new_property_001
    print(sna_updated_prop)
    if sna_updated_prop == "15":
        bpy.data.lights[bpy.context.active_object.name].spread = float(15 * 0.01745299994945526)
    elif sna_updated_prop == "60":
        bpy.data.lights[bpy.context.active_object.name].spread = float(60 * 0.01745299994945526)
    elif sna_updated_prop == "90":
        bpy.data.lights[bpy.context.active_object.name].spread = float(90 * 0.01745299994945526)
    elif sna_updated_prop == "120":
        bpy.data.lights[bpy.context.active_object.name].spread = float(120 * 0.01745299994945526)
    elif sna_updated_prop == "180":
        bpy.data.lights[bpy.context.active_object.name].spread = float(180 * 0.01745299994945526)
    elif sna_updated_prop == "0":
        bpy.data.lights[bpy.context.active_object.name].spread = float(0 * 0.01745299994945526)
    else:
        pass


class SNA_OT_Operator001_64C4A(bpy.types.Operator):
    bl_idname = "sna.operator001_64c4a"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 2560
        bpy.context.scene.render.resolution_y = 1440
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_B46A6(bpy.types.Operator):
    bl_idname = "sna.operator_b46a6"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator003_F8Ede(bpy.types.Operator):
    bl_idname = "sna.operator003_f8ede"
    bl_label = "Operator.003"
    bl_description = "更改材质名称为网格名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前场景
        scene = bpy.context.scene
        # 获取所选物体列表
        selected_objects = bpy.context.selected_objects
        # 循环遍历所选物体
        for obj in selected_objects:
            # 获取物体的第一个材质
            material = obj.data.materials[0] if obj.data.materials else None
            # 如果物体有材质，则将物体名称更改为材质名称
            if material:
                obj.name = material.name
                print(f"Object {obj.name} renamed to {material.name}")
            else:
                print(f"Object {obj.name} has no materials")
        # 更新场景
        bpy.context.view_layer.update()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator011_9D3Ab(bpy.types.Operator):
    bl_idname = "sna.operator011_9d3ab"
    bl_label = "Operator.011"
    bl_description = "更改网格名称为材质名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def rename_materials_to_objects():
            # 获取当前选择的物体
            selected_objects = bpy.context.selected_objects
            for obj in selected_objects:
                # 获取物体的第一个材质
                material = obj.active_material
                if material:
                    # 将材质的名称设置为物体的名称
                    material.name = obj.name
                else:
                    print(f"Object {obj.name} has no material.")
        if __name__ == "__main__":
            rename_materials_to_objects()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator012_Bbb3C(bpy.types.Operator):
    bl_idname = "sna.operator012_bbb3c"
    bl_label = "Operator.012"
    bl_description = "更改贴图名称为基础色贴图名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def rename_materials_to_base_color_texture():
            # 获取当前选择的物体
            selected_objects = bpy.context.selected_objects
            for obj in selected_objects:
                # 获取物体的第一个材质
                material = obj.active_material
                base_color_texture_node = None
                # 定义可能的基础色输入端口名称列表
                possible_base_color_input_names = ["Color", "Base Color", "Diffuse Color", "Albedo","Base Tex"]
                if material:
                    # 遍历节点图中的所有节点
                    for node in material.node_tree.nodes:
                        # 检查节点是否是 'TEX_IMAGE' 类型
                        if node.type == 'TEX_IMAGE':
                            # 遍历可能的基础色输入端口名称
                            for base_color_input_name in possible_base_color_input_names:
                                # 检查节点的 "Color" 输出端口是否连接到其他节点的基础色输入端口
                                if any(link.to_socket.name == base_color_input_name for link in node.outputs['Color'].links):
                                    base_color_texture_node = node
                                    break
                            if base_color_texture_node:
                                break  # 如果找到匹配的节点，退出外层循环
                    if base_color_texture_node:
                        # 获取贴图的名称并设置为材质的名称
                        texture_name = base_color_texture_node.image.name
                        material.name = texture_name
                else:
                    print(f"Object {obj.name} has no material.")
        if __name__ == "__main__":
            rename_materials_to_base_color_texture()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator007_85779(bpy.types.Operator):
    bl_idname = "sna.operator007_85779"
    bl_label = "Operator.007"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_ax: bpy.props.IntProperty(name='ax', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        self.sna_ax = bpy.context.scene.render.resolution_x
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_y = self.sna_ax
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator008_F7B4C(bpy.types.Operator):
    bl_idname = "sna.operator008_f7b4c"
    bl_label = "Operator.008"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x / 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y / 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator002_7Dbd9(bpy.types.Operator):
    bl_idname = "sna.operator002_7dbd9"
    bl_label = "Operator.002"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 3840
        bpy.context.scene.render.resolution_y = 2160
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator014_47F89(bpy.types.Operator):
    bl_idname = "sna.operator014_47f89"
    bl_label = "Operator.014"
    bl_description = "方形"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1920
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_render_pt_format_6423A(self, context):
    if not (False):
        layout = self.layout
        row_96091 = layout.row(heading='', align=False)
        row_96091.alert = False
        row_96091.enabled = True
        row_96091.active = True
        row_96091.use_property_split = False
        row_96091.use_property_decorate = False
        row_96091.scale_x = 1.0
        row_96091.scale_y = 1.0
        row_96091.alignment = 'Center'.upper()
        if not True: row_96091.operator_context = "EXEC_DEFAULT"
        row_96091.prop(bpy.data.scenes['Scene'].render, 'film_transparent', text='透明', icon_value=0, emboss=True)
        row_96091.prop(bpy.data.scenes['Scene'].render, 'use_persistent_data', text='持久数据', icon_value=0, emboss=True)


def sna_add_to_cycles_light_pt_light_A9602(self, context):
    if not (False):
        layout = self.layout
        row_81A38 = layout.row(heading='', align=True)
        row_81A38.alert = False
        row_81A38.enabled = True
        row_81A38.active = True
        row_81A38.use_property_split = False
        row_81A38.use_property_decorate = False
        row_81A38.scale_x = 1.0
        row_81A38.scale_y = 1.0
        row_81A38.alignment = 'Expand'.upper()
        if not True: row_81A38.operator_context = "EXEC_DEFAULT"
        op = row_81A38.operator('sna.operator013_2e178', text='随机灯光颜色', icon_value=239, emboss=True, depress=False)
        row_8C7A0 = layout.row(heading='', align=True)
        row_8C7A0.alert = False
        row_8C7A0.enabled = True
        row_8C7A0.active = True
        row_8C7A0.use_property_split = False
        row_8C7A0.use_property_decorate = False
        row_8C7A0.scale_x = 1.0
        row_8C7A0.scale_y = 1.0
        row_8C7A0.alignment = 'Expand'.upper()
        if not True: row_8C7A0.operator_context = "EXEC_DEFAULT"
        row_8C7A0.prop(bpy.context.scene, 'sna_new_property_001', text='灯光角度', icon_value=0, emboss=True, expand=True)


class SNA_OT_Operator013_2E178(bpy.types.Operator):
    bl_idname = "sna.operator013_2e178"
    bl_label = "Operator.013"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import random

        def set_random_light_colors():
            # 获取当前选择的灯光对象
            selected_lights = [obj for obj in bpy.context.selected_objects if obj.type == 'LIGHT']
            for light in selected_lights:
                # 检查灯光是否有 color 属性
                if hasattr(light.data, 'color'):
                    # 生成随机颜色
                    random_color = [random.uniform(0, 1) for _ in range(3)]
                    # 设置灯光的颜色
                    light.data.color = random_color
        if __name__ == "__main__":
            set_random_light_colors()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator004_Fa32A(bpy.types.Operator):
    bl_idname = "sna.operator004_fa32a"
    bl_label = "Operator.004"
    bl_description = "合并使用同一基础色贴图的材质"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 存储贴图的字典
        texture_dict = {}
        color_input_name=["Color", "Base Color", "Diffuse Color", "Albedo","Base Tex"]
        # 获取所选物体列表
        selected_objects = bpy.context.selected_objects
        # 循环遍历所选物体
        for obj in selected_objects:
            # 检查物体是否为网格对象
            if isinstance(obj.data, bpy.types.Mesh):
                # 遍历物体的材质列表
                for material in obj.data.materials:
                    # 获取材质的节点树
                    tree = material.node_tree
                    # 遍历节点树中的所有节点
                    for node in tree.nodes:
                        # 检查节点类型是否为ShaderNodeTexImage（贴图节点）
                        if node.type == 'TEX_IMAGE':
                            # 检查节点的输出连接是否存在
                            if node.outputs['Color'].is_linked:
                                # 遍历节点的输出连接
                                for link in node.outputs['Color'].links:
                                    # 检查连接的输入端口名称是否为"基础颜色"
                                    for input_name in color_input_name:
                                        if link.to_socket.name == input_name:
                                            # 检查贴图是否已经在字典中
                                            if node.image.name not in texture_dict:
                                                # 将贴图节点添加到字典
                                                texture_dict[node.image.name] = material
                                                print('贴图已经在字典中', node.image.name)
                                            else:
                                                # 替换材质为字典中的材质
                                                new_material = texture_dict[node.image.name]
                                                # 将物体的材质更改为新的材质
                                                obj.data.materials[0] = new_material
                                                print('贴图不在字典中', node.image.name, '替换材质:', new_material.name)
                                    else:
                                        print('连接端口的贴图没找到')
                        else:
                            print("没有找到贴图")
            else:
                print('没有找到网格对象')
        #清理未使用数据块
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        # 设置材质的名称为贴图名称
        for tex_name, material in texture_dict.items():
            material.name = tex_name
        # 打印贴图字典
        print(texture_dict)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator005_9368B(bpy.types.Operator):
    bl_idname = "sna.operator005_9368b"
    bl_label = "Operator.005"
    bl_description = "将替换mmd自带节点组为原理化节点组"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前选中的物体
        selected_objects = bpy.context.selected_objects
        # 遍历选中的物体
        for obj in selected_objects:
            # 遍历物体的所有材质槽
            for material_slot in obj.material_slots:
                material = material_slot.material
                # 遍历材质的所有节点
                for node in material.node_tree.nodes:
                    # 检查节点的类型和名称
                    if node.type == 'GROUP' and node.node_tree.name == 'MMDShaderDev':  # 替换为你的节点组名称
                        # 获取节点组的输入
                        base_tex_input = node.inputs.get('Base Tex')
                        base_alpha_input = node.inputs.get('Base Alpha')
                        # 如果找到对应的输入，继续处理
                        if base_tex_input and base_alpha_input:
                            # 获取连接到 Base Tex 和 Base Alpha 的连接
                            base_tex_link = base_tex_input.links[0] if base_tex_input.links else None
                            base_alpha_link = base_alpha_input.links[0] if base_alpha_input.links else None
                            # 创建新的原理化节点
                            principled_node = material.node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
                            principled_node.location = node.location
                            # 连接 Base Tex
                            if base_tex_link:
                                material.node_tree.links.new(principled_node.inputs['Base Color'], base_tex_link.from_socket)
                            # 连接 Base Alpha
                            if base_alpha_link:
                                material.node_tree.links.new(principled_node.inputs['Alpha'], base_alpha_link.from_socket)
                            # 连接新原理化节点到材质输出
                            material_output_node = material.node_tree.nodes.get("Material Output")
                            if material_output_node:
                                material.node_tree.links.new(material_output_node.inputs['Surface'], principled_node.outputs['BSDF'])
                            # 删除旧的节点
                            material.node_tree.nodes.remove(node)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator010_78668(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.operator010_78668"
    bl_label = "Operator.010"
    bl_description = "选择mtl文件，贴图需要和mtl文件在同一个文件夹内"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.mtl', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        file_path = self.filepath
        import re
        # 脚本 by 三分仪
        # 将alembic_file.mtl所在路径复制进去，贴图和alembic_file.mtl在同一文件夹下
        #file_path = r'E:\mmd_project\绯色回响mmd\wj\alembic_file.mtl'
        materials = {}
        with open(file_path, 'r', encoding='gbk') as f:
            current_material = None
            for line in f:
                if line.startswith("newmtl"):
                    current_material = line.split()[1]
                    materials[current_material] = {}
                elif line.startswith("map_Kd"):
                    texture = line.split()[1:]
                    texture_name = " ".join(texture)
                    if current_material is not None:
                        materials[current_material]["map_Kd"] = texture_name
        new_materials_dict = {}
        for i, (key, value) in enumerate(materials.items()):
            new_key = f'xform_0_material_{i}'
            new_materials_dict[new_key] = value
        # Check if 'map_Kd' exists before trying to access it
        materials = {k: v.get('map_Kd', '') for k, v in new_materials_dict.items()}
        # Output the new dictionary
        print(materials)
        for key, value in materials.items():
            obj = bpy.data.objects[key]
            mat = bpy.data.materials.new(name=value)
            # 设置该材质使用节点
            mat.use_nodes = True
            # 创建一个新的Image纹理节点
            tex = mat.node_tree.nodes.new('ShaderNodeTexImage')
            tex.location = (-300, 300)
            new_name = value
            new_path = file_path.replace(file_path.split('\\')[-1], new_name)
            print(new_path)
            # 设置纹理图片路径
            tex.image = bpy.data.images.load(new_path)
            # 获取Diffuse BSDF节点
            bsdf = mat.node_tree.nodes.get('Principled BSDF')
            # 将Image纹理节点连接到Diffuse BSDF节点的Base Color输入
            mat.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            mat.node_tree.links.new(tex.outputs['Alpha'], bsdf.inputs['Alpha'])
            # 赋予材质
            obj.data.materials.append(mat)
            # 遍历所有物体
            for obj in bpy.data.objects:
                # 判断物体名称中是否含有 xform_0_material
                if "xform_0_material" in obj.name:
                    # 遍历该物体的材质
                    for mat_slot in obj.material_slots:
                        # 获取材质
                        mat = mat_slot.material
                        # 判断材质名称中是否含有序号
                        if re.search(r"\.\d+", mat.name):
                            # 替换材质名称为没有序号的名称
                            new_name = re.sub(r"\.\d+", "", mat.name)
                            mat_slot.material = bpy.data.materials[new_name]
            # 清理未使用的数据块
            bpy.ops.outliner.orphans_purge()
        return {"FINISHED"}


class SNA_OT_Operator006_42368(bpy.types.Operator):
    bl_idname = "sna.operator006_42368"
    bl_label = "Operator.006"
    bl_description = "将对mmd导入的相机进行修复"
    bl_options = {"REGISTER", "UNDO"}
    sna_new_property: bpy.props.StringProperty(name='相机名称', description='', default='', subtype='NONE', maxlen=0)
    sna_new_property_001: bpy.props.IntProperty(name='帧偏移', description='', default=0, subtype='NONE')
    sna_new_property_001: bpy.props.StringProperty(name='相机空物体名称', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        camera_name = None
        Advance_frame = None
        MMD_Camera = None
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator009_F9Bf5(bpy.types.Operator):
    bl_idname = "sna.operator009_f9bf5"
    bl_label = "Operator.009"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x * 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y * 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_MMD_BC42C(bpy.types.Panel):
    bl_label = 'mmd快速工具'
    bl_idname = 'SNA_PT_MMD_BC42C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'MMD'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_D8987 = layout.box()
        box_D8987.alert = False
        box_D8987.enabled = True
        box_D8987.active = True
        box_D8987.use_property_split = False
        box_D8987.use_property_decorate = False
        box_D8987.alignment = 'Expand'.upper()
        box_D8987.scale_x = 1.0
        box_D8987.scale_y = 1.0
        if not True: box_D8987.operator_context = "EXEC_DEFAULT"
        col_9EBA4 = box_D8987.column(heading='', align=False)
        col_9EBA4.alert = False
        col_9EBA4.enabled = True
        col_9EBA4.active = True
        col_9EBA4.use_property_split = False
        col_9EBA4.use_property_decorate = False
        col_9EBA4.scale_x = 1.0
        col_9EBA4.scale_y = 1.0
        col_9EBA4.alignment = 'Expand'.upper()
        if not True: col_9EBA4.operator_context = "EXEC_DEFAULT"
        col_9EBA4.label(text='名称编辑', icon_value=197)
        row_38F6B = col_9EBA4.row(heading='', align=False)
        row_38F6B.alert = False
        row_38F6B.enabled = True
        row_38F6B.active = True
        row_38F6B.use_property_split = False
        row_38F6B.use_property_decorate = False
        row_38F6B.scale_x = 1.0
        row_38F6B.scale_y = 1.0
        row_38F6B.alignment = 'Expand'.upper()
        if not True: row_38F6B.operator_context = "EXEC_DEFAULT"
        op = row_38F6B.operator('sna.operator003_f8ede', text='材质到网格', icon_value=0, emboss=True, depress=False)
        op = row_38F6B.operator('sna.operator011_9d3ab', text='网格到材质', icon_value=0, emboss=True, depress=False)
        op = row_38F6B.operator('sna.operator012_bbb3c', text='贴图到材质', icon_value=0, emboss=True, depress=False)
        col_85326 = layout.column(heading='', align=False)
        col_85326.alert = False
        col_85326.enabled = True
        col_85326.active = True
        col_85326.use_property_split = False
        col_85326.use_property_decorate = False
        col_85326.scale_x = 1.0
        col_85326.scale_y = 1.0
        col_85326.alignment = 'Expand'.upper()
        if not True: col_85326.operator_context = "EXEC_DEFAULT"
        op = col_85326.operator('sna.operator004_fa32a', text='合并相同贴图的材质', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator005_9368b', text='替换mmd材质节点组', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator010_78668', text='为abc添加材质', icon_value=0, emboss=True, depress=False)
        col_52A12 = layout.column(heading='', align=True)
        col_52A12.alert = False
        col_52A12.enabled = True
        col_52A12.active = True
        col_52A12.use_property_split = False
        col_52A12.use_property_decorate = False
        col_52A12.scale_x = 1.0
        col_52A12.scale_y = 1.0
        col_52A12.alignment = 'Center'.upper()
        if not True: col_52A12.operator_context = "EXEC_DEFAULT"
        col_52A12.separator(factor=1.003000020980835)
        col_52A12.label(text='如果导入mmd相机后经常闪退可以试试这个', icon_value=0)
        op = col_52A12.operator('sna.operator006_42368', text='相机闪退修复', icon_value=0, emboss=True, depress=False)
        op.sna_new_property = 'Camera'
        op.sna_new_property_001 = 0
        op.sna_new_property_001 = 'MMD_Camera'


class SNA_PT__F6C6B(bpy.types.Panel):
    bl_label = '分辨率调整'
    bl_idname = 'SNA_PT__F6C6B'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_format'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_9A4A1 = layout.row(heading='', align=False)
        row_9A4A1.alert = False
        row_9A4A1.enabled = True
        row_9A4A1.active = True
        row_9A4A1.use_property_split = False
        row_9A4A1.use_property_decorate = False
        row_9A4A1.scale_x = 1.0
        row_9A4A1.scale_y = 1.0
        row_9A4A1.alignment = 'Left'.upper()
        if not True: row_9A4A1.operator_context = "EXEC_DEFAULT"
        op = row_9A4A1.operator('sna.operator_b46a6', text='1080p', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator001_64c4a', text='2k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator002_7dbd9', text='4k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator007_85779', text='交换', icon_value=692, emboss=True, depress=False)
        op.sna_ax = 7
        op = row_9A4A1.operator('sna.operator008_f7b4c', text='*0.5', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator009_f9bf5', text='*2', icon_value=0, emboss=True, depress=False)
        row_3E7EE = layout.row(heading='', align=False)
        row_3E7EE.alert = False
        row_3E7EE.enabled = True
        row_3E7EE.active = True
        row_3E7EE.use_property_split = False
        row_3E7EE.use_property_decorate = False
        row_3E7EE.scale_x = 1.0
        row_3E7EE.scale_y = 1.0
        row_3E7EE.alignment = 'Left'.upper()
        if not True: row_3E7EE.operator_context = "EXEC_DEFAULT"
        row_3E7EE.prop(bpy.context.scene, 'sna_bili', text='比例', icon_value=0, emboss=True, expand=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_bili = bpy.props.EnumProperty(name='bili', description='', items=[('自定义', '自定义', '', 0, 0), ('1:1', '1:1', '', 0, 1), ('3:2', '3:2', '', 0, 2), ('4:3', '4:3', '', 0, 3), ('16:9', '16:9', '', 0, 4), ('14:9', '14:9', '', 0, 5), ('1.85:1', '1.85:1', '', 0, 6), ('2.39:1', '2.39:1', '', 0, 7)], update=sna_update_sna_bili_31149)
    bpy.types.Scene.sna_new_property = bpy.props.BoolProperty(name='锁定比例', description='', default=False)
    bpy.types.Scene.sna_new_property_001 = bpy.props.EnumProperty(name='灯光角度', description='', items=[('自定义', '自定义', '', 0, 0), ('0', '0', '', 0, 1), ('15', '15', '', 0, 2), ('60', '60', '', 0, 3), ('90', '90', '', 0, 4), ('120', '120', '', 0, 5), ('180', '180', '', 0, 6)], update=sna_update_sna_new_property_001_7222D)
    bpy.utils.register_class(SNA_OT_Operator001_64C4A)
    bpy.utils.register_class(SNA_OT_Operator_B46A6)
    bpy.utils.register_class(SNA_OT_Operator003_F8Ede)
    bpy.utils.register_class(SNA_OT_Operator011_9D3Ab)
    bpy.utils.register_class(SNA_OT_Operator012_Bbb3C)
    bpy.utils.register_class(SNA_OT_Operator007_85779)
    bpy.utils.register_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.register_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.register_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.append(sna_add_to_render_pt_format_6423A)
    bpy.types.CYCLES_LIGHT_PT_light.append(sna_add_to_cycles_light_pt_light_A9602)
    bpy.utils.register_class(SNA_OT_Operator013_2E178)
    bpy.utils.register_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.register_class(SNA_OT_Operator005_9368B)
    bpy.utils.register_class(SNA_OT_Operator010_78668)
    bpy.utils.register_class(SNA_OT_Operator006_42368)
    bpy.utils.register_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.register_class(SNA_PT_MMD_BC42C)
    bpy.utils.register_class(SNA_PT__F6C6B)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_new_property_001
    del bpy.types.Scene.sna_new_property
    del bpy.types.Scene.sna_bili
    bpy.utils.unregister_class(SNA_OT_Operator001_64C4A)
    bpy.utils.unregister_class(SNA_OT_Operator_B46A6)
    bpy.utils.unregister_class(SNA_OT_Operator003_F8Ede)
    bpy.utils.unregister_class(SNA_OT_Operator011_9D3Ab)
    bpy.utils.unregister_class(SNA_OT_Operator012_Bbb3C)
    bpy.utils.unregister_class(SNA_OT_Operator007_85779)
    bpy.utils.unregister_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.unregister_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.unregister_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.remove(sna_add_to_render_pt_format_6423A)
    bpy.types.CYCLES_LIGHT_PT_light.remove(sna_add_to_cycles_light_pt_light_A9602)
    bpy.utils.unregister_class(SNA_OT_Operator013_2E178)
    bpy.utils.unregister_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.unregister_class(SNA_OT_Operator005_9368B)
    bpy.utils.unregister_class(SNA_OT_Operator010_78668)
    bpy.utils.unregister_class(SNA_OT_Operator006_42368)
    bpy.utils.unregister_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.unregister_class(SNA_PT_MMD_BC42C)
    bpy.utils.unregister_class(SNA_PT__F6C6B)
