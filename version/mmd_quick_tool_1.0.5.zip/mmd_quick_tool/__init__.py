# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "mmd Quick tool",
    "author" : "SFY", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 5),
    "location" : "",
    "warning" : "",
    "doc_url": "https://github.com/bb-yi/mmd-Quick-tool", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import mathutils
import os
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy.app.handlers import persistent
from datetime import datetime


addon_keymaps = {}
_icons = None
node_tree_001 = {'sna_sub_render_time': 0.0, 'sna_avg_render_time': 0.0, 'sna_sub_frame': 0, 'sna_current_frame': 0, 'sna_default_camera': '', 'sna_default_frame_start': 0, 'sna_default_frame_end': 0, 'sna_default_output_directory': '', }


def sna_update_sna_bili_31149(self, context):
    sna_updated_prop = self.sna_bili
    print(sna_updated_prop)
    if sna_updated_prop == "1:1":
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
    elif sna_updated_prop == "3:2":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(3.0 / 2.0))
    elif sna_updated_prop == "4:3":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(4.0 / 3.0))
    elif sna_updated_prop == "16:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(16.0 / 9.0))
    elif sna_updated_prop == "14:9":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(14.0 / 9.0))
    elif sna_updated_prop == "1.85:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(1.850000023841858 / 1.0))
    elif sna_updated_prop == "2.39:1":
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_y * float(2.390000104904175 / 1.0))
    else:
        pass


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_update_sna_new_property_003_1E44E(self, context):
    sna_updated_prop = self.sna_new_property_003
    if sna_updated_prop:
        bpy.context.preferences.view.language = 'zh_CN'
        bpy.context.preferences.view.use_translate_new_dataname = False
    else:
        bpy.context.preferences.view.language = 'en_US'


def sna_update_sna_new_property_001_7222D(self, context):
    sna_updated_prop = self.sna_new_property_001
    print(sna_updated_prop)
    if sna_updated_prop == "15":
        bpy.data.lights[bpy.context.active_object.name].spread = float(15 * 0.01745299994945526)
    elif sna_updated_prop == "60":
        bpy.data.lights[bpy.context.active_object.name].spread = float(60 * 0.01745299994945526)
    elif sna_updated_prop == "90":
        bpy.data.lights[bpy.context.active_object.name].spread = float(90 * 0.01745299994945526)
    elif sna_updated_prop == "120":
        bpy.data.lights[bpy.context.active_object.name].spread = float(120 * 0.01745299994945526)
    elif sna_updated_prop == "180":
        bpy.data.lights[bpy.context.active_object.name].spread = float(180 * 0.01745299994945526)
    elif sna_updated_prop == "0":
        bpy.data.lights[bpy.context.active_object.name].spread = float(0 * 0.01745299994945526)
    else:
        pass


def sna_update_sna_new_property_004_0F02E(self, context):
    sna_updated_prop = self.sna_new_property_004
    timemax_0_02639 = sna_setmaxi_454ED(sna_updated_prop)
    frame_0_85032, s_1_85032 = sna_time2frameinput_2F52D(timemax_0_02639)
    if bpy.context.scene.sna_open:
        bpy.context.scene.frame_current = frame_0_85032
        bpy.context.scene.sna_new_property_004 = timemax_0_02639


def sna_update_render_camera_28727(self, context):
    sna_updated_prop = self.render_camera
    for i_18B62 in range(len(bpy.context.scene.sna_render_list)):
        if (bpy.context.scene.sna_render_list[i_18B62].render_camera == None):
            pass
        else:
            if ((bpy.context.scene.sna_render_list[i_18B62].render_camera != None) and bpy.context.scene.sna_render_list[i_18B62].render_camera.type == 'CAMERA'):
                pass
            else:
                bpy.context.scene.sna_render_list[i_18B62].render_camera = None


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_B793B(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_B793B, icon, active_data, active_propname, index_B793B):
        row = layout
        layout.prop(item_B793B, 'on', text='', icon_value=(254 if item_B793B.on else 253), emboss=item_B793B.on)
        layout.prop(item_B793B, 'name', text='', icon_value=0, emboss=False)
        layout.prop(item_B793B, 'start_frame', text='开始', icon_value=0, emboss=item_B793B.on)
        layout.prop(item_B793B, 'end_frame', text='结束', icon_value=0, emboss=item_B793B.on)
        layout.prop(item_B793B, 'render_camera', text='', icon_value=168, emboss=item_B793B.on)
        layout.prop(item_B793B, 'output_directory', text='', icon_value=0, emboss=item_B793B.on)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


class SNA_OT_Operator001_64C4A(bpy.types.Operator):
    bl_idname = "sna.operator001_64c4a"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 2560
        bpy.context.scene.render.resolution_y = 1440
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator_B46A6(bpy.types.Operator):
    bl_idname = "sna.operator_b46a6"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator007_85779(bpy.types.Operator):
    bl_idname = "sna.operator007_85779"
    bl_label = "Operator.007"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_ax: bpy.props.IntProperty(name='ax', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        self.sna_ax = bpy.context.scene.render.resolution_x
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_y = self.sna_ax
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator008_F7B4C(bpy.types.Operator):
    bl_idname = "sna.operator008_f7b4c"
    bl_label = "Operator.008"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x / 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y / 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator002_7Dbd9(bpy.types.Operator):
    bl_idname = "sna.operator002_7dbd9"
    bl_label = "Operator.002"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 3840
        bpy.context.scene.render.resolution_y = 2160
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator014_47F89(bpy.types.Operator):
    bl_idname = "sna.operator014_47f89"
    bl_label = "Operator.014"
    bl_description = "方形"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1920
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_render_pt_format_0A62E(self, context):
    if not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property):
        layout = self.layout
        row_96091 = layout.row(heading='', align=False)
        row_96091.alert = False
        row_96091.enabled = True
        row_96091.active = True
        row_96091.use_property_split = False
        row_96091.use_property_decorate = False
        row_96091.scale_x = 1.0
        row_96091.scale_y = 1.0
        row_96091.alignment = 'Center'.upper()
        if not True: row_96091.operator_context = "EXEC_DEFAULT"
        row_96091.prop(bpy.data.scenes['Scene'].render, 'film_transparent', text='透明', icon_value=0, emboss=True)
        row_96091.prop(bpy.data.scenes['Scene'].render, 'use_persistent_data', text='持久数据', icon_value=0, emboss=True)


class SNA_OT_Operator009_F9Bf5(bpy.types.Operator):
    bl_idname = "sna.operator009_f9bf5"
    bl_label = "Operator.009"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.resolution_x = int(bpy.context.scene.render.resolution_x * 2.0)
        bpy.context.scene.render.resolution_y = int(bpy.context.scene.render.resolution_y * 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator015_0Ebb1(bpy.types.Operator):
    bl_idname = "sna.operator015_0ebb1"
    bl_label = "Operator.015"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_new_property_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_new_property: bpy.props.EnumProperty(name='位姿', description='', items=[('位置', '位置', '', 0, 0), ('旋转', '旋转', '', 0, 1), ('缩放', '缩放', '', 0, 2)])
    sna_x: bpy.props.BoolProperty(name='x', description='', default=True)
    sna_y: bpy.props.BoolProperty(name='y', description='', default=True)
    sna_z: bpy.props.BoolProperty(name='z', description='', default=True)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_37CB5 in range(len(bpy.context.selected_objects)):
            if (self.sna_new_property == '位置'):
                if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location", globals(), locals()):
                    bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location = tuple(mathutils.Vector((bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location if (self.sna_new_property == '位置') else (bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler if (self.sna_new_property == '旋转') else None))) * mathutils.Vector(((0 if self.sna_x else 1), (0 if self.sna_y else 1), (0 if self.sna_z else 1))))
            else:
                if (self.sna_new_property == '旋转'):
                    if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler", globals(), locals()):
                        bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler = tuple(mathutils.Vector((bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].location if (self.sna_new_property == '位置') else (bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].rotation_euler if (self.sna_new_property == '旋转') else None))) * mathutils.Vector(((0 if self.sna_x else 1), (0 if self.sna_y else 1), (0 if self.sna_z else 1))))
                else:
                    if (self.sna_new_property == '缩放'):
                        if property_exists("bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale", globals(), locals()):
                            bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale = ((1.0 if self.sna_x else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[0]), (1.0 if self.sna_y else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[1]), (1.0 if self.sna_z else bpy.context.view_layer.objects.selected[bpy.context.selected_objects[i_37CB5].name].scale[2]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_tool_header_3D7F1(self, context):
    if not (False):
        layout = self.layout
        row_9280A = layout.row(heading='', align=False)
        row_9280A.alert = False
        row_9280A.enabled = True
        row_9280A.active = True
        row_9280A.use_property_split = False
        row_9280A.use_property_decorate = False
        row_9280A.scale_x = 1.0
        row_9280A.scale_y = 1.0
        row_9280A.alignment = 'Right'.upper()
        if not True: row_9280A.operator_context = "EXEC_DEFAULT"
        row_9280A.prop(bpy.context.scene, 'sna_new_property_003', text=('中' if bpy.context.scene.sna_new_property_003 else '英'), icon_value=0, emboss=True)
        op = row_9280A.operator('outliner.orphans_purge', text='清理数据', icon_value=0, emboss=True, depress=False)


class SNA_OT_Operator013_2E178(bpy.types.Operator):
    bl_idname = "sna.operator013_2e178"
    bl_label = "Operator.013"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import random

        def set_random_light_colors():
            # 获取当前选择的灯光对象
            selected_lights = [obj for obj in bpy.context.selected_objects if obj.type == 'LIGHT']
            for light in selected_lights:
                # 检查灯光是否有 color 属性
                if hasattr(light.data, 'color'):
                    # 生成随机颜色
                    random_color = [random.uniform(0, 1) for _ in range(3)]
                    # 设置灯光的颜色
                    light.data.color = random_color
        if __name__ == "__main__":
            set_random_light_colors()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_cycles_light_pt_light_8C939(self, context):
    if not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property_001):
        layout = self.layout
        row_9A489 = layout.row(heading='', align=True)
        row_9A489.alert = False
        row_9A489.enabled = True
        row_9A489.active = True
        row_9A489.use_property_split = False
        row_9A489.use_property_decorate = False
        row_9A489.scale_x = 1.0
        row_9A489.scale_y = 1.0
        row_9A489.alignment = 'Expand'.upper()
        if not True: row_9A489.operator_context = "EXEC_DEFAULT"
        op = row_9A489.operator('sna.operator016_2e985', text='亮度*0.5', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator018_bf94b', text='亮度*0.75', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator019_8aa9a', text='亮度*1.5', icon_value=32, emboss=True, depress=False)
        op = row_9A489.operator('sna.operator017_e38ed', text='亮度*2', icon_value=31, emboss=True, depress=False)
        row_81A38 = layout.row(heading='', align=True)
        row_81A38.alert = False
        row_81A38.enabled = True
        row_81A38.active = True
        row_81A38.use_property_split = False
        row_81A38.use_property_decorate = False
        row_81A38.scale_x = 1.0
        row_81A38.scale_y = 1.0
        row_81A38.alignment = 'Expand'.upper()
        if not True: row_81A38.operator_context = "EXEC_DEFAULT"
        op = row_81A38.operator('sna.operator013_2e178', text='随机灯光颜色', icon_value=239, emboss=True, depress=False)


class SNA_OT_Operator019_8Aa9A(bpy.types.Operator):
    bl_idname = "sna.operator019_8aa9a"
    bl_label = "Operator.019"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 1.5)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator017_E38Ed(bpy.types.Operator):
    bl_idname = "sna.operator017_e38ed"
    bl_label = "Operator.017"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 2.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator018_Bf94B(bpy.types.Operator):
    bl_idname = "sna.operator018_bf94b"
    bl_label = "Operator.018"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 0.75)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator016_2E985(bpy.types.Operator):
    bl_idname = "sna.operator016_2e985"
    bl_label = "Operator.016"
    bl_description = "随机选中灯光颜色"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.lights[bpy.context.active_object.name].energy = float(bpy.data.lights[bpy.context.active_object.name].energy * 0.5)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator004_Fa32A(bpy.types.Operator):
    bl_idname = "sna.operator004_fa32a"
    bl_label = "Operator.004"
    bl_description = "合并使用同一基础色贴图的材质"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 存储贴图的字典
        texture_dict = {}
        color_input_name=["Color", "Base Color", "Diffuse Color", "Albedo","Base Tex"]
        # 获取所选物体列表
        selected_objects = bpy.context.selected_objects
        # 循环遍历所选物体
        for obj in selected_objects:
            # 检查物体是否为网格对象
            if isinstance(obj.data, bpy.types.Mesh):
                # 遍历物体的材质列表
                for material in obj.data.materials:
                    # 获取材质的节点树
                    tree = material.node_tree
                    # 遍历节点树中的所有节点
                    for node in tree.nodes:
                        # 检查节点类型是否为ShaderNodeTexImage（贴图节点）
                        if node.type == 'TEX_IMAGE':
                            # 检查节点的输出连接是否存在
                            if node.outputs['Color'].is_linked:
                                # 遍历节点的输出连接
                                for link in node.outputs['Color'].links:
                                    # 检查连接的输入端口名称是否为"基础颜色"
                                    for input_name in color_input_name:
                                        if link.to_socket.name == input_name:
                                            # 检查贴图是否已经在字典中
                                            if node.image.name not in texture_dict:
                                                # 将贴图节点添加到字典
                                                texture_dict[node.image.name] = material
                                                print('贴图已经在字典中', node.image.name)
                                            else:
                                                # 替换材质为字典中的材质
                                                new_material = texture_dict[node.image.name]
                                                # 将物体的材质更改为新的材质
                                                obj.data.materials[0] = new_material
                                                print('贴图不在字典中', node.image.name, '替换材质:', new_material.name)
                                    else:
                                        print('连接端口的贴图没找到')
                        else:
                            print("没有找到贴图")
            else:
                print('没有找到网格对象')
        #清理未使用数据块
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        # 设置材质的名称为贴图名称
        for tex_name, material in texture_dict.items():
            material.name = tex_name
        # 打印贴图字典
        print(texture_dict)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator005_9368B(bpy.types.Operator):
    bl_idname = "sna.operator005_9368b"
    bl_label = "Operator.005"
    bl_description = "将替换mmd自带节点组为原理化节点组"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前选中的物体
        selected_objects = bpy.context.selected_objects
        # 遍历选中的物体
        for obj in selected_objects:
            # 遍历物体的所有材质槽
            for material_slot in obj.material_slots:
                material = material_slot.material
                # 遍历材质的所有节点
                for node in material.node_tree.nodes:
                    # 检查节点的类型和名称
                    if node.type == 'GROUP' and node.node_tree.name == 'MMDShaderDev':  # 替换为你的节点组名称
                        # 获取节点组的输入
                        base_tex_input = node.inputs.get('Base Tex')
                        base_alpha_input = node.inputs.get('Base Alpha')
                        # 如果找到对应的输入，继续处理
                        if base_tex_input and base_alpha_input:
                            # 获取连接到 Base Tex 和 Base Alpha 的连接
                            base_tex_link = base_tex_input.links[0] if base_tex_input.links else None
                            base_alpha_link = base_alpha_input.links[0] if base_alpha_input.links else None
                            # 创建新的原理化节点
                            principled_node = material.node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
                            principled_node.location = node.location
                            # 连接 Base Tex
                            if base_tex_link:
                                material.node_tree.links.new(principled_node.inputs['Base Color'], base_tex_link.from_socket)
                            # 连接 Base Alpha
                            if base_alpha_link:
                                material.node_tree.links.new(principled_node.inputs['Alpha'], base_alpha_link.from_socket)
                            # 连接新原理化节点到材质输出
                            material_output_node = material.node_tree.nodes.get("Material Output")
                            if material_output_node:
                                material.node_tree.links.new(material_output_node.inputs['Surface'], principled_node.outputs['BSDF'])
                            # 删除旧的节点
                            material.node_tree.nodes.remove(node)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator006_42368(bpy.types.Operator):
    bl_idname = "sna.operator006_42368"
    bl_label = "Operator.006"
    bl_description = "选中mmd相机和mmd相机的父级空物体"
    bl_options = {"REGISTER", "UNDO"}
    sna_camera_name: bpy.props.StringProperty(name='camera_name', description='', default='Camera', subtype='NONE', maxlen=0)
    sna_mmd_camera: bpy.props.StringProperty(name='MMD_Camera', description='', default='MMD_Camera', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not  not ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA')))

    def execute(self, context):
        if ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA'))):
            if bpy.context.view_layer.objects.selected[0].type == 'EMPTY':
                self.sna_mmd_camera = bpy.context.view_layer.objects.selected[0].name
                self.sna_camera_name = bpy.context.view_layer.objects.selected[1].name
                print(self.sna_mmd_camera + self.sna_camera_name)
                camera_name = self.sna_camera_name
                Advance_frame = bpy.context.scene.sna_new_property_002
                MMD_Camera = self.sna_mmd_camera
                '''
                camera_name="Camera"
                Advance_frame=30
                MMD_Camera='MMD_Camera'
                '''
                #选中物体

                def selected_object(Selected_object_name):
                # 检查物体是否存在
                    if Selected_object_name in bpy.data.objects:
                        obj = bpy.data.objects[Selected_object_name]
                        # 将指定物体设置为活动物体
                        bpy.context.view_layer.objects.active = obj
                        # 清除选择
                        bpy.ops.object.select_all(action='DESELECT')
                        # 选择指定物体
                        obj.select_set(True)
                    else:
                        print(f"找不到名为 '{Selected_object_name}' 的物体。")
                #选中通道

                def select_channel(channel_name):
                    # 获取当前激活的动作
                    current_action = bpy.context.object.animation_data.action
                    if current_action:
                        # 遍历当前动作的 F-Curves（通道）
                        for fcurve in current_action.fcurves:
                            if fcurve.data_path.endswith(channel_name):
                                fcurve.select = True
                            else:
                                fcurve.select = False

                def set_workspace_to_3d_view():
                    # 获取当前激活的工作区域
                    current_area = bpy.context.area
                    if current_area:
                        # 设置当前工作区域为3D视图
                        current_area.type = 'VIEW_3D'
                        print("Switched to 3D View.")
                    else:
                        print("No active workspace.")
                bpy.context.preferences.view.language = 'en_US'#设置语言为英文
                bpy.ops.object.select_all(action='DESELECT')#取消所有选择
                selected_object(MMD_Camera)
                bpy.context.area.type = 'DOPESHEET_EDITOR'#切换工作区域为动画摄影表
                bpy.context.area.spaces.active.dopesheet.show_only_selected = False#取消显示所有关键帧
                #选择名为angle的关键帧
                bpy.context.area.spaces.active.dopesheet.filter_text = "angle"#搜索通道名
                bpy.ops.action.select_all(action='SELECT')#全选关键帧
                bpy.ops.action.copy()
                select_channel("angle")#选中通道
                bpy.context.scene.frame_set(Advance_frame)#回到第0帧
                bpy.ops.anim.channels_setting_toggle(type='MUTE')#禁用通道
                bpy.context.area.spaces.active.dopesheet.filter_text = "perspective"
                select_channel("perspective")
                bpy.ops.anim.channels_setting_toggle(type='MUTE')
                #新建空物体
                empty = bpy.data.objects.new("焦距", None)
                bpy.context.scene.collection.objects.link(empty)
                selected_object("焦距")
                # 设置要操作的物体名称
                object_name = empty.name
                # 检查物体是否存在
                if object_name in bpy.data.objects:
                    obj = bpy.data.objects[object_name]
                    # 在时间轴中的特定帧设置物体的位置
                    frame = 0  # 替换为您要创建关键帧的帧数
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    # 在时间轴中的特定帧设置物体的位置
                    # 替换为您要创建关键帧的帧数
                    obj.location.x = 0.2  # 替换为您要设置的位置值
                    #obj.location.y = 0.0
                    #obj.location.z = 0.0
                    # 在指定帧上为位置属性创建关键帧
                    obj.keyframe_insert(data_path="location", frame=frame,index=0)
                    bpy.context.area.spaces.active.dopesheet.filter_text = "X Location"
                    bpy.ops.action.select_all(action='SELECT')
                    #粘贴关键帧
                    bpy.ops.action.paste(flipped=True)
                    bpy.context.area.spaces.active.dopesheet.filter_text = ""
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    bpy.context.preferences.view.language = 'zh_CN'#回到中文
                    bpy.context.area.type = 'TEXT_EDITOR'
                    #bpy.context.area.type = 'TEXT_EDITOR'
                    set_workspace_to_3d_view()
                    empty_obj = bpy.data.objects[object_name]
                    # 创建一个新的驱动器
                    driver = empty_obj.driver_add('location', 2)  # 在这里，将驱动器添加到目标物体的 Y 缩放属性（索引为 1）
                    # 设置驱动器的类型为 "Scripted Expression"，以自定义表达式
                    driver.driver.type = 'SCRIPTED'
                    # 创建一个自定义变量，用于控制驱动器
                    var = driver.driver.variables.new()
                    var.name = "var"  # 变量名称
                    var.type = 'SINGLE_PROP'
                    var.targets[0].id = empty_obj
                    var.targets[0].data_path = "location.x"  # 引用源物体的 X 位置属性
                    # 设置驱动器的表达式，以引用自定义变量 var
                    driver.driver.expression = "12/tan(var/2)"  # 使目标物体的 Y 缩放属性等于源物体的 X 位置属性的两倍
                    target_object = empty_obj
                    selected_object(camera_name)
                    # 通过名称获取相机对象
                    camera = bpy.data.objects.get(camera_name) 
                    if camera and target_object:
                        # 创建一个新的驱动器对象
                        driver = camera.data.driver_add("lens")  # "lens" 是焦距属性的名称
                        # 设置驱动器的类型为 "Scripted Expression"
                        driver.driver.type = "SCRIPTED"
                        # 创建一个自定义变量，并将其设置为控制驱动器的输入
                        var = driver.driver.variables.new()
                        var.name = "var"  # 自定义变量的名称
                        var.type = "SINGLE_PROP"
                        var.targets[0].id = target_object
                        var.targets[0].data_path = "location.z"  # 引用目标物体的 X 位置属性作为输入
                        # 设置驱动器的表达式，以引用自定义变量并计算焦距
                        driver.driver.expression = "var"  # 例如，这里是一个示例表达式
                    else:
                        print("找不到相机或目标物体。")
                else:
                    print(f"找不到名为 '{object_name}' 的物体。")
            else:
                self.sna_mmd_camera = bpy.context.view_layer.objects.selected[1].name
                self.sna_camera_name = bpy.context.view_layer.objects.selected[0].name
                print(self.sna_mmd_camera + self.sna_camera_name)
                camera_name = self.sna_camera_name
                Advance_frame = bpy.context.scene.sna_new_property_002
                MMD_Camera = self.sna_mmd_camera
                '''
                camera_name="Camera"
                Advance_frame=30
                MMD_Camera='MMD_Camera'
                '''
                #选中物体

                def selected_object(Selected_object_name):
                # 检查物体是否存在
                    if Selected_object_name in bpy.data.objects:
                        obj = bpy.data.objects[Selected_object_name]
                        # 将指定物体设置为活动物体
                        bpy.context.view_layer.objects.active = obj
                        # 清除选择
                        bpy.ops.object.select_all(action='DESELECT')
                        # 选择指定物体
                        obj.select_set(True)
                    else:
                        print(f"找不到名为 '{Selected_object_name}' 的物体。")
                #选中通道

                def select_channel(channel_name):
                    # 获取当前激活的动作
                    current_action = bpy.context.object.animation_data.action
                    if current_action:
                        # 遍历当前动作的 F-Curves（通道）
                        for fcurve in current_action.fcurves:
                            if fcurve.data_path.endswith(channel_name):
                                fcurve.select = True
                            else:
                                fcurve.select = False

                def set_workspace_to_3d_view():
                    # 获取当前激活的工作区域
                    current_area = bpy.context.area
                    if current_area:
                        # 设置当前工作区域为3D视图
                        current_area.type = 'VIEW_3D'
                        print("Switched to 3D View.")
                    else:
                        print("No active workspace.")
                bpy.context.preferences.view.language = 'en_US'#设置语言为英文
                bpy.ops.object.select_all(action='DESELECT')#取消所有选择
                selected_object(MMD_Camera)
                bpy.context.area.type = 'DOPESHEET_EDITOR'#切换工作区域为动画摄影表
                bpy.context.area.spaces.active.dopesheet.show_only_selected = False#取消显示所有关键帧
                #选择名为angle的关键帧
                bpy.context.area.spaces.active.dopesheet.filter_text = "angle"#搜索通道名
                bpy.ops.action.select_all(action='SELECT')#全选关键帧
                bpy.ops.action.copy()
                select_channel("angle")#选中通道
                bpy.context.scene.frame_set(Advance_frame)#回到第0帧
                bpy.ops.anim.channels_setting_toggle(type='MUTE')#禁用通道
                bpy.context.area.spaces.active.dopesheet.filter_text = "perspective"
                select_channel("perspective")
                bpy.ops.anim.channels_setting_toggle(type='MUTE')
                #新建空物体
                empty = bpy.data.objects.new("焦距", None)
                bpy.context.scene.collection.objects.link(empty)
                selected_object("焦距")
                # 设置要操作的物体名称
                object_name = empty.name
                # 检查物体是否存在
                if object_name in bpy.data.objects:
                    obj = bpy.data.objects[object_name]
                    # 在时间轴中的特定帧设置物体的位置
                    frame = 0  # 替换为您要创建关键帧的帧数
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    # 在时间轴中的特定帧设置物体的位置
                    # 替换为您要创建关键帧的帧数
                    obj.location.x = 0.2  # 替换为您要设置的位置值
                    #obj.location.y = 0.0
                    #obj.location.z = 0.0
                    # 在指定帧上为位置属性创建关键帧
                    obj.keyframe_insert(data_path="location", frame=frame,index=0)
                    bpy.context.area.spaces.active.dopesheet.filter_text = "X Location"
                    bpy.ops.action.select_all(action='SELECT')
                    #粘贴关键帧
                    bpy.ops.action.paste(flipped=True)
                    bpy.context.area.spaces.active.dopesheet.filter_text = ""
                    print(f"在帧 {frame} 上为物体 '{object_name}' 创建了关键帧。")
                    bpy.context.preferences.view.language = 'zh_CN'#回到中文
                    bpy.context.area.type = 'TEXT_EDITOR'
                    #bpy.context.area.type = 'TEXT_EDITOR'
                    set_workspace_to_3d_view()
                    empty_obj = bpy.data.objects[object_name]
                    # 创建一个新的驱动器
                    driver = empty_obj.driver_add('location', 2)  # 在这里，将驱动器添加到目标物体的 Y 缩放属性（索引为 1）
                    # 设置驱动器的类型为 "Scripted Expression"，以自定义表达式
                    driver.driver.type = 'SCRIPTED'
                    # 创建一个自定义变量，用于控制驱动器
                    var = driver.driver.variables.new()
                    var.name = "var"  # 变量名称
                    var.type = 'SINGLE_PROP'
                    var.targets[0].id = empty_obj
                    var.targets[0].data_path = "location.x"  # 引用源物体的 X 位置属性
                    # 设置驱动器的表达式，以引用自定义变量 var
                    driver.driver.expression = "12/tan(var/2)"  # 使目标物体的 Y 缩放属性等于源物体的 X 位置属性的两倍
                    target_object = empty_obj
                    selected_object(camera_name)
                    # 通过名称获取相机对象
                    camera = bpy.data.objects.get(camera_name) 
                    if camera and target_object:
                        # 创建一个新的驱动器对象
                        driver = camera.data.driver_add("lens")  # "lens" 是焦距属性的名称
                        # 设置驱动器的类型为 "Scripted Expression"
                        driver.driver.type = "SCRIPTED"
                        # 创建一个自定义变量，并将其设置为控制驱动器的输入
                        var = driver.driver.variables.new()
                        var.name = "var"  # 自定义变量的名称
                        var.type = "SINGLE_PROP"
                        var.targets[0].id = target_object
                        var.targets[0].data_path = "location.z"  # 引用目标物体的 X 位置属性作为输入
                        # 设置驱动器的表达式，以引用自定义变量并计算焦距
                        driver.driver.expression = "var"  # 例如，这里是一个示例表达式
                    else:
                        print("找不到相机或目标物体。")
                else:
                    print(f"找不到名为 '{object_name}' 的物体。")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator010_78668(bpy.types.Operator, ImportHelper):
    bl_idname = "sna.operator010_78668"
    bl_label = "Operator.010"
    bl_description = "选择mtl文件，贴图需要和mtl文件在同一个文件夹内"
    bl_options = {"REGISTER", "UNDO"}
    filter_glob: bpy.props.StringProperty( default='*.mtl', options={'HIDDEN'} )

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        file_path = self.filepath
        import re
        # 脚本 by 三分仪
        # 将alembic_file.mtl所在路径复制进去，贴图和alembic_file.mtl在同一文件夹下
        #file_path = r'E:\mmd_project\绯色回响mmd\wj\alembic_file.mtl'
        materials = {}
        with open(file_path, 'r', encoding='gbk') as f:
            current_material = None
            for line in f:
                if line.startswith("newmtl"):
                    current_material = line.split()[1]
                    materials[current_material] = {}
                elif line.startswith("map_Kd"):
                    texture = line.split()[1:]
                    texture_name = " ".join(texture)
                    if current_material is not None:
                        materials[current_material]["map_Kd"] = texture_name
        new_materials_dict = {}
        for i, (key, value) in enumerate(materials.items()):
            new_key = f'xform_0_material_{i}'
            new_materials_dict[new_key] = value
        # Check if 'map_Kd' exists before trying to access it
        materials = {k: v.get('map_Kd', '') for k, v in new_materials_dict.items()}
        # Output the new dictionary
        print(materials)
        for key, value in materials.items():
            obj = bpy.data.objects[key]
            mat = bpy.data.materials.new(name=value)
            # 设置该材质使用节点
            mat.use_nodes = True
            # 创建一个新的Image纹理节点
            tex = mat.node_tree.nodes.new('ShaderNodeTexImage')
            tex.location = (-300, 300)
            new_name = value
            new_path = file_path.replace(file_path.split('\\')[-1], new_name)
            print(new_path)
            # 设置纹理图片路径
            tex.image = bpy.data.images.load(new_path)
            # 获取Diffuse BSDF节点
            bsdf = mat.node_tree.nodes.get('Principled BSDF')
            # 将Image纹理节点连接到Diffuse BSDF节点的Base Color输入
            mat.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            mat.node_tree.links.new(tex.outputs['Alpha'], bsdf.inputs['Alpha'])
            # 赋予材质
            obj.data.materials.append(mat)
            # 遍历所有物体
            for obj in bpy.data.objects:
                # 判断物体名称中是否含有 xform_0_material
                if "xform_0_material" in obj.name:
                    # 遍历该物体的材质
                    for mat_slot in obj.material_slots:
                        # 获取材质
                        mat = mat_slot.material
                        # 判断材质名称中是否含有序号
                        if re.search(r"\.\d+", mat.name):
                            # 替换材质名称为没有序号的名称
                            new_name = re.sub(r"\.\d+", "", mat.name)
                            mat_slot.material = bpy.data.materials[new_name]
            # 清理未使用的数据块
            bpy.ops.outliner.orphans_purge()
        return {"FINISHED"}


def sna_add_to_time_mt_editor_menus_3F6F3(self, context):
    if not (False):
        layout = self.layout
        row_58E00 = layout.row(heading='', align=False)
        row_58E00.alert = False
        row_58E00.enabled = True
        row_58E00.active = True
        row_58E00.use_property_split = False
        row_58E00.use_property_decorate = False
        row_58E00.scale_x = 0.8320000171661377
        row_58E00.scale_y = 1.0
        row_58E00.alignment = 'Expand'.upper()
        if not True: row_58E00.operator_context = "EXEC_DEFAULT"
        row_58E00.prop(bpy.context.scene, 'sna_new_property_004', text='时间(分.秒)', icon_value=0, emboss=True)


class SNA_OT_Operator003_F8Ede(bpy.types.Operator):
    bl_idname = "sna.operator003_f8ede"
    bl_label = "Operator.003"
    bl_description = "更改材质名称为网格名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        # 获取当前场景
        scene = bpy.context.scene
        # 获取所选物体列表
        selected_objects = bpy.context.selected_objects
        # 循环遍历所选物体
        for obj in selected_objects:
            # 获取物体的第一个材质
            material = obj.data.materials[0] if obj.data.materials else None
            # 如果物体有材质，则将物体名称更改为材质名称
            if material:
                obj.name = material.name
                print(f"Object {obj.name} renamed to {material.name}")
            else:
                print(f"Object {obj.name} has no materials")
        # 更新场景
        bpy.context.view_layer.update()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator011_9D3Ab(bpy.types.Operator):
    bl_idname = "sna.operator011_9d3ab"
    bl_label = "Operator.011"
    bl_description = "更改网格名称为材质名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def rename_materials_to_objects():
            # 获取当前选择的物体
            selected_objects = bpy.context.selected_objects
            for obj in selected_objects:
                # 获取物体的第一个材质
                material = obj.active_material
                if material:
                    # 将材质的名称设置为物体的名称
                    material.name = obj.name
                else:
                    print(f"Object {obj.name} has no material.")
        if __name__ == "__main__":
            rename_materials_to_objects()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator012_Bbb3C(bpy.types.Operator):
    bl_idname = "sna.operator012_bbb3c"
    bl_label = "Operator.012"
    bl_description = "更改贴图名称为基础色贴图名称"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def rename_materials_to_base_color_texture():
            # 获取当前选择的物体
            selected_objects = bpy.context.selected_objects
            for obj in selected_objects:
                # 获取物体的第一个材质
                material = obj.active_material
                base_color_texture_node = None
                # 定义可能的基础色输入端口名称列表
                possible_base_color_input_names = ["Color", "Base Color", "Diffuse Color", "Albedo","Base Tex"]
                if material:
                    # 遍历节点图中的所有节点
                    for node in material.node_tree.nodes:
                        # 检查节点是否是 'TEX_IMAGE' 类型
                        if node.type == 'TEX_IMAGE':
                            # 遍历可能的基础色输入端口名称
                            for base_color_input_name in possible_base_color_input_names:
                                # 检查节点的 "Color" 输出端口是否连接到其他节点的基础色输入端口
                                if any(link.to_socket.name == base_color_input_name for link in node.outputs['Color'].links):
                                    base_color_texture_node = node
                                    break
                            if base_color_texture_node:
                                break  # 如果找到匹配的节点，退出外层循环
                    if base_color_texture_node:
                        # 获取贴图的名称并设置为材质的名称
                        texture_name = base_color_texture_node.image.name
                        material.name = texture_name
                else:
                    print(f"Object {obj.name} has no material.")
        if __name__ == "__main__":
            rename_materials_to_base_color_texture()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_MMD_06384(bpy.types.Panel):
    bl_label = 'mmd快速工具'
    bl_idname = 'SNA_PT_MMD_06384'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'MMD'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


def sna_setmaxi_454ED(time):
    return round((float(time + 0.0) if (float(float(time + 0.0) - int(time + 0.0)) < 0.6000000238418579) else float(0.6000000238418579 + int(time + 0.0))), abs(3))


def sna_time2frameinput_2F52D(time):
    return [int(round(float(float(float(float(time + 0.0) - int(time + 0.0)) * 100.0) + float(int(time + 0.0) * 60.0)), abs(1)) * bpy.context.scene.render.fps), round(float(float(float(float(time + 0.0) - int(time + 0.0)) * 100.0) + float(int(time + 0.0) * 60.0)), abs(1))]


def sna_frame2timei_02BDE(frame):
    return float(int(int(frame / bpy.context.scene.render.fps) / 60.0) + float(eval("int(frame / bpy.context.scene.render.fps) % 60.0") / 100.0))


@persistent
def frame_change_post_handler_1BDE6(dummy):
    time_0_5ddbc = sna_frame2timei_02BDE(bpy.context.scene.frame_current)
    bpy.context.scene.sna_open = False
    bpy.context.scene.sna_new_property_004 = time_0_5ddbc
    bpy.context.scene.sna_open = True


class SNA_OT_Down_25Ee0(bpy.types.Operator):
    bl_idname = "sna.down_25ee0"
    bl_label = "down"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (float(len(bpy.context.scene.sna_render_list) - 1.0) == bpy.context.scene.sna_id):
            pass
        else:
            bpy.context.scene.sna_render_list.move(bpy.context.scene.sna_id, int(bpy.context.scene.sna_id + 1.0))
            item_CA05D = bpy.context.scene.sna_render_list[int(bpy.context.scene.sna_id + 1.0)]
            bpy.context.scene.sna_id = int(bpy.context.scene.sna_id + 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Up_B66Ca(bpy.types.Operator):
    bl_idname = "sna.up_b66ca"
    bl_label = "up"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.scene.sna_id == 0):
            pass
        else:
            bpy.context.scene.sna_render_list.move(bpy.context.scene.sna_id, int(bpy.context.scene.sna_id - 1.0))
            item_BA94F = bpy.context.scene.sna_render_list[int(bpy.context.scene.sna_id - 1.0)]
            bpy.context.scene.sna_id = int(bpy.context.scene.sna_id - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Render_List_84292(bpy.types.Operator):
    bl_idname = "sna.add_render_list_84292"
    bl_label = "add_render_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        item_D5070 = bpy.context.scene.sna_render_list.add()
        item_D5070.name = '渲染任务' + str(len(bpy.context.scene.sna_render_list))
        item_D5070.start_frame = bpy.context.scene.frame_start
        item_D5070.end_frame = bpy.context.scene.frame_end
        bpy.context.scene.sna_id = int(len(bpy.context.scene.sna_render_list) - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Render_List_E8059(bpy.types.Operator):
    bl_idname = "sna.remove_render_list_e8059"
    bl_label = "remove_render_list"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (int(len(bpy.context.scene.sna_render_list) - 1.0) == bpy.context.scene.sna_id):
            if len(bpy.context.scene.sna_render_list) > bpy.context.scene.sna_id:
                bpy.context.scene.sna_render_list.remove(bpy.context.scene.sna_id)
            bpy.context.scene.sna_id = int(len(bpy.context.scene.sna_render_list) - 1.0)
        else:
            if len(bpy.context.scene.sna_render_list) > bpy.context.scene.sna_id:
                bpy.context.scene.sna_render_list.remove(bpy.context.scene.sna_id)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_My_Generic_Operator_5874F(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_5874f"
    bl_label = "渲染"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.sna.operator_cc77e('INVOKE_DEFAULT', )
        bpy.ops.sna.my_generic_operator_33f13('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_complete_handler_825EB(dummy):
    bpy.context.scene.sna_id = int(bpy.context.scene.sna_id + 1.0)
    for i_D5DFF in range(len(bpy.context.scene.sna_render_list)):
        if (bpy.context.scene.sna_render_list[i_D5DFF].on and (i_D5DFF >= bpy.context.scene.sna_id)):
            bpy.context.scene.sna_id = i_D5DFF
            break

    def delayed_3D3B7():
        bpy.context.scene.sna_is_render = False
        if bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].on:
            bpy.context.scene.frame_start = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].start_frame
            bpy.context.scene.frame_end = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].end_frame
            bpy.context.scene.camera = (bpy.data.objects[node_tree_001['sna_default_camera']] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera == None) else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera)
            bpy.context.scene.render.filepath = (node_tree_001['sna_default_output_directory'] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory == '') else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory)
            bpy.context.scene.sna_is_render = True
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True, use_viewport=True)
        else:

            def delayed_C1A0C():
                bpy.context.scene.frame_start = node_tree_001['sna_default_frame_start']
                bpy.context.scene.frame_end = node_tree_001['sna_default_frame_end']
                bpy.context.scene.camera = bpy.context.view_layer.objects[node_tree_001['sna_default_camera']]

                def delayed_F65CF():
                    bpy.context.scene.render.filepath = node_tree_001['sna_default_output_directory']
                    bpy.context.scene.sna_time.clear()
                    bpy.context.scene.sna_is_render = False
                bpy.app.timers.register(delayed_F65CF, first_interval=0.5)
            bpy.app.timers.register(delayed_C1A0C, first_interval=1.0)
    bpy.app.timers.register(delayed_3D3B7, first_interval=0.30000001192092896)


@persistent
def render_complete_handler_C420C(dummy):
    pass


class SNA_OT_My_Generic_Operator_33F13(bpy.types.Operator):
    bl_idname = "sna.my_generic_operator_33f13"
    bl_label = "开始渲染"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        node_tree_001['sna_default_frame_start'] = bpy.context.scene.frame_start
        node_tree_001['sna_default_frame_end'] = bpy.context.scene.frame_end
        node_tree_001['sna_default_camera'] = bpy.context.scene.camera.name
        node_tree_001['sna_default_output_directory'] = bpy.context.scene.render.filepath
        for i_ACDF3 in range(len(bpy.context.scene.sna_render_list)):
            if bpy.context.scene.sna_render_list[i_ACDF3].on:
                print(str(i_ACDF3))
                bpy.context.scene.sna_id = i_ACDF3
                break
        bpy.context.scene.frame_start = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].start_frame
        bpy.context.scene.frame_end = bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].end_frame
        bpy.context.scene.camera = (bpy.context.scene.camera if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera == None) else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].render_camera)
        bpy.context.scene.render.filepath = (node_tree_001['sna_default_output_directory'] if (bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory == '') else bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].output_directory)
        bpy.context.scene.sna_is_render = True
        bpy.ops.render.render('INVOKE_DEFAULT', animation=True, use_viewport=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_cancel_handler_58683(dummy):
    bpy.context.scene.sna_is_render = False


@persistent
def render_post_handler_4E079(dummy):
    if (bpy.context.scene.sna_render_list[len(bpy.context.scene.sna_render_list)].end_frame == bpy.context.scene.frame_current):
        bpy.context.scene.sna_is_render = False


@persistent
def render_pre_handler_1092E(dummy):
    if (len(bpy.context.scene.sna_time) >= 6):
        if len(bpy.context.scene.sna_time) > 0:
            bpy.context.scene.sna_time.remove(0)
        item_D9314 = bpy.context.scene.sna_time.add()
        item_D9314.frame_start_time = round(float(int(datetime.now().time().hour * 3600.0) + float(int(datetime.now().time().minute * 60.0) + float(datetime.now().time().second + float(datetime.now().time().microsecond//1000 / 1000.0)))), abs(2))
        item_D9314.frame_time = (0 if (len(bpy.context.scene.sna_time) <= 1) else round(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_start_time - (0 if (len(bpy.context.scene.sna_time) <= 1) else bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 2.0)].frame_start_time)), abs(2)))
    else:
        item_F5BA6 = bpy.context.scene.sna_time.add()
        item_F5BA6.frame_start_time = round(float(int(datetime.now().time().hour * 3600.0) + float(int(datetime.now().time().minute * 60.0) + float(datetime.now().time().second + float(datetime.now().time().microsecond//1000 / 1000.0)))), abs(2))
        item_F5BA6.frame_time = (0 if (len(bpy.context.scene.sna_time) <= 1) else round(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_start_time - (0 if (len(bpy.context.scene.sna_time) <= 1) else bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 2.0)].frame_start_time)), abs(2)))


@persistent
def render_post_handler_15713(dummy):
    node_tree_001['sna_sub_render_time'] = round((float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_time + node_tree_001['sna_sub_render_time']) if (len(bpy.context.scene.sna_time) == 1) else float(float(bpy.context.scene.sna_time[int(len(bpy.context.scene.sna_time) - 1.0)].frame_time + node_tree_001['sna_sub_render_time']) - bpy.context.scene.sna_time[0].frame_time)), abs(2))
    node_tree_001['sna_avg_render_time'] = round(float(node_tree_001['sna_sub_render_time'] / (int(len(bpy.context.scene.sna_time) - 1.0) if (len(bpy.context.scene.sna_time) <= 5) else int(len(bpy.context.scene.sna_time) - 1.0))), abs(2))


class SNA_OT_Operator_Cc77E(bpy.types.Operator):
    bl_idname = "sna.operator_cc77e"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_E2ECF in range(len(bpy.context.scene.sna_render_list)):
            node_tree_001['sna_sub_frame'] = (int(int(int(bpy.context.scene.sna_render_list[i_E2ECF].end_frame - bpy.context.scene.sna_render_list[i_E2ECF].start_frame) + 1.0) + node_tree_001['sna_sub_frame']) if bpy.context.scene.sna_render_list[i_E2ECF].on else node_tree_001['sna_sub_frame'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_post_handler_B2801(dummy):
    node_tree_001['sna_current_frame'] = int(node_tree_001['sna_current_frame'] + 1.0)


class SNA_AddonPreferences_C113E(bpy.types.AddonPreferences):
    bl_idname = 'mmd_quick_tool'
    sna_mmd: bpy.props.BoolProperty(name='MMD工具', description='', default=True)
    sna_new_property: bpy.props.BoolProperty(name='快速设置分辨率界面', description='', default=True)
    sna_new_property_001: bpy.props.BoolProperty(name='快速灯光设置界面', description='', default=True)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            row_1F4FE = layout.row(heading='', align=False)
            row_1F4FE.alert = False
            row_1F4FE.enabled = True
            row_1F4FE.active = True
            row_1F4FE.use_property_split = False
            row_1F4FE.use_property_decorate = False
            row_1F4FE.scale_x = 1.0
            row_1F4FE.scale_y = 1.0
            row_1F4FE.alignment = 'Expand'.upper()
            if not True: row_1F4FE.operator_context = "EXEC_DEFAULT"
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_mmd', text='MMD工具', icon_value=0, emboss=True)
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_new_property', text='快速设置分辨率界面', icon_value=0, emboss=True)
            row_1F4FE.prop(bpy.context.preferences.addons['mmd_quick_tool'].preferences, 'sna_new_property_001', text='快速设置灯光界面', icon_value=0, emboss=True)
            row_472B7 = layout.row(heading='', align=False)
            row_472B7.alert = False
            row_472B7.enabled = True
            row_472B7.active = True
            row_472B7.use_property_split = False
            row_472B7.use_property_decorate = False
            row_472B7.scale_x = 1.0
            row_472B7.scale_y = 1.0
            row_472B7.alignment = 'Expand'.upper()
            if not True: row_472B7.operator_context = "EXEC_DEFAULT"
            op = row_472B7.operator('wm.url_open', text='打开github首页获取帮助', icon_value=625, emboss=True, depress=False)
            op.url = 'https://github.com/bb-yi/mmd-Quick-tool'
            row_99DC0 = layout.row(heading='', align=False)
            row_99DC0.alert = False
            row_99DC0.enabled = True
            row_99DC0.active = True
            row_99DC0.use_property_split = False
            row_99DC0.use_property_decorate = False
            row_99DC0.scale_x = 1.0
            row_99DC0.scale_y = 1.0
            row_99DC0.alignment = 'Center'.upper()
            if not True: row_99DC0.operator_context = "EXEC_DEFAULT"
            row_99DC0.label(text='mmd Quick tool', icon_value=0)
            row_99DC0.label(text='插件版本' + str(tuple((1, 0, 5))), icon_value=0)
            row_99DC0.label(text='by  ' + 'SFY', icon_value=227)
            row_99DC0.label(text='感谢使用', icon_value=0)


class SNA_PT__C52FF(bpy.types.Panel):
    bl_label = '分辨率调整'
    bl_idname = 'SNA_PT__C52FF'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_format'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_9A4A1 = layout.row(heading='', align=False)
        row_9A4A1.alert = False
        row_9A4A1.enabled = True
        row_9A4A1.active = True
        row_9A4A1.use_property_split = False
        row_9A4A1.use_property_decorate = False
        row_9A4A1.scale_x = 1.0
        row_9A4A1.scale_y = 1.0
        row_9A4A1.alignment = 'Left'.upper()
        if not True: row_9A4A1.operator_context = "EXEC_DEFAULT"
        op = row_9A4A1.operator('sna.operator_b46a6', text='1080p', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator001_64c4a', text='2k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator002_7dbd9', text='4k', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator007_85779', text='交换', icon_value=692, emboss=True, depress=False)
        op.sna_ax = 7
        op = row_9A4A1.operator('sna.operator008_f7b4c', text='*0.5', icon_value=0, emboss=True, depress=False)
        op = row_9A4A1.operator('sna.operator009_f9bf5', text='*2', icon_value=0, emboss=True, depress=False)
        row_3E7EE = layout.row(heading='', align=False)
        row_3E7EE.alert = False
        row_3E7EE.enabled = True
        row_3E7EE.active = True
        row_3E7EE.use_property_split = False
        row_3E7EE.use_property_decorate = False
        row_3E7EE.scale_x = 1.0
        row_3E7EE.scale_y = 1.0
        row_3E7EE.alignment = 'Left'.upper()
        if not True: row_3E7EE.operator_context = "EXEC_DEFAULT"
        row_3E7EE.prop(bpy.context.scene, 'sna_bili', text='比例', icon_value=0, emboss=True, expand=True)


class SNA_PT_panel_42AE7(bpy.types.Panel):
    bl_label = '物体操作'
    bl_idname = 'SNA_PT_panel_42AE7'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 1
    bl_parent_id = 'SNA_PT_MMD_06384'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.operator015_0ebb1', text='位姿归零', icon_value=0, emboss=True, depress=False)
        op.sna_x = True
        op.sna_y = True
        op.sna_z = True


class SNA_PT__5C6B9(bpy.types.Panel):
    bl_label = '相机设置'
    bl_idname = 'SNA_PT__5C6B9'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_format'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_new_property)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_854C3 = layout.row(heading='', align=False)
        row_854C3.alert = False
        row_854C3.enabled = True
        row_854C3.active = True
        row_854C3.use_property_split = False
        row_854C3.use_property_decorate = False
        row_854C3.scale_x = 1.0
        row_854C3.scale_y = 1.0
        row_854C3.alignment = 'Left'.upper()
        if not True: row_854C3.operator_context = "EXEC_DEFAULT"
        row_854C3.prop(bpy.data.cameras[bpy.context.scene.camera.data.name], 'lens', text='焦距', icon_value=0, emboss=True)
        row_854C3.prop(bpy.data.cameras[bpy.context.scene.camera.data.name].dof, 'aperture_fstop', text='光圈', icon_value=0, emboss=True)


class SNA_PT__4C59C(bpy.types.Panel):
    bl_label = '名称编辑'
    bl_idname = 'SNA_PT__4C59C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_MMD_06384'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_38F6B = layout.row(heading='', align=False)
        row_38F6B.alert = False
        row_38F6B.enabled = True
        row_38F6B.active = True
        row_38F6B.use_property_split = False
        row_38F6B.use_property_decorate = False
        row_38F6B.scale_x = 1.0
        row_38F6B.scale_y = 1.0
        row_38F6B.alignment = 'Expand'.upper()
        if not True: row_38F6B.operator_context = "EXEC_DEFAULT"
        op = row_38F6B.operator('sna.operator003_f8ede', text='材质到网格', icon_value=0, emboss=True, depress=False)
        op = row_38F6B.operator('sna.operator011_9d3ab', text='网格到材质', icon_value=0, emboss=True, depress=False)
        op = row_38F6B.operator('sna.operator012_bbb3c', text='贴图到材质', icon_value=0, emboss=True, depress=False)


class SNA_PT_MMD_720C4(bpy.types.Panel):
    bl_label = 'MMD工具'
    bl_idname = 'SNA_PT_MMD_720C4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_06384'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['mmd_quick_tool'].preferences.sna_mmd)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_85326 = layout.column(heading='', align=False)
        col_85326.alert = False
        col_85326.enabled = True
        col_85326.active = True
        col_85326.use_property_split = False
        col_85326.use_property_decorate = False
        col_85326.scale_x = 1.0
        col_85326.scale_y = 1.0
        col_85326.alignment = 'Expand'.upper()
        if not True: col_85326.operator_context = "EXEC_DEFAULT"
        op = col_85326.operator('sna.operator004_fa32a', text='合并相同贴图的材质', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator005_9368b', text='替换mmd材质节点组', icon_value=0, emboss=True, depress=False)
        op = col_85326.operator('sna.operator010_78668', text='为abc添加材质', icon_value=0, emboss=True, depress=False)
        col_52A12 = col_85326.column(heading='', align=True)
        col_52A12.alert = False
        col_52A12.enabled = True
        col_52A12.active = True
        col_52A12.use_property_split = False
        col_52A12.use_property_decorate = False
        col_52A12.scale_x = 1.0
        col_52A12.scale_y = 1.0
        col_52A12.alignment = 'Center'.upper()
        if not True: col_52A12.operator_context = "EXEC_DEFAULT"
        col_52A12.separator(factor=1.003000020980835)
        col_52A12.label(text='如果导入mmd相机后经常闪退可以试试这个', icon_value=0)
        op = col_52A12.operator('sna.operator006_42368', text='相机闪退修复', icon_value=0, emboss=True, depress=False)
        op.sna_camera_name = ''
        op.sna_mmd_camera = ''
        if ((len(bpy.context.view_layer.objects.selected) == 2) and ((bpy.context.view_layer.objects.selected[0].type == 'EMPTY' and bpy.context.view_layer.objects.selected[1].type == 'CAMERA') or (bpy.context.view_layer.objects.selected[1].type == 'EMPTY' and bpy.context.view_layer.objects.selected[0].type == 'CAMERA'))):
            col_52A12.prop(bpy.context.scene, 'sna_new_property_002', text='帧偏移', icon_value=0, emboss=True)


class SNA_PT_panel_3A032(bpy.types.Panel):
    bl_label = '分段渲染'
    bl_idname = 'SNA_PT_panel_3A032'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 2
    bl_parent_id = 'SNA_PT_MMD_06384'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_9BC54 = layout.row(heading='', align=False)
        row_9BC54.alert = False
        row_9BC54.enabled = True
        row_9BC54.active = True
        row_9BC54.use_property_split = False
        row_9BC54.use_property_decorate = False
        row_9BC54.scale_x = 1.0
        row_9BC54.scale_y = 1.0
        row_9BC54.alignment = 'Expand'.upper()
        if not True: row_9BC54.operator_context = "EXEC_DEFAULT"
        coll_id = display_collection_id('B793B', locals())
        row_9BC54.template_list('SNA_UL_display_collection_list_B793B', coll_id, bpy.context.scene, 'sna_render_list', bpy.context.scene, 'sna_id', rows=0)
        col_B28B3 = row_9BC54.column(heading='', align=True)
        col_B28B3.alert = False
        col_B28B3.enabled = True
        col_B28B3.active = True
        col_B28B3.use_property_split = False
        col_B28B3.use_property_decorate = False
        col_B28B3.scale_x = 1.0
        col_B28B3.scale_y = 1.0
        col_B28B3.alignment = 'Expand'.upper()
        if not True: col_B28B3.operator_context = "EXEC_DEFAULT"
        op = col_B28B3.operator('sna.add_render_list_84292', text='', icon_value=31, emboss=True, depress=False)
        op = col_B28B3.operator('sna.remove_render_list_e8059', text='', icon_value=32, emboss=True, depress=False)
        col_B28B3.separator(factor=1.6389999389648438)
        op = col_B28B3.operator('sna.up_b66ca', text='', icon_value=7, emboss=True, depress=False)
        op = col_B28B3.operator('sna.down_25ee0', text='', icon_value=5, emboss=True, depress=False)
        col_34299 = layout.column(heading='', align=False)
        col_34299.alert = False
        col_34299.enabled = True
        col_34299.active = True
        col_34299.use_property_split = False
        col_34299.use_property_decorate = False
        col_34299.scale_x = 1.0
        col_34299.scale_y = 1.0
        col_34299.alignment = 'Expand'.upper()
        if not True: col_34299.operator_context = "EXEC_DEFAULT"
        row_9779E = col_34299.row(heading='', align=False)
        row_9779E.alert = bpy.context.scene.sna_is_render
        row_9779E.enabled = True
        row_9779E.active = True
        row_9779E.use_property_split = False
        row_9779E.use_property_decorate = False
        row_9779E.scale_x = 1.0
        row_9779E.scale_y = 1.0
        row_9779E.alignment = 'Expand'.upper()
        if not True: row_9779E.operator_context = "EXEC_DEFAULT"
        op = row_9779E.operator('sna.my_generic_operator_5874f', text=('正在渲染' if bpy.context.scene.sna_is_render else '开始渲染'), icon_value=0, emboss=True, depress=False)
        if bpy.context.scene.sna_is_render:
            row_42916 = col_34299.row(heading='', align=False)
            row_42916.alert = True
            row_42916.enabled = True
            row_42916.active = True
            row_42916.use_property_split = False
            row_42916.use_property_decorate = False
            row_42916.scale_x = 1.0
            row_42916.scale_y = 1.0
            row_42916.alignment = 'Center'.upper()
            if not True: row_42916.operator_context = "EXEC_DEFAULT"
            row_42916.label(text='正在进行    ' + bpy.context.scene.sna_render_list[bpy.context.scene.sna_id].name, icon_value=0)
            row_42916.label(text='第' + str(bpy.data.scenes['Scene'].frame_current) + '帧', icon_value=0)
        row_71992 = col_34299.row(heading='', align=False)
        row_71992.alert = False
        row_71992.enabled = True
        row_71992.active = True
        row_71992.use_property_split = False
        row_71992.use_property_decorate = False
        row_71992.scale_x = 1.0
        row_71992.scale_y = 1.0
        row_71992.alignment = 'Center'.upper()
        if not True: row_71992.operator_context = "EXEC_DEFAULT"
        row_71992.label(text='平均渲染时间(五次)  ' + str(node_tree_001['sna_avg_render_time']), icon_value=0)
        row_71992.label(text='还剩' + str(int(node_tree_001['sna_sub_frame'] - node_tree_001['sna_current_frame'])) + '帧', icon_value=0)
        row_71992.label(text='预计剩余' + str(round(float(int(node_tree_001['sna_sub_frame'] - node_tree_001['sna_current_frame']) * node_tree_001['sna_avg_render_time']), abs(2))) + '时间', icon_value=0)


class SNA_GROUP_sna_render_list_property(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='name', description='', default='', subtype='NONE', maxlen=0)
    start_frame: bpy.props.IntProperty(name='start_frame', description='', default=0, subtype='NONE')
    end_frame: bpy.props.IntProperty(name='end_frame', description='', default=0, subtype='NONE')
    render_camera: bpy.props.PointerProperty(name='render_camera', description='', type=bpy.types.Object, update=sna_update_render_camera_28727)
    output_directory: bpy.props.StringProperty(name='output_directory', description='', default='', subtype='DIR_PATH', maxlen=0)
    on: bpy.props.BoolProperty(name='on', description='', default=True)


class SNA_GROUP_sna_render_time(bpy.types.PropertyGroup):
    frame_start_time: bpy.props.FloatProperty(name='frame_start_time', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)
    frame_time: bpy.props.FloatProperty(name='frame_time', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=2)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_render_list_property)
    bpy.utils.register_class(SNA_GROUP_sna_render_time)
    bpy.types.Scene.sna_bili = bpy.props.EnumProperty(name='bili', description='', items=[('自定义', '自定义', '', 0, 0), ('1:1', '1:1', '', 0, 1), ('3:2', '3:2', '', 0, 2), ('4:3', '4:3', '', 0, 3), ('16:9', '16:9', '', 0, 4), ('14:9', '14:9', '', 0, 5), ('1.85:1', '1.85:1', '', 0, 6), ('2.39:1', '2.39:1', '', 0, 7)], update=sna_update_sna_bili_31149)
    bpy.types.Scene.sna_new_property = bpy.props.BoolProperty(name='锁定比例', description='', default=False)
    bpy.types.Scene.sna_new_property_001 = bpy.props.EnumProperty(name='灯光角度', description='', items=[('自定义', '自定义', '', 0, 0), ('0', '0', '', 0, 1), ('15', '15', '', 0, 2), ('60', '60', '', 0, 3), ('90', '90', '', 0, 4), ('120', '120', '', 0, 5), ('180', '180', '', 0, 6)], update=sna_update_sna_new_property_001_7222D)
    bpy.types.Scene.sna_new_property_002 = bpy.props.IntProperty(name='帧偏移', description='', default=30, subtype='NONE')
    bpy.types.Scene.sna_new_property_003 = bpy.props.BoolProperty(name='切换中英文', description='', default=True, update=sna_update_sna_new_property_003_1E44E)
    bpy.types.Scene.sna_new_property_004 = bpy.props.FloatProperty(name='分.秒', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=3, precision=2, update=sna_update_sna_new_property_004_0F02E)
    bpy.types.Scene.sna_id = bpy.props.IntProperty(name='id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_render_list = bpy.props.CollectionProperty(name='render_list', description='', type=SNA_GROUP_sna_render_list_property)
    bpy.types.Scene.sna_is_render = bpy.props.BoolProperty(name='is_render', description='', default=False)
    bpy.types.Scene.sna_render_time_id = bpy.props.IntProperty(name='render_time_id', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_time = bpy.props.CollectionProperty(name='time', description='', type=SNA_GROUP_sna_render_time)
    bpy.types.Scene.sna_open = bpy.props.BoolProperty(name='open', description='', default=True)
    bpy.utils.register_class(SNA_OT_Operator001_64C4A)
    bpy.utils.register_class(SNA_OT_Operator_B46A6)
    bpy.utils.register_class(SNA_OT_Operator007_85779)
    bpy.utils.register_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.register_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.register_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.append(sna_add_to_render_pt_format_0A62E)
    bpy.utils.register_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.register_class(SNA_OT_Operator015_0Ebb1)
    bpy.types.VIEW3D_HT_tool_header.append(sna_add_to_view3d_ht_tool_header_3D7F1)
    bpy.utils.register_class(SNA_OT_Operator013_2E178)
    bpy.types.CYCLES_LIGHT_PT_light.append(sna_add_to_cycles_light_pt_light_8C939)
    bpy.utils.register_class(SNA_OT_Operator019_8Aa9A)
    bpy.utils.register_class(SNA_OT_Operator017_E38Ed)
    bpy.utils.register_class(SNA_OT_Operator018_Bf94B)
    bpy.utils.register_class(SNA_OT_Operator016_2E985)
    bpy.utils.register_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.register_class(SNA_OT_Operator005_9368B)
    bpy.utils.register_class(SNA_OT_Operator006_42368)
    bpy.utils.register_class(SNA_OT_Operator010_78668)
    bpy.types.TIME_MT_editor_menus.append(sna_add_to_time_mt_editor_menus_3F6F3)
    bpy.utils.register_class(SNA_OT_Operator003_F8Ede)
    bpy.utils.register_class(SNA_OT_Operator011_9D3Ab)
    bpy.utils.register_class(SNA_OT_Operator012_Bbb3C)
    bpy.utils.register_class(SNA_PT_MMD_06384)
    bpy.app.handlers.frame_change_post.append(frame_change_post_handler_1BDE6)
    bpy.utils.register_class(SNA_OT_Down_25Ee0)
    bpy.utils.register_class(SNA_OT_Up_B66Ca)
    bpy.utils.register_class(SNA_OT_Add_Render_List_84292)
    bpy.utils.register_class(SNA_OT_Remove_Render_List_E8059)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_5874F)
    bpy.app.handlers.render_complete.append(render_complete_handler_825EB)
    bpy.app.handlers.render_complete.append(render_complete_handler_C420C)
    bpy.utils.register_class(SNA_OT_My_Generic_Operator_33F13)
    bpy.app.handlers.render_cancel.append(render_cancel_handler_58683)
    bpy.app.handlers.render_post.append(render_post_handler_4E079)
    bpy.app.handlers.render_pre.append(render_pre_handler_1092E)
    bpy.app.handlers.render_post.append(render_post_handler_15713)
    bpy.utils.register_class(SNA_OT_Operator_Cc77E)
    bpy.app.handlers.render_post.append(render_post_handler_B2801)
    bpy.utils.register_class(SNA_AddonPreferences_C113E)
    bpy.utils.register_class(SNA_PT__C52FF)
    bpy.utils.register_class(SNA_PT_panel_42AE7)
    bpy.utils.register_class(SNA_PT__5C6B9)
    bpy.utils.register_class(SNA_PT__4C59C)
    bpy.utils.register_class(SNA_PT_MMD_720C4)
    bpy.utils.register_class(SNA_PT_panel_3A032)
    bpy.utils.register_class(SNA_UL_display_collection_list_B793B)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_open
    del bpy.types.Scene.sna_time
    del bpy.types.Scene.sna_render_time_id
    del bpy.types.Scene.sna_is_render
    del bpy.types.Scene.sna_render_list
    del bpy.types.Scene.sna_id
    del bpy.types.Scene.sna_new_property_004
    del bpy.types.Scene.sna_new_property_003
    del bpy.types.Scene.sna_new_property_002
    del bpy.types.Scene.sna_new_property_001
    del bpy.types.Scene.sna_new_property
    del bpy.types.Scene.sna_bili
    bpy.utils.unregister_class(SNA_GROUP_sna_render_time)
    bpy.utils.unregister_class(SNA_GROUP_sna_render_list_property)
    bpy.utils.unregister_class(SNA_OT_Operator001_64C4A)
    bpy.utils.unregister_class(SNA_OT_Operator_B46A6)
    bpy.utils.unregister_class(SNA_OT_Operator007_85779)
    bpy.utils.unregister_class(SNA_OT_Operator008_F7B4C)
    bpy.utils.unregister_class(SNA_OT_Operator002_7Dbd9)
    bpy.utils.unregister_class(SNA_OT_Operator014_47F89)
    bpy.types.RENDER_PT_format.remove(sna_add_to_render_pt_format_0A62E)
    bpy.utils.unregister_class(SNA_OT_Operator009_F9Bf5)
    bpy.utils.unregister_class(SNA_OT_Operator015_0Ebb1)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_3D7F1)
    bpy.utils.unregister_class(SNA_OT_Operator013_2E178)
    bpy.types.CYCLES_LIGHT_PT_light.remove(sna_add_to_cycles_light_pt_light_8C939)
    bpy.utils.unregister_class(SNA_OT_Operator019_8Aa9A)
    bpy.utils.unregister_class(SNA_OT_Operator017_E38Ed)
    bpy.utils.unregister_class(SNA_OT_Operator018_Bf94B)
    bpy.utils.unregister_class(SNA_OT_Operator016_2E985)
    bpy.utils.unregister_class(SNA_OT_Operator004_Fa32A)
    bpy.utils.unregister_class(SNA_OT_Operator005_9368B)
    bpy.utils.unregister_class(SNA_OT_Operator006_42368)
    bpy.utils.unregister_class(SNA_OT_Operator010_78668)
    bpy.types.TIME_MT_editor_menus.remove(sna_add_to_time_mt_editor_menus_3F6F3)
    bpy.utils.unregister_class(SNA_OT_Operator003_F8Ede)
    bpy.utils.unregister_class(SNA_OT_Operator011_9D3Ab)
    bpy.utils.unregister_class(SNA_OT_Operator012_Bbb3C)
    bpy.utils.unregister_class(SNA_PT_MMD_06384)
    bpy.app.handlers.frame_change_post.remove(frame_change_post_handler_1BDE6)
    bpy.utils.unregister_class(SNA_OT_Down_25Ee0)
    bpy.utils.unregister_class(SNA_OT_Up_B66Ca)
    bpy.utils.unregister_class(SNA_OT_Add_Render_List_84292)
    bpy.utils.unregister_class(SNA_OT_Remove_Render_List_E8059)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_5874F)
    bpy.app.handlers.render_complete.remove(render_complete_handler_825EB)
    bpy.app.handlers.render_complete.remove(render_complete_handler_C420C)
    bpy.utils.unregister_class(SNA_OT_My_Generic_Operator_33F13)
    bpy.app.handlers.render_cancel.remove(render_cancel_handler_58683)
    bpy.app.handlers.render_post.remove(render_post_handler_4E079)
    bpy.app.handlers.render_pre.remove(render_pre_handler_1092E)
    bpy.app.handlers.render_post.remove(render_post_handler_15713)
    bpy.utils.unregister_class(SNA_OT_Operator_Cc77E)
    bpy.app.handlers.render_post.remove(render_post_handler_B2801)
    bpy.utils.unregister_class(SNA_AddonPreferences_C113E)
    bpy.utils.unregister_class(SNA_PT__C52FF)
    bpy.utils.unregister_class(SNA_PT_panel_42AE7)
    bpy.utils.unregister_class(SNA_PT__5C6B9)
    bpy.utils.unregister_class(SNA_PT__4C59C)
    bpy.utils.unregister_class(SNA_PT_MMD_720C4)
    bpy.utils.unregister_class(SNA_PT_panel_3A032)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_B793B)
